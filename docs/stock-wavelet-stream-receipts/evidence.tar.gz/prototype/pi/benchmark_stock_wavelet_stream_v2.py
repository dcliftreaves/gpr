"""Fixed within-process native-12MP comparison of retained and streamed inverse."""
from pathlib import Path
import hashlib,json,os,statistics,subprocess
ROOT=Path('/mnt/ssd/gpr_work/stock-wavelet-row-pipeline-20261031');SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030');OUT=ROOT/'isolated-v2'
ORDER=[0,1,2,3,3,2,1,0,2,0,3,1,1,3,0,2];NAMES=['none','retained-inverse','pipelined-retained-inverse','streamed-inverse']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);source=json.loads((SEED/'protocol.json').read_text());exe=ROOT/'build/wavelet_stream_benchmark';env={k:v for k,v in os.environ.items() if not k.startswith('GPR_')};flags={n:'1' for n in ['GPR_STREAM_UNPACK','GPR_BAND_STREAM','GPR_CHANNEL_ASM','GPR_PIN_CHANNELS','GPR_DIRECT_BANDS','GPR_COMPACT_BANDS']};env.update(flags)
 assert os.getuid()==1000 and os.sched_getscheduler(0)==os.SCHED_OTHER and os.getpriority(os.PRIO_PROCESS,0)==0
 protocol=dict(schema='gpr.stock_wavelet_stream_modes.v1',base='ba2d89b698d08792c2350ee09ba415c735a64661',driver_sha256=sha(Path(__file__)),binary_sha256=sha(exe),source_sha256={n:sha(ROOT/n) for n in ['source/lib/vc5_encoder/encoder.c','source/lib/vc5_encoder/encoder.h','source/lib/vc5_encoder/parameters.h','source/lib/vc5_common/vc5_preview.h','source/lib/vc5_decoder/inverse.c','tests/wavelet_row_collector.hpp','tests/wavelet_stream_benchmark.cpp','CMakeLists.txt']},independent_source_protocol_sha256=sha(SEED/'protocol.json'),source_inputs=source['inputs'],reference_payloads=source['reference_payloads'],fixed_order=[NAMES[i] for i in ORDER],iterations_per_block=16,warmups_per_block=1,flags=flags,scheduling='UID1000 SCHED_OTHER nice0; per-worker affinity request only. No realtime/global/device changes.',acceptance_timing=False,scope='Same executable/process/192MiBencoderarena per input; preallocated legacy or boundedstreaminverse workspace. Streaming uses experimental private row callback with compact HP rows and complete final planes. All payloads independent historical stock exact; actual inverse modes compare all3planes against independent entropy decode. No capture/color/queues/storage/pacing.',promotion='No production integration or sustained rate claim based on this diagnostic. Need matched workflow validation, callback/ownership/failure contracts and public package compatibility first.')
 save(OUT/'protocol.json',protocol);receipt=dict(complete=False,protocol_sha256=sha(OUT/'protocol.json'),sources=[]);save(OUT/'receipt.json',receipt)
 for i,item in enumerate(source['inputs']):
  raw=SEED/item['raw_file'];ref=SEED/f'reference-{i}.vc5';assert sha(raw)==item['raw_sha256'] and sha(ref)==source['reference_payloads'][i]['sha256']
  with (OUT/f'{i}.jsonl').open('w') as out,(OUT/f'{i}.stderr').open('w') as err:
   child=subprocess.Popen([str(exe),str(raw),str(ref)],stdout=out,stderr=err,env=env);observed=dict(pid=child.pid,uid=os.getuid(),policy=os.sched_getscheduler(child.pid),priority=os.sched_getparam(child.pid).sched_priority,nice=os.getpriority(os.PRIO_PROCESS,child.pid));assert observed['policy']==0 and observed['priority']==0 and observed['nice']==0;save(OUT/f'{i}-observed.json',observed);assert child.wait(timeout=180)==0
  events=[json.loads(s) for s in (OUT/f'{i}.jsonl').read_text().splitlines()];assert len(events)==256
  for b,mode in enumerate(protocol['fixed_order']):
   for j,event in enumerate(events[b*16:(b+1)*16]):
    assert event['block']==b and event['iteration']==j and event['mode']==mode and event['warmup']==(j==0) and event['payload_exact_independent_stock']
    assert event['planes_exact_independent_decode'] is (None if mode=='none' else True)
    if mode=='streamed-inverse':assert event['max_hp_live']<=16 and event['max_ll_live']<=8
  modes={}
  for mode in NAMES:
   rows=[e for e in events if e['mode']==mode and not e['warmup']];assert len(rows)==60
   modes[mode]=dict(iterations=60,median_ms=statistics.median(e['wall_s']*1000 for e in rows),min_ms=min(e['wall_s']*1000 for e in rows),max_ms=max(e['wall_s']*1000 for e in rows),block_median_ms=[statistics.median(e['wall_s']*1000 for e in rows if e['block']==b) for b,m in enumerate(protocol['fixed_order']) if m==mode],encoder_bytes=sorted({e['encoder_bytes'] for e in rows}),max_hp_live=max(e['max_hp_live'] for e in rows),max_ll_live=max(e['max_ll_live'] for e in rows))
  row=dict(source=i,modes=modes,observed=observed,all_payloads_exact=True,all_reconstructed_modes_exact=True);receipt['sources'].append(row);save(OUT/'receipt.json',receipt);print(json.dumps(row),flush=True)
 receipt['complete']=True;save(OUT/'receipt.json',receipt)
if __name__=='__main__':main()
