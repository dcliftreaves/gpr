"""Independently recompute all isolated streaming-wavelet mode results."""
from pathlib import Path
import hashlib,json,statistics,math
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_wavelet_stream_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 result=dict(schema='gpr.stock_wavelet_stream_audit.v1',complete=False,driver_sha256=sha(Path(__file__)),studies=[],payload_comparisons=0,reconstructed_frame_comparisons=0,plane_comparisons=0,production_integration=False,sustained_capture_test=False,goal_timing_gate_closed=False)
 for version,study in [('v1','isolated'),('v2','isolated-v2'),('v3','isolated-v3')]:
  d=ROOT/'pi'/study;p=json.loads((d/'protocol.json').read_text());report=json.loads((d/'receipt.json').read_text());assert report['complete'] and report['protocol_sha256']==sha(d/'protocol.json')
  for name,digest in p['source_sha256'].items():assert sha(ROOT/version/name)==digest,(version,name)
  driver='benchmark_stock_wavelet_stream'+('' if version=='v1' else '_'+version)+'.py';assert sha(ROOT/'pi'/driver)==p['driver_sha256'];sources=[]
  for index,row in enumerate(report['sources']):
   events=[json.loads(l) for l in (d/f'{index}.jsonl').read_text().splitlines()];assert len(events)==256 and row['observed']['uid']==1000 and row['observed']['policy']==0 and row['observed']['nice']==0
   for b,mode in enumerate(p['fixed_order']):
    for j,e in enumerate(events[b*16:(b+1)*16]):
     assert e['block']==b and e['iteration']==j and e['warmup']==(j==0) and e['mode']==mode and e['payload_exact_independent_stock'];result['payload_comparisons']+=1
     if mode=='none':assert e['planes_exact_independent_decode'] is None
     else:assert e['planes_exact_independent_decode'] is True;result['reconstructed_frame_comparisons']+=1;result['plane_comparisons']+=3
     if mode=='streamed-inverse':assert e['max_hp_live']<=8 and e['max_ll_live']<=4
   modes={}
   for mode,expected in row['modes'].items():
    es=[e for e in events if e['mode']==mode and not e['warmup']];assert len(es)==60
    median=statistics.median(e['wall_s']*1000 for e in es);blocks=[statistics.median(e['wall_s']*1000 for e in es if e['block']==b) for b,m in enumerate(p['fixed_order']) if m==mode]
    assert median==expected['median_ms'] and blocks==expected['block_median_ms'];modes[mode]=dict(median_ms=median,block_median_ms=blocks,encoder_bytes=sorted({e['encoder_bytes'] for e in es}),max_hp_live=max(e['max_hp_live'] for e in es),max_ll_live=max(e['max_ll_live'] for e in es))
   base=modes['retained-inverse'];candidate=modes['streamed-inverse'];sources.append(dict(source=index,modes=modes,gain_ms=base['median_ms']-candidate['median_ms'],every_stream_block_faster_than_every_retained_block=max(candidate['block_median_ms'])<min(base['block_median_ms'])))
  result['studies'].append(dict(version=version,protocol_sha256=sha(d/'protocol.json'),sources=sources))
 assert all(s['every_stream_block_faster_than_every_retained_block'] for s in result['studies'][-1]['sources'])
 assert not result['studies'][1]['sources'][0]['every_stream_block_faster_than_every_retained_block']
 # Both machine families compare against unchanged full inverse and independent
 # payload entropy decoding. New contracts are standalone prototype checks.
 for name,count in [('pipeline-contract.json',360),('row-contract.json',840),('stream-contract.json',360),('v2-row-contract.json',840),('v2-stream-contract.json',360),('v3-corrected-contract.json',497)]:
  o=json.loads((ROOT/'pi'/name).read_text());assert o['cases']==count and all(v is True for k,v in o.items() if k!='cases')
 result.update(complete=True,final_ring_profile='8 HP rows for even lower-band height,16 for odd-height tail;4 reconstructed LL rows;3 upper coefficient rows',final_native_live_rows=dict(highpass=8,reconstructed_ll=4),final_native_encoder_arena_saving_bytes=104257536-97936896,conclusion='Final bounded-ring prototype is faster in each fixed native-input block and exact in codec/plane checks. Intermediate v2 input0 has mixed/slower blocks. No calibrated capture lifecycle/public API/package integration or sustained timing approval follows.')
 (ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='studies'},indent=2))
if __name__=='__main__':main()
