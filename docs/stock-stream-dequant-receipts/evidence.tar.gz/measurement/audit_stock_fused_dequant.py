"""Audit saved integration receipts; clip-byte checks were completed before deletion."""
from pathlib import Path
import hashlib,json,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_fused_dequant_20261031')
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-stream-fused-dequant-20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=json.loads((ROOT/'native-abba/protocol.json').read_text());r=json.loads((ROOT/'native-abba/receipt.json').read_text())
 assert r['complete']
 assert r['protocol_sha256']==sha(ROOT/'native-abba/protocol.json')
 assert p['order']==['baseline','streamed','streamed','baseline'] and p['attempts_per_run']==600
 for name,digest in p['uncommitted_integration_source'].items():assert sha(REPO/name)==digest,name
 assert sha(Path('analysis/benchmark_stock_fused_dequant_capture.py'))==p['driver_sha256']
 for name,digest in p['verifier_sources'].items():assert sha(REPO/'tools'/name)==digest
 rows=[];total=0
 for i,run in enumerate(r['runs']):
  assert (run['index'],run['mode'])==(i,p['order'][i])
  events=[json.loads(l) for l in (ROOT/f'native-abba/{i}.jsonl').read_text().splitlines() if l.startswith('{')]
  frames=[x for x in events if x['event']=='frame'];previews=[x for x in events if x['event']=='preview']
  c=next(x for x in events if x['event']=='summary');q=next(x for x in events if x['event']=='preview_summary');v=run['verified']
  assert c==v['capture'] and q==v['preview'] and c['complete']
  assert len(frames)==len(previews)==v['frames_verified']==c['written']==c['accepted']==q['rendered']==q['offered']
  assert c['attempts']==600==len(frames)+c['overruns'] and not q['discarded']
  assert c['deadline_misses']==sum(x['deadline_missed'] for x in frames)
  late=sum(x['capture_to_sink_ms']>50 for x in previews)
  assert v['floor']==dict(recording=not c['overruns'] and not c['deadline_misses'] and c['durable_fps']>=20,preview=len(previews)==600 and not late,preview_late_deliveries=late,deadline_ms=50.0)
  assert abs(sorted(x['encode_ms'] for x in frames)[int((len(frames)-1)*.5)]-c['encode_median_ms'])<.0002
  assert [x['index'] for x in frames]==list(range(len(frames)))
  fm={x['index']:x for x in frames}
  for x in previews:assert x['timestamp_ns']==fm[x['index']]['timestamp_ns'] and x['width']==1024 and x['height']==768
  assert run['observed']==dict(uids=[1000]*4,policy=1,priority=1,nice=0,capabilities='0000000000000000')
  assert run['clip_deleted_after_verification'] and run['clip_bytes']>c['payload_bytes'] and len(v['clip_sha256'])==64
  for key in ['all_payloads_exact_independent_stock','all_source_calibration_exact','all_delivered_preview_pixels_exact_offline','end_marker_verified']:assert v[key]
  assert q['streamed_inverse'] and q['stream_buffer_bytes']==4843522 and not q['reconstruction_scratch_bytes']
  total+=len(frames)
  rows.append(dict(index=i,mode=run['mode'],frames=len(frames),durable_fps=c['durable_fps'],encode_median_ms=c['encode_median_ms'],late_writes=c['deadline_misses'],late_previews=late,workspace_bytes=c['workspace_peak_bytes'],peak_rss_bytes=c['peak_rss_bytes'],floor=v['floor']))
 result=dict(complete=True,scope='Independent source binding/event/accounting/deadline audit; original clip bytes/calibration/CRC/pixels/END3 checked by archived verifier before deletion, not rechecked from deleted clips.',frames_verified_before_clip_deletion=total,streamed_fixed_repeats_passed=r['streamed_fixed_repeats_passed'],runs=rows)
 assert r['streamed_fixed_repeats_passed']==all(x['floor']['recording'] and x['floor']['preview'] for x in rows if x['mode']=='streamed')
 (ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
