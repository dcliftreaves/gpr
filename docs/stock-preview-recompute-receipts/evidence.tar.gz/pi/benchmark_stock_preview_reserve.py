"""Fixed within-process five-mode Pi experiment, ordinary scheduling only."""
from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
ROOT=Path('/mnt/ssd/gpr_work/stock-preview-recompute-20261031');SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030');OUT=ROOT/'reserve-only';ORDER=[0,1,2,2,1,0,1,0,2,0,2,1];NAMES=['none','retain','reserve-only']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);source=json.loads((SEED/'protocol.json').read_text());exe=ROOT/'build/preview_reserve_benchmark';env={k:v for k,v in os.environ.items() if not k.startswith('GPR_')};flags={n:'1' for n in ['GPR_STREAM_UNPACK','GPR_BAND_STREAM','GPR_CHANNEL_ASM','GPR_PIN_CHANNELS','GPR_DIRECT_BANDS','GPR_COMPACT_BANDS']};env.update(flags)
 assert os.getuid()==1000 and os.sched_getscheduler(0)==os.SCHED_OTHER and os.getpriority(os.PRIO_PROCESS,0)==0
 protocol=dict(schema='gpr.stock_preview_reserve_modes.v1',base='ffe8385a085585a79350e276a060386210ccc2a2',driver_sha256=sha(Path(__file__)),binary_sha256=sha(exe),source_sha256={n:sha(ROOT/n) for n in ['source/lib/vc5_encoder/encoder.c','CMakeLists.txt','tests/preview_reserve_benchmark.cpp','tests/preview_recompute_contract.cpp']},independent_source_protocol_sha256=sha(SEED/'protocol.json'),source_inputs=source['inputs'],reference_payloads=source['reference_payloads'],fixed_order=[NAMES[i] for i in ORDER],iterations_per_block=16,warmups_per_block=1,flags=flags,scheduling='Unprivileged UID1000 SCHED_OTHER nice0. Requested per-worker pinning; no sudo, realtime, boot, device or system setting changes.',acceptance_timing=False,scope='Three modes same binary/process/arena: ordinary compact allocation, actual retained bands with a tiny observer, or full upper-band allocation without observer/retained writes. Every payload checked against independent historical encoding. Layout-reservation diagnostic only, no reconstruction/capture/storage/pacing. Original compressed references are not sensor truth.')
 save(OUT/'protocol.json',protocol);report=dict(complete=False,protocol_sha256=sha(OUT/'protocol.json'),sources=[]);save(OUT/'receipt.json',report)
 for i,item in enumerate(source['inputs']):
  raw=SEED/item['raw_file'];ref=SEED/f'reference-{i}.vc5';assert sha(raw)==item['raw_sha256'] and sha(ref)==source['reference_payloads'][i]['sha256']
  with (OUT/f'{i}.jsonl').open('w') as out,(OUT/f'{i}.stderr').open('w') as err:
   child=subprocess.Popen([str(exe),str(raw),str(ref)],stdout=out,stderr=err,env=env)
   observed=dict(pid=child.pid,uid=os.getuid(),policy=os.sched_getscheduler(child.pid),priority=os.sched_getparam(child.pid).sched_priority,nice=os.getpriority(os.PRIO_PROCESS,child.pid));assert observed['policy']==os.SCHED_OTHER and observed['priority']==0 and observed['nice']==0;save(OUT/f'{i}-observed.json',observed)
   assert child.wait(timeout=180)==0
  events=[json.loads(s) for s in (OUT/f'{i}.jsonl').read_text().splitlines()];assert len(events)==192
  for b,mode in enumerate(protocol['fixed_order']):
   block=events[b*16:b*16+16];assert all(e['block']==b and e['mode']==mode and e['iteration']==j and e['warmup']==(j==0) and e['all_payloads_exact_independent_stock'] for j,e in enumerate(block))
   if 'reconstruct' in mode:assert all(e['planes_exact_independent_decode'] for e in block)
  modes={}
  for mode in NAMES:
   rows=[e for e in events if e['mode']==mode and not e['warmup']];assert len(rows)==60
   modes[mode]=dict(median_ms=statistics.median(e['wall_s']*1000 for e in rows),min_ms=min(e['wall_s']*1000 for e in rows),max_ms=max(e['wall_s']*1000 for e in rows),block_median_ms=[statistics.median(e['wall_s']*1000 for e in rows if e['block']==b) for b,n in enumerate(protocol['fixed_order']) if n==mode],callback_median_ms=statistics.median(e['callback_s']*1000 for e in rows),encoder_bytes=sorted({e['encoder_used'] for e in rows}),iterations=60)
  row=dict(source=i,observed=observed,modes=modes,all_payloads_exact=True,all_reconstructed_planes_exact=True);report['sources'].append(row);save(OUT/'receipt.json',report);print(json.dumps(row),flush=True)
 report['complete']=True;save(OUT/'receipt.json',report)
if __name__=='__main__':main()
