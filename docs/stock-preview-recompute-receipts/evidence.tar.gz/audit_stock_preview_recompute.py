"""Independently score all recomputation/reservation events and source bindings."""
from pathlib import Path
import hashlib,json,statistics,math,subprocess
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_preview_recompute_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 result=dict(schema='gpr.stock_preview_recompute_audit.v1',complete=False,driver_sha256=sha(Path(__file__)),studies=[],payload_comparisons=0,reconstructed_frame_comparisons=0,plane_comparisons=0,production_source_changed=False,accepted_runtime_change=False,acceptance_timing=False)
 for study,source in [('isolated','v1-snapshot/encoder.c'),('isolated-v2','v2-snapshot/encoder.c'),('reserve-only','source/lib/vc5_encoder/encoder.c')]:
  r=ROOT/'pi'/study;p=json.loads((r/'protocol.json').read_text());receipt=json.loads((r/'receipt.json').read_text());assert receipt['complete'] and sha(r/'protocol.json')==receipt['protocol_sha256']
  assert sha(ROOT/'pi'/source)==p['source_sha256']['source/lib/vc5_encoder/encoder.c']
  snapshot='v1-snapshot' if study=='isolated' else 'v2-snapshot' if study=='isolated-v2' else None
  for name,expected in p['source_sha256'].items():
   path=ROOT/'pi'/name
   if name=='source/lib/vc5_encoder/encoder.c':path=ROOT/'pi'/source
   if name=='CMakeLists.txt' and snapshot:path=ROOT/'pi'/snapshot/'CMakeLists.txt'
   assert sha(path)==expected,(study,name)
  driver={'isolated':'benchmark_stock_preview_recompute.py','isolated-v2':'benchmark_stock_preview_recompute_v2.py','reserve-only':'benchmark_stock_preview_reserve.py'}[study]
  assert sha(ROOT/'pi'/driver)==p['driver_sha256']
  rows=[]
  for i,original in enumerate(receipt['sources']):
   events=[json.loads(l) for l in (r/f'{i}.jsonl').read_text().splitlines()];assert len(events)==len(p['fixed_order'])*16
   for block,mode in enumerate(p['fixed_order']):
    es=events[block*16:(block+1)*16];assert all(e['block']==block and e['mode']==mode and e['iteration']==j and e['warmup']==(j==0) and e['all_payloads_exact_independent_stock'] for j,e in enumerate(es))
    for e in es:
     result['payload_comparisons']+=1
     if mode in ('reconstruct','recompute-reconstruct'):
      assert e['planes_exact_independent_decode'] is True;result['reconstructed_frame_comparisons']+=1;result['plane_comparisons']+=3
     else:assert e['planes_exact_independent_decode'] is None
   modes={}
   for mode,expected in original['modes'].items():
    es=[e for e in events if e['mode']==mode and not e['warmup']];assert len(es)==60
    med=statistics.median(e['wall_s']*1000 for e in es);blocks=[statistics.median(e['wall_s']*1000 for e in es if e['block']==b) for b,m in enumerate(p['fixed_order']) if m==mode]
    assert med==expected['median_ms'] and blocks==expected['block_median_ms'];modes[mode]=dict(median_ms=med,block_median_ms=blocks,encoder_bytes=sorted({e['encoder_used'] for e in es}))
   row=dict(source=i,modes=modes,uid=original['observed']['uid'],policy=original['observed']['policy']);assert row['uid']==1000 and row['policy']==0
   if study=='reserve-only':
    assert modes['reserve-only']['encoder_bytes']==modes['retain']['encoder_bytes'] and modes['none']['encoder_bytes']!=modes['retain']['encoder_bytes']
    row.update(reserve_minus_none_ms=modes['reserve-only']['median_ms']-modes['none']['median_ms'],retain_minus_reserve_ms=modes['retain']['median_ms']-modes['reserve-only']['median_ms'],reconstructed_planes_verified=None,producer_unused_plane_summary_ignored=True)
   else:
    assert min(modes['recompute-reconstruct']['block_median_ms'])>max(modes['reconstruct']['block_median_ms']);row.update(recompute_minus_baseline_ms=modes['recompute-reconstruct']['median_ms']-modes['reconstruct']['median_ms'],reconstructed_planes_verified=True)
   rows.append(row)
  result['studies'].append(dict(name=study,protocol_sha256=sha(r/'protocol.json'),sources=rows))
 # The reserve-only driver's copied aggregate plane flag is unsupported: raw
 # events correctly report null for every frame, and no observer is called.
 # Preserve raw producer bytes; canonical audit deliberately reports null.
 result['reserve_only_producer_field_correction']='all_reconstructed_planes_exact=true was a copied unused aggregate, contradicted by null frame fields and no reconstruction. Ignore aggregate; no plane verification is claimed for reservation control.'
 for label in ['v1-snapshot/contract.json','v2-contract.json']:
  c=json.loads((ROOT/'pi'/label).read_text());assert c==dict(cases=144,payloads_exact=True,all_24_bands_exact=True,view_metadata_exact=True)
 for name in ['preview_recompute_mac_contract.json','preview_recompute_v2_mac_contract.json']:
  c=json.loads((ROOT/name).read_text());assert c['cases']==144 and c['all_24_bands_exact']
 binary_rows=Path('/Users/dcliftreaves/Documents/slop/gpr_check/analysis/preview_recompute_pi_binary_poststate.sha256').read_text().splitlines()
 for study,line in zip(['isolated','isolated-v2','reserve-only'],binary_rows[:3]):assert line.split()[0]==json.loads((ROOT/'pi'/study/'protocol.json').read_text())['binary_sha256']
 assert binary_rows[3].split()[0]=='c576f5662ac605cc5719ae536308e9ff71cdcec4f4e714343a5a919a5711687c'
 main=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime')
 baseline=subprocess.check_output(['git','show','ffe8385:source/lib/vc5_encoder/encoder.c'],cwd=main)
 assert (main/'source/lib/vc5_encoder/encoder.c').read_bytes()==baseline
 result.update(complete=True,all_source_harness_driver_binary_bindings_verified=True,production_encoder_source_unchanged=True,production_pi_capture_sha256=binary_rows[3].split()[0],coefficient_contract_pairs=576,conclusion='Reject both recomputation proposals. Reservation alone is close to ordinary compact encode; material cost remains in actual retained-band processing, not the full-storage reservation alone. No sustained capture gate was run or closed.')
 (ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='studies'},indent=2))
if __name__=='__main__':main()
