from pathlib import Path
import hashlib,json,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_quant_table_20261031/same-binary-final')
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-stream-quant-table-20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=json.loads((ROOT/'protocol.json').read_text());done=json.loads((ROOT/'complete.json').read_text());assert done['complete'] and done['protocol_sha256']==sha(ROOT/'protocol.json');assert p['driver_sha256']==sha(ROOT/'driver.py')
 for n,d in p['source_sha256'].items():assert sha(ROOT/n)==d
 for n,d in p['candidate_sha256'].items():assert sha(REPO/n)==d
 sources=[]
 for i in range(2):
  rows=[json.loads(l) for l in (ROOT/f'{i}.jsonl').read_text().splitlines()];assert len(rows)==128
  for j,e in enumerate(rows):assert (e['block'],e['iteration'],e['candidate'],e['warmup'])==(j//16,j%16,p['order'][j//16],j%16==0) and e['payload_exact'] and e['planes_exact']
  blocks=[dict(block=j,candidate=p['order'][j],median_ms=statistics.median(e['encode_preview_ms'] for e in rows if e['block']==j and not e['warmup'])) for j in range(8)]
  a=statistics.median(e['encode_preview_ms'] for e in rows if not e['candidate'] and not e['warmup']);b=statistics.median(e['encode_preview_ms'] for e in rows if e['candidate'] and not e['warmup']);faster=max(x['median_ms'] for x in blocks if x['candidate'])<min(x['median_ms'] for x in blocks if not x['candidate']);sources.append(dict(source=i,baseline_median_ms=a,candidate_median_ms=b,reduction_percent=100*(1-b/a),every_candidate_block_faster=faster,blocks=blocks));assert faster
 result=dict(complete=True,driver_sha256=sha(Path(__file__)),protocol_sha256=sha(ROOT/'protocol.json'),all_256_payloads_and_independently_decoded_planes_exact=True,measurements_per_mode_source_after_exclusion=60,sources=sources,scope='Unpaced encoder plus production stream inverse, same process; no rendering/capture/storage/finalfsync or sustained-rate approval.')
 (ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Both sources: every candidate block faster; all256 exact.')
if __name__=='__main__':main()
