"""Fixed native 12MP ABBA: accepted fused lookup versus quantizer-specific signed tables."""
from pathlib import Path
import hashlib,json,os,platform,subprocess,sys,time,shutil
REPO=Path('/mnt/ssd/gpr_work/stock-stream-quant-table-20261031');ROOT=REPO/'native-final';SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030');BASE=Path('/mnt/ssd/gpr_work/stock-stream-fused-dequant-20261031/build/gpr_capture_app')
sys.path.insert(0,str(REPO/'tools'));import benchmark_mission1 as bench,stock_video,raw_media

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 ROOT.mkdir(exist_ok=False);original=json.loads((SEED/'protocol.json').read_text());binaries={'baseline':BASE,'streamed':REPO/'build/gpr_capture_app'};hashes={k:sha(p) for k,p in binaries.items()};assert hashes['baseline']=='8a5c3e97b6e1fd3617fdf153b7c15e8817e49f9a430f2cf2bc7375fa024ed224'
 metadata=[];expected=[];offline={r['index']:r for r in map(json.loads,(SEED/'offline.jsonl').read_text().splitlines()) if r.get('event')=='preview'};assert set(offline)=={0,1};base=['--width','4096','--height','3072','--cfa','RGGB','--sample-bits','14','--quality','3','--fps-num','20','--fps-den','1','--queue','4','--workspace-mib','192','--leased','--writeback-mib','1']
 for i,item in enumerate(original['inputs']):
  raw=SEED/item['raw_file'];meta=SEED/item['metadata_file'];assert sha(raw)==item['raw_sha256'] and sha(meta)==item['metadata_sha256'];m=stock_video.decode_metadata(meta.read_bytes());raw_media.validate(m,dict(width=4096,height=3072,sample_bits=14,bayer='RGGB'));metadata.append(m)
  payload=SEED/f'reference-{i}.vc5';assert sha(payload)==original['reference_payloads'][i]['sha256'];expected.append(sha(payload));base+=['--input',str(raw),'--source-metadata',str(meta)]
 for i in range(2):assert sha(SEED/f'profiles/{i:06d}.gprp')==original['profile_sha256'][i]
 # Keep only one newly created clip at a time, after byte/pixel verification.
 required=600*max(r['bytes'] for r in original['reference_payloads'])+600*max((SEED/i['metadata_file']).stat().st_size for i in original['inputs'])+2*(1<<30)
 assert shutil.disk_usage(ROOT).free>required
 common=base+['--frames','600','--paced','--preview-every','1','--preview-sync-stages','--preview-foreground']
 for i in range(2):common+=['--preview-profile',str(SEED/f'profiles/{i:06d}.gprp')]
 sources=['source/lib/vc5_encoder/encoder.c','source/lib/vc5_encoder/encoder.h','source/lib/vc5_encoder/parameters.h','source/lib/vc5_encoder/vc5_encoder.c','source/lib/vc5_encoder/vc5_encoder.h','source/lib/vc5_common/vc5_preview.h','source/lib/vc5_decoder/inverse.c','source/lib/gpr_video/gpr_capture.cpp','source/lib/gpr_video/gpr_capture.h','source/lib/gpr_video/gpr_preview_stream.cpp','source/lib/gpr_video/gpr_preview_stream.h','source/lib/gpr_video/gpr_preview_dequantize.h','tests/preview_dequant_contract.c','tests/wavelet_stream_inverse_contract.cpp','source/app/gpr_capture_main.cpp','CMakeLists.txt','cmake/GPRInstall.cmake']
 protocol=dict(schema='gpr.stock_quant_table_final_capture.v1',base='1d998977a67ad3835a3c52835f2376ba137bffbd',prototype_checkpoint='Final value-initialized cache storage, preset-change/capacity checks; protocol binds actual source bytes',uncommitted_integration_source={n:sha(REPO/n) for n in sources},driver_sha256=sha(Path(__file__)),binaries={k:dict(path=str(p),sha256=hashes[k]) for k,p in binaries.items()},source_protocol_sha256=sha(SEED/'protocol.json'),inputs=original['inputs'],reference_payloads=original['reference_payloads'],profile_sha256=original['profile_sha256'],offline_sha256=sha(SEED/'offline.jsonl'),launcher_sha256=sha(SEED/'launch_stock_policy_user.py'),verifier_sources={n:sha(REPO/'tools'/n) for n in ['benchmark_mission1.py','stock_video.py','raw_media.py','stock_still.py']},order=['streamed','streamed'],attempts_per_run=600,fps=20,quality=3,common_command=common,mode_flags=dict(baseline='--preview-streamed',streamed='--preview-streamed'),scheduler='FIFO1 child only; UID1000/cap0/nice0 explicitly observed, no global/boot/device changes',realtime_runtime_us=Path('/proc/sys/kernel/sched_rt_runtime_us').read_text().strip(),realtime_period_us=Path('/proc/sys/kernel/sched_rt_period_us').read_text().strip(),platform=platform.platform(),scope='Native SDK-decoded compressed GoPro references, leased warm-cache replay, calibrated memory-CRC preview, serialized compute,1MiBwriteback,finalfsync. No newly launched Pi build/test/profiler during children; pre-existing long-lived workloads left unchanged, observed separately. Sensor/display/SD/thermal deployment remains unverified.',gate='Both fixed streamed runs must record/preview all600attempts,zerooverruns,zerolatewrites/previews,durablefps>=20,allpayload/calibration/pixels/CRC/END3/source-attemptbindings exact. Preserve all baseline/candidate failures.',temporary_clip_policy='Unlink only this run newly created clip AFTER independent verification and persistent clip SHA/byte count receipt; failed verification preserves clip.')
 save(ROOT/'protocol.json',protocol);report=dict(complete=False,protocol_sha256=sha(ROOT/'protocol.json'),runs=[]);save(ROOT/'receipt.json',report);environment={k:v for k,v in os.environ.items() if not k.startswith('GPR_')}
 for index,mode in enumerate(protocol['order']):
  assert all(sha(p)==hashes[k] for k,p in binaries.items());clip=ROOT/f'{index}-{mode}.gvid';launch=ROOT/f'{index}-launch.json';capture=[str(binaries[mode]),*common,protocol['mode_flags'][mode],'--output',str(clip)]
  command=['sudo','-n','chrt','--fifo','1','/usr/bin/setpriv','--reuid=1000','--regid=1000','--init-groups','--reset-env','/usr/bin/python3',str(SEED/'launch_stock_policy_user.py'),str(launch),str(os.SCHED_FIFO),*capture]
  save(ROOT/f'{index}-thermal-before.json',dict(millidegrees_c=Path('/sys/class/thermal/thermal_zone0/temp').read_text().strip(),throttled=subprocess.check_output(['vcgencmd','get_throttled'],text=True).strip()))
  print(json.dumps(dict(event='starting',index=index,mode=mode)),flush=True)
  with (ROOT/f'{index}.jsonl').open('w') as out,(ROOT/f'{index}.stderr').open('w') as err:
   child=subprocess.Popen(command,stdout=out,stderr=err,env=environment);save(ROOT/f'{index}-supervisor.json',dict(pid=child.pid,command=command));settings=None
   while settings is None:
    if launch.exists():
     try:settings=json.loads(launch.read_text())
     except json.JSONDecodeError:pass
    if settings is None:
     assert child.poll() is None,('child terminated before launch record',child.returncode);time.sleep(.005)
   pid=settings['pid'];status=(Path('/proc')/str(pid)/'status').read_text();observed=dict(uids=list(map(int,next(l.split()[1:] for l in status.splitlines() if l.startswith('Uid:')))),policy=os.sched_getscheduler(pid),priority=os.sched_getparam(pid).sched_priority,nice=os.getpriority(os.PRIO_PROCESS,pid),capabilities=next(l.split()[1] for l in status.splitlines() if l.startswith('CapEff:')))
   assert observed==dict(uids=[1000]*4,policy=os.SCHED_FIFO,priority=1,nice=0,capabilities='0000000000000000');assert not settings['gpr_environment'];save(ROOT/f'{index}-observed.json',observed);rc=child.wait();assert rc==0,('capture exit',mode,rc)
  save(ROOT/f'{index}-thermal-after.json',dict(millidegrees_c=Path('/sys/class/thermal/thermal_zone0/temp').read_text().strip(),throttled=subprocess.check_output(['vcgencmd','get_throttled'],text=True).strip()))
  events=[json.loads(l) for l in (ROOT/f'{index}.jsonl').read_text().splitlines() if l.startswith('{')];verified=bench.verify(clip,events,metadata,expected,offline);assert verified['preview']['background_requested']==0
  if mode in ('baseline','streamed'):assert verified['preview']['streamed_inverse'] is True and verified['preview']['stream_buffer_bytes']>0 and not verified['preview']['reconstruction_scratch_bytes']
  row=dict(index=index,mode=mode,command=command,observed=observed,launch=settings,verified=verified,clip_bytes=clip.stat().st_size,clip_deleted_after_verification=False);report['runs'].append(row);save(ROOT/'receipt.json',report);clip.unlink();row['clip_deleted_after_verification']=True;save(ROOT/'receipt.json',report)
  print(json.dumps(dict(event='verified',index=index,mode=mode,frames=verified['frames_verified'],durable_fps=verified['capture']['durable_fps'],encode_median_ms=verified['capture']['encode_median_ms'],floor=verified['floor'])),flush=True)
 report.update(complete=True,streamed_fixed_repeats_passed=all(r['verified']['floor']['recording'] and r['verified']['floor']['preview'] for r in report['runs'] if r['mode']=='streamed'));save(ROOT/'receipt.json',report)
if __name__=='__main__':main()
