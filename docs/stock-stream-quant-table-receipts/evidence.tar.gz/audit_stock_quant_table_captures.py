"""Audit both frozen capture protocols and their exact measured source snapshots."""
from pathlib import Path
import hashlib,json,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_quant_table_20261031');REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-stream-quant-table-20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 results=[]
 for sub,driver,order in [('native-abba','benchmark_stock_quant_table_capture.py',['baseline','streamed','streamed','baseline']),('native-final','benchmark_stock_quant_table_final_capture.py',['streamed','streamed'])]:
  d=ROOT/sub;p=json.loads((d/'protocol.json').read_text());r=json.loads((d/'receipt.json').read_text());assert r['complete'] and r['protocol_sha256']==sha(d/'protocol.json');assert p['order']==order and p['attempts_per_run']==600;assert sha(Path('analysis')/driver)==p['driver_sha256']
  for name,digest in p['uncommitted_integration_source'].items():
   snapshot=(ROOT/'final-source'/name) if sub=='native-final' else ROOT/name
   assert sha(snapshot if snapshot.exists() else REPO/name)==digest,name
  for name,digest in p['verifier_sources'].items():assert sha(REPO/'tools'/name)==digest
  rows=[]
  for i,run in enumerate(r['runs']):
   assert (run['index'],run['mode'])==(i,order[i]);events=[json.loads(l) for l in (d/f'{i}.jsonl').read_text().splitlines() if l.startswith('{')];frames=[e for e in events if e['event']=='frame'];previews=[e for e in events if e['event']=='preview'];v=run['verified'];c=next(e for e in events if e['event']=='summary');q=next(e for e in events if e['event']=='preview_summary');assert c==v['capture'] and q==v['preview'] and c['complete'];assert len(frames)==len(previews)==v['frames_verified']==c['written']==c['accepted']==q['rendered']==q['offered'];assert c['attempts']==600==len(frames)+c['overruns'];assert not q['discarded']
   assert c['deadline_misses']==sum(x['deadline_missed'] for x in frames);late=sum(x['capture_to_sink_ms']>50 for x in previews);floor=dict(recording=not c['overruns'] and not c['deadline_misses'] and c['durable_fps']>=20,preview=len(previews)==600 and not late,preview_late_deliveries=late,deadline_ms=50.0);assert v['floor']==floor
   assert abs(sorted(x['encode_ms'] for x in frames)[int((len(frames)-1)*.5)]-c['encode_median_ms'])<.0002;assert [x['index'] for x in frames]==list(range(len(frames)));fm={x['index']:x for x in frames}
   for x in previews:assert x['timestamp_ns']==fm[x['index']]['timestamp_ns'] and x['width']==1024 and x['height']==768
   assert run['observed']==dict(uids=[1000]*4,policy=1,priority=1,nice=0,capabilities='0000000000000000');assert run['clip_deleted_after_verification'] and run['clip_bytes']>c['payload_bytes'] and len(v['clip_sha256'])==64
   for k in ['all_payloads_exact_independent_stock','all_source_calibration_exact','all_delivered_preview_pixels_exact_offline','end_marker_verified']:assert v[k]
   assert q['streamed_inverse'] and q['stream_buffer_bytes']==(4843522 if run['mode']=='baseline' else 4917214) and not q['reconstruction_scratch_bytes'];sources={e['index']:e['source_index'] for e in previews}
   rows.append(dict(index=i,mode=run['mode'],frames=len(frames),durable_fps=c['durable_fps'],encode_median_ms=c['encode_median_ms'],late_writes=c['deadline_misses'],late_previews=late,workspace_bytes=c['workspace_peak_bytes'],preview_sample_buffer_bytes=q['stream_buffer_bytes'],peak_rss_bytes=c['peak_rss_bytes'],floor=floor,per_source_encode_median_ms={str(s):statistics.median(e['encode_ms'] for e in frames if sources[e['index']]==s) for s in (0,1)}))
  passed=all(e['floor']['recording'] and e['floor']['preview'] for e in rows if e['mode']=='streamed');assert r['streamed_fixed_repeats_passed']==passed;results.append(dict(protocol=sub,frames_verified_before_deletion=sum(e['frames'] for e in rows),strict_combined_floor_passed=passed,runs=rows))
 out=dict(complete=True,driver_sha256=sha(Path(__file__)),scope='Saved protocol/source/event/deadline audit. Full clip bytes/calibration/attemptPTS/CRC/pixels/END3 verified by bound producer before deletion, not re-read from deleted clips.',protocols=results);(ROOT/'capture-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
