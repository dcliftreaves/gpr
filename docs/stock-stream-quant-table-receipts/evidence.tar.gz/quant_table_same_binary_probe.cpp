#include "vc5_encoder.h"
#include "vc5_decoder.h"
#include "gpr_preview_stream.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"probe line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
struct base_stream;
extern "C" {
int base_create(uint32_t,uint32_t,size_t,base_stream**);
int base_push(base_stream*,const vc5_preview_row*);
int base_finish(base_stream*,gpr_preview_wavelet_planes*);
int base_reset(base_stream*);
void base_destroy(base_stream*);
}
struct Rows{base_stream *base;gpr_preview_stream *candidate;bool use_candidate;static void accept(void *p,const vc5_preview_row *r){auto&v=*static_cast<Rows*>(p);CHECK(!(v.use_candidate?gpr_preview_stream_push(v.candidate,r):base_push(v.base,r)));}};
static std::vector<unsigned char> read(const char*p){FILE*f=fopen(p,"rb");CHECK(f);CHECK(!fseek(f,0,SEEK_END));long n=ftell(f);CHECK(n>0);rewind(f);std::vector<unsigned char>b(n);CHECK(fread(b.data(),1,b.size(),f)==b.size());CHECK(!fclose(f));return b;}
int main(int argc,char**argv){
 CHECK(argc==3);auto raw=read(argv[1]),ref=read(argv[2]);CHECK(raw.size()==4096u*3072*2);
 vc5_encoder_parameters p;vc5_encoder_parameters_set_default(&p);p.input_width=4096;p.input_height=3072;p.input_pitch=8192;p.pixel_format=VC5_ENCODER_PIXEL_FORMAT_RGGB_14;p.quality_setting=VC5_ENCODER_QUALITY_SETTING_FS1;
 gpr_buffer reference={ref.data(),ref.size()},input={raw.data(),raw.size()};gpr_rgb_buffer expected[3]={};vc5_decoder_parameters dp;vc5_decoder_parameters_set_default(&dp);dp.mem_alloc=malloc;dp.mem_free=free;dp.rgb_bits=16;dp.rgb_resolution=GPR_RGB_RESOLUTION_QUARTER;
 for(unsigned c=0;c<3;++c)CHECK(!vc5_decoder_process_wavelet_channel(&dp,&reference,c,&expected[c]));
 Rows rows={};CHECK(!base_create(4096,3072,128u<<20,&rows.base));CHECK(!gpr_preview_stream_create(4096,3072,128u<<20,&rows.candidate));
 const bool order[8]={false,true,true,false,true,false,false,true};
 for(unsigned block=0;block<8;++block)for(unsigned iteration=0;iteration<16;++iteration){
  rows.use_candidate=order[block];gpr_buffer encoded={};gpr_preview_wavelet_planes planes={};auto begin=std::chrono::steady_clock::now();CHECK(!vc5_encoder_process_with_preview_rows(&p,&input,&encoded,nullptr,Rows::accept,&rows));CHECK(!(rows.use_candidate?gpr_preview_stream_finish(rows.candidate,&planes):base_finish(rows.base,&planes)));auto end=std::chrono::steady_clock::now();
  CHECK(encoded.size==ref.size()&&!memcmp(encoded.buffer,ref.data(),ref.size()));CHECK(planes.width==1024&&planes.height==768);
  for(unsigned c=0;c<3;++c)CHECK(planes.sample_count[c]*2==expected[c].size&&!memcmp(planes.samples[c],expected[c].buffer,expected[c].size));
  printf("{\"block\":%u,\"iteration\":%u,\"warmup\":%s,\"candidate\":%s,\"encode_preview_ms\":%.9f,\"payload_exact\":true,\"planes_exact\":true}\n",block,iteration,iteration==0?"true":"false",rows.use_candidate?"true":"false",std::chrono::duration<double,std::milli>(end-begin).count());fflush(stdout);
  free(encoded.buffer);CHECK(!(rows.use_candidate?gpr_preview_stream_reset(rows.candidate):base_reset(rows.base)));
 }
 base_destroy(rows.base);gpr_preview_stream_destroy(rows.candidate);for(auto&e:expected)free(e.buffer);
}
