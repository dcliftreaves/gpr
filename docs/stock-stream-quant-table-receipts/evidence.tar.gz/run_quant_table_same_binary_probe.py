from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess,time
ROOT=Path('/mnt/ssd/gpr_work/stock-stream-quant-table-probe-20261031');REPO=Path('/mnt/ssd/gpr_work/stock-stream-quant-table-20261031');BASE=Path('/mnt/ssd/gpr_work/stock-stream-fused-dequant-20261031');SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 ROOT.mkdir(exist_ok=False);shutil.copyfile('/tmp/quant_table_same_binary_probe.cpp',ROOT/'probe.cpp');shutil.copyfile(BASE/'source/lib/gpr_video/gpr_preview_stream.cpp',ROOT/'baseline.cpp');shutil.copyfile(Path(__file__),ROOT/'driver.py')
 include=['-I'+str(REPO/'source/lib'/p) for p in ['vc5_encoder','vc5_common','common/public','vc5_decoder','gpr_video']];flags=['-O3','-DNDEBUG','-flto=auto','-fno-fat-lto-objects'];defs=['-DGPR_JPEG_AVAILABLE=0','-DGPR_READING=1','-DGPR_WRITING=1','-DNEON=1']
 rename=['-Dgpr_preview_stream=base_stream','-DRowChannel=BaseRowChannel','-DInvalidRows=BaseInvalidRows','-Drequire_rows=base_require_rows']+['-Dgpr_preview_stream_'+x+'=base_'+x for x in ['create','push','finish','reset','destroy','buffer_bytes']];commands=[]
 for name,extra in [('baseline',rename),('probe',[])]:
  command=['/usr/bin/c++',*flags,*defs,*include,*extra,'-c',str(ROOT/(name+'.cpp')),'-o',str(ROOT/(name+'.o'))];commands.append(command)
  with (ROOT/(name+'-build.log')).open('w') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
 command=shlex.split((REPO/'build/CMakeFiles/wavelet_stream_inverse_contract.dir/link.txt').read_text());command[command.index('CMakeFiles/wavelet_stream_inverse_contract.dir/tests/wavelet_stream_inverse_contract.cpp.o')]=str(ROOT/'probe.o');command.insert(command.index(str(ROOT/'probe.o')),str(ROOT/'baseline.o'));command[command.index('-o')+1]=str(ROOT/'probe');commands.append(command)
 with (ROOT/'link.log').open('w') as f:subprocess.run(command,cwd=REPO/'build',stdout=f,stderr=subprocess.STDOUT,check=True)
 original=json.loads((SEED/'protocol.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('GPR_')};env.update({k:'1' for k in ['GPR_STREAM_UNPACK','GPR_BAND_STREAM','GPR_CHANNEL_ASM','GPR_PIN_CHANNELS','GPR_DIRECT_BANDS','GPR_COMPACT_BANDS']})
 protocol=dict(schema='gpr.stock_quant_table_same_binary.v1',driver_sha256=sha(Path(__file__)),source_sha256={n:sha(ROOT/n) for n in ['probe.cpp','baseline.cpp']},candidate_sha256={n:sha(REPO/n) for n in ['source/lib/gpr_video/gpr_preview_stream.cpp','source/lib/gpr_video/gpr_preview_dequantize.h']},binary_sha256=sha(ROOT/'probe'),compile_commands=commands,compiler=subprocess.check_output(['/usr/bin/c++','--version'],text=True),source_protocol_sha256=sha(SEED/'protocol.json'),inputs=original['inputs'],reference_payloads=original['reference_payloads'],environment={k:v for k,v in env.items() if k.startswith('GPR_')},order=[False,True,True,False,True,False,False,True],iterations_per_block=16,excluded_warmup_per_block=1,uid=os.getuid(),scheduler=os.sched_getscheduler(0),nice=os.getpriority(os.PRIO_PROCESS,0),scope='Same process public encoder plus two separately named production streaming inverse implementations. Stream objects persist, payload allocations/encoding/callback/finish inside timing; reset/independent payload/decoded-plane comparisons outside timing. Native sources, no capture/pacing/render/storage/finalfsync. No sustained-rate claim. Candidate table memory adds73692B.',libraries_sha256={str(p.relative_to(REPO/'build')):sha(p) for p in (REPO/'build/source/lib').rglob('*.a')})
 assert protocol['uid']==1000 and protocol['scheduler']==os.SCHED_OTHER and protocol['nice']==0;save(ROOT/'protocol.json',protocol)
 for i,item in enumerate(original['inputs']):
  raw=SEED/item['raw_file'];ref=SEED/f'reference-{i}.vc5';assert sha(raw)==item['raw_sha256'] and sha(ref)==original['reference_payloads'][i]['sha256']
  with (ROOT/f'{i}.jsonl').open('w') as out,(ROOT/f'{i}.stderr').open('w') as err:subprocess.run([str(ROOT/'probe'),str(raw),str(ref)],stdout=out,stderr=err,env=env,check=True)
  events=[json.loads(l) for l in (ROOT/f'{i}.jsonl').read_text().splitlines()];assert len(events)==128
  for k,e in enumerate(events):assert (e['block'],e['iteration'],e['candidate'],e['warmup'])==(k//16,k%16,protocol['order'][k//16],k%16==0) and e['payload_exact'] and e['planes_exact']
  print('Verified source '+str(i),flush=True)
 save(ROOT/'complete.json',dict(complete=True,protocol_sha256=sha(ROOT/'protocol.json')))
if __name__=='__main__':main()
