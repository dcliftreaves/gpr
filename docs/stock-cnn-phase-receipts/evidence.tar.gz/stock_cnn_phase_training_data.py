"""Matched stock BIBO SR-only, frozen-cleanup, and joint-cleanup/SR study."""
from pathlib import Path
import datetime,hashlib,json,shutil,sys,time
import numpy as np
import torch
import torch.nn.functional as F
import tifffile
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'))
import raw_media,stock_video,train_stock_sr
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');ROOT=BASE/'stock_cnn_joint_20261031'
DATA=[('nikon',BASE/'stock_sr_20261028/dataset'),('camera',BASE/'stock_sr_mission_calibrated_20261031/dataset')]
CLEAN=REPO/'models/stock-q3-rggb14-cleanup/selected.pt';SR=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt'
PEAK=16383.
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def rounded(x):
    y=(x*PEAK+.5).floor().clamp(0,PEAK)/PEAK
    return x+(y-x).detach()
def load_training():
    torch.set_num_threads(4);device=torch.device('mps');arrays=[];patches={};domains=[];validation=[];source_rows=[]
    # Extend actual decoded sensor inputs to 256 planes: the two-stage receptive
    # field exceeds the old 32-plane patch halo. Preserve target cores/splits.
    for domain,directory in DATA:
        info=json.loads((directory/'dataset.json').read_text());assert info['complete']
        assert sha(directory/'inputs.npy')==info['input_sha256'] and sha(directory/'targets.npy')==info['target_sha256']
        di=len(arrays);inputs=np.load(directory/'inputs.npy',mmap_mode='r');targets=np.load(directory/'targets.npy',mmap_mode='r');arrays.append((inputs,targets));training=[]
        for si,source in enumerate(info['sources']):
            if source['split']=='test':assert source['patch_count']==0 and source['patch_start'] is None;continue
            path=Path(source['path']);assert sha(path)==source['sha256'];meta=raw_media.extract(path,14);tags={r['code']:r for r in meta['image']}
            assert meta['cfa']=='RGGB';black=np.array(raw_media.values(tags[50714]),np.float32);white=float(raw_media.values(tags[50717])[0]);neutral=np.array(raw_media.values(tags[50728]),np.float32);wb=neutral[1]/neutral;wbg=np.array([wb[0],wb[1],wb[1],wb[2]],np.float32)
            decoded=directory/f'source-{si:03d}/decoded.raw'
            if decoded.exists():
                assert sha(decoded)==source['low_decoded_raw_sha256'];raw=np.memmap(decoded,dtype='<u2',mode='r',shape=(source['height']//2,source['width']//2))
            else:
                dng=directory/f'source-{si:03d}/decoded.dng'
                with tifffile.TiffFile(dng) as f:raw=f.asarray()
                assert hashlib.sha256(raw.tobytes()).hexdigest()==source['low_decoded_raw_sha256']
            planes=np.stack([raw[c//2::2,c%2::2] for c in range(4)]);ph,pw=planes.shape[-2:];assert ph>=256 and pw>=256
            planes=np.pad(planes,((0,0),(0,(-ph)%8),(0,(-pw)%8)),mode='edge')
            keys=[]
            for k,(y,x) in enumerate(source['low_plane_yx']):
                idx=source['patch_start']+k;key=(di,idx);keys.append(key)
                assert np.array_equal(planes[:,y:y+128,x:x+128],inputs[idx])
                ya=min(max(y-64,0),planes.shape[-2]-256);xa=min(max(x-64,0),planes.shape[-1]-256);assert not (ya%8 or xa%8)
                # Original high-target core64:192 is unchanged. Global-frame
                # boundary convolutions remain real boundaries, not fake padding.
                oy=2*(y-ya)+64;ox=2*(x-xa)+64
                patches[key]=(planes,ya,xa,oy,ox,min(256,ph-ya),min(256,pw-xa),black,white,wbg,domain+':'+source['group'])
            (training if source['split']=='train' else validation).append(keys)
            source_rows.append(dict(domain=domain,source_sha256=source['sha256'],split=source['split'],group=source['group'],patches=len(keys),decoded_counts_sha256=source['low_decoded_raw_sha256']))
        domains.append(training)
    validation=[k for group in validation for k in group];assert len(validation)==320 and [len(d) for d in domains]==[8,28]
    return arrays,patches,domains,source_rows
