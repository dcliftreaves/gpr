"""Describe residual amplitude after frozen phase study; no model selection."""
from pathlib import Path
import datetime,hashlib,json,sys
import numpy as np
import torch
import torch.nn.functional as F
from stock_cnn_phase_validation import load_validation,stock_video,REPO,PEAK
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_phase_training_20261031');OUT=ROOT/'residual-energy'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);r=json.loads((ROOT/'results.json').read_text());assert r['complete'];b=json.loads((ROOT/'baseline.json').read_text());_,_,_,items=load_validation();device=torch.device('mps');torch.set_num_threads(4)
 family=[dict(name='bicubic',path=None,metrics=b['bicubic']),dict(name='supplied',path=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt',metrics=b['supplied_sr'],phase=b['phase'])]+[dict(name=f'phase-{a["phase_weight"]}-{c["step"]}',path=ROOT/f'phase-{a["phase_weight"]}'/f'sr-{c["step"]}.pt',metrics=c['metrics'],phase=c['phase']) for a in r['arms'] for c in a['checkpoints']]
 protocol=dict(schema='gpr.stock_cnn_phase_energy_protocol.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_results_sha256=sha(ROOT/'results.json'),driver_sha256=sha(Path(__file__)),settings=[dict(name=x['name'],checkpoint_sha256=sha(x['path']) if x['path'] else None) for x in family],scope='Post-disqualification descriptive analysis only: compare each frozen predictedcount residual from identical bicubic cores with suppliedmodel residual; report amplitude ratio, regression projection and phaseMSE/residualMSE. No strength candidate, tuning, qualification or actualvideoqualityclaim. Raw core outputs externalonly, hashes must matchoriginalstudy.')
 save(OUT/'protocol.json',protocol);results=[]
 with torch.inference_mode():
  for case in family:
   model=stock_video.load_cnn(None,case['path'],device)[0] if case['path'] else None;file=OUT/(case['name']+'.raw')
   with file.open('wb') as f:
    for start in range(0,len(items),4):
     batch=items[start:start+4];x=torch.from_numpy(np.stack([e['input'] for e in batch]).astype(np.float32)/PEAK).to(device);out=F.interpolate(x,scale_factor=2,mode='bicubic',align_corners=False).clamp(0,1) if model is None else model(x)
     for j,e in enumerate(batch):
      y,z=e['crop'];counts=np.floor(out[j,:,y:y+128,z:z+128].cpu().numpy()*PEAK+.5).clip(0,PEAK).astype('<u2');f.write(counts.tobytes())
   assert sha(file)==case['metrics']['prediction_sha256'];del model;torch.mps.empty_cache()
   if case['name']=='bicubic':continue
   current=np.memmap(file,dtype='<u2',mode='r',shape=(320,4,128,128));bicubic=np.memmap(OUT/'bicubic.raw',dtype='<u2',mode='r',shape=current.shape);teacher=np.memmap(OUT/'supplied.raw',dtype='<u2',mode='r',shape=current.shape);stats={}
   for j,e in enumerate(items):
    a=current[j].astype(np.int64)-bicubic[j].astype(np.int64);t=teacher[j].astype(np.int64)-bicubic[j].astype(np.int64)
    for group in ['pooled',e['group']]:
     d=stats.setdefault(group,[0,0,0,0]);d[0]+=int(np.sum(a*a));d[1]+=int(np.sum(t*t));d[2]+=int(np.sum(a*t));d[3]+=a.size
   groups={g:dict(residual_mse_counts=s/n,amplitude_energy_ratio=s/st if st else None,projection_to_supplied=c/st if st else None,phase_mse_over_residual_energy={axis:case['phase']['groups'][g][axis]['mse_counts']/(s/n) if s else None for axis in ['0,1','1,0']}) for g,(s,st,c,n) in stats.items()};results.append(dict(name=case['name'],prediction_sha256=sha(file),groups=groups));print(case['name'],groups['pooled'],flush=True)
 save(OUT/'results.json',dict(complete=True,protocol_sha256=sha(OUT/'protocol.json'),results=results,selection=False))
if __name__=='__main__':main()
