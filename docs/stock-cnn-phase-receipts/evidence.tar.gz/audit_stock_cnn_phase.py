"""Repeat fidelity scoring; independently measure shifts with edge replication."""
from pathlib import Path
import hashlib,json,math,shutil
import numpy as np
import torch
from stock_cnn_phase_validation import load_validation,stock_video,REPO,PEAK
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_phase_training_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def phase_independent(model,items):
 totals={};hashes={};device=torch.device('mps')
 with torch.inference_mode():
  for start in range(0,len(items),4):
   batch=items[start:start+4];input_counts=np.stack([e['input'] for e in batch]);x=torch.from_numpy(input_counts.astype(np.float32)/PEAK).to(device);out=model(x).cpu().numpy();base=np.floor(out[:,:,192:320,192:320]*PEAK+.5).clip(0,PEAK).astype(np.int32)
   for dy,dx in [(0,1),(1,0),(0,8)]:
    # Different transformed edges from producer roll; receptive-field interior
    # must reproduce exactly without borrowing wrapped source samples.
    shifted=np.pad(input_counts,((0,0),(0,0),(dy,0),(dx,0)),mode='edge')[:,:,:256,:256];output=model(torch.from_numpy(shifted.astype(np.float32)/PEAK).to(device)).cpu().numpy();current=np.floor(output[:,:,192+2*dy:320+2*dy,192+2*dx:320+2*dx]*PEAK+.5).clip(0,PEAK).astype(np.int32);delta=current-base;label=f'{dy},{dx}';hashes.setdefault(label,hashlib.sha256()).update(delta.astype('<i4').tobytes())
    for row,error in zip(batch,delta):
     sse=sum(int(np.dot(line.astype(np.int64),line.astype(np.int64))) for line in error.reshape(-1,128));maximum=int(np.max(np.abs(error)))
     for group in ['pooled',row['group']]:
      d=totals.setdefault(group,{}).setdefault(label,[0,0,0]);d[0]+=sse;d[1]+=error.size;d[2]=max(d[2],maximum)
 return dict(groups={g:{n:dict(mse_counts=s/n0,max_abs_counts=m,count=n0) for n,(s,n0,m) in d.items()} for g,d in totals.items()},delta_sha256={k:v.hexdigest() for k,v in hashes.items()})
def main():
 p=json.loads((ROOT/'protocol.json').read_text());r=json.loads((ROOT/'results.json').read_text());b=json.loads((ROOT/'baseline.json').read_text());assert r['complete'] and not r['eligible'];assert r['protocol_sha256']==sha(ROOT/'protocol.json') and p['driver_sha256']==sha(ROOT/'train_stock_cnn_phase.py')
 for n,d in p['helper_sha256'].items():assert sha(ROOT/n)==d
 for n,d in p['runtime_sha256'].items():assert sha(REPO/'tools'/n)==d
 checkpoint=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt';assert sha(checkpoint)==p['model_sha256'];base=torch.load(checkpoint,map_location='cpu',weights_only=True);evaluate,_,_,items=load_validation();torch.set_num_threads(4);cases=[]
 model,_=stock_video.load_cnn(None,checkpoint,torch.device('mps'));assert evaluate(None,None)==b['bicubic'];assert evaluate(None,model)==b['supplied_sr'];assert phase_independent(model,items)==b['phase'];del model
 for arm in r['arms']:
  for c in arm['checkpoints']:
   path=ROOT/f'phase-{arm["phase_weight"]}'/f'sr-{c["step"]}.pt';assert sha(path)==c['checkpoint_sha256'];weights=torch.load(path,map_location='cpu',weights_only=True)
   for name,value in base['backbone_state'].items():
    if any(key in name for key in ['running_mean','running_var','num_batches_tracked']):assert torch.equal(value,weights['backbone_state'][name]),name
   for key in base:
    if key!='backbone_state':assert weights[key]==base[key]
   model,_=stock_video.load_cnn(None,path,torch.device('mps'));score=evaluate(None,model);assert score==c['metrics'];phase=phase_independent(model,items);assert phase==c['phase'];del model;torch.mps.empty_cache()
   bad=[label+':'+g+':'+n for label,key in [('bicubic','bicubic'),('supplied','supplied_sr')] for g,d in b[key]['regions'].items() for n,v in d.items() if score['regions'][g][n]>v];tonebad=[g for g,v in b['supplied_sr']['tone_proxy_mse'].items() if score['tone_proxy_mse'][g]>v];phasebad=[g+':'+n for g,d in b['phase']['groups'].items() for n,v in d.items() if n!='0,8' and phase['groups'][g][n]['mse_counts']>v['mse_counts']];gain=10*math.log10(b['supplied_sr']['regions']['pooled']['overall']/score['regions']['pooled']['overall']);assert bad==c['raw_regressions'] and tonebad==c['tone_proxy_regressions'] and phasebad==c['phase_regressions'];assert bad and not c['eligible'] and abs(gain-c['gain_db_vs_supplied'])<1e-14
   cases.append(dict(phase_weight=arm['phase_weight'],step=c['step'],prediction_sha256=score['prediction_sha256'],phase_delta_sha256=phase['delta_sha256'],raw_regressions=bad,tone_proxy_regressions=tonebad,phase_regressions=phasebad));print('Verified '+str((arm['phase_weight'],c['step'])),flush=True)
 audit=dict(schema='gpr.stock_cnn_phase_audit.v1',complete=True,driver_sha256=sha(Path(__file__)),results_sha256=sha(ROOT/'results.json'),settings_reinferred=8,validation_patches=320,all_raw_proxy_scores_and_prediction_hashes_reproduced=True,all_phase_scores_and_delta_hashes_exact_with_independent_replicated_edges=True,all_bn_running_buffers_unchanged=True,all_checkpoints_disqualified_by_raw_guard=True,selected=None,cases=cases);(ROOT/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
if __name__=='__main__':main()
