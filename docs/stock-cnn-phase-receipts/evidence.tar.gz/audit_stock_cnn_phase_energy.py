from pathlib import Path
import hashlib,json
import numpy as np
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_phase_training_20261031');OUT=ROOT/'residual-energy'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=json.loads((ROOT/'protocol.json').read_text());a=json.loads((OUT/'protocol.json').read_text());r=json.loads((OUT/'results.json').read_text());assert r['complete'] and r['protocol_sha256']==sha(OUT/'protocol.json');assert a['parent_results_sha256']==sha(ROOT/'results.json');groups=[]
 for dataset in p['datasets']:
  d=Path(dataset['path']);assert sha(d/'dataset.json')==dataset['manifest_sha256'];manifest=json.loads((d/'dataset.json').read_text())
  for source in manifest['sources']:
   if source['split']=='validation':groups += [dataset['domain']+':'+source['group']]*source['patch_count']
 assert len(groups)==320;shape=(320,4,128,128);bicubic=np.memmap(OUT/'bicubic.raw',dtype='<u2',mode='r',shape=shape);supplied=np.memmap(OUT/'supplied.raw',dtype='<u2',mode='r',shape=shape);rows=[]
 for case in r['results']:
  path=OUT/(case['name']+'.raw');assert sha(path)==case['prediction_sha256'];current=np.memmap(path,dtype='<u2',mode='r',shape=shape);totals={}
  for i,g in enumerate(groups):
   x=current[i].astype(np.int64);b=bicubic[i].astype(np.int64);s=supplied[i].astype(np.int64);xx=int(np.sum(x*x));bb=int(np.sum(b*b));ss=int(np.sum(s*s));xb=int(np.sum(x*b));sb=int(np.sum(s*b));xs=int(np.sum(x*s));energy=xx+bb-2*xb;teacher=ss+bb-2*sb;dot=xs-xb-sb+bb
   for group in ['pooled',g]:
    d=totals.setdefault(group,[0,0,0,0]);d[0]+=energy;d[1]+=teacher;d[2]+=dot;d[3]+=x.size
  for group,(e,t,dot,n) in totals.items():
   actual=case['groups'][group];assert actual['residual_mse_counts']==e/n and actual['amplitude_energy_ratio']==e/t and actual['projection_to_supplied']==dot/t
  rows.append(dict(setting=case['name'],prediction_sha256=case['prediction_sha256'],all_energy_and_projection_values_exact=True))
 result=dict(complete=True,driver_sha256=sha(Path(__file__)),protocol_sha256=sha(OUT/'protocol.json'),results_sha256=sha(OUT/'results.json'),samples_per_setting=20971520,settings=7,independent_expanded_integer_cross_terms_exact=True,rows=rows,selection=False);(OUT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Seven frozen residual-energy settings independently exact.')
if __name__=='__main__':main()
