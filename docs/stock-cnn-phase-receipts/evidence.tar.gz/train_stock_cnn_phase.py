"""Source-balanced, region-relative fidelity and translation-consistency training."""
from pathlib import Path
import datetime,hashlib,json,math,shutil,sys,time
import numpy as np
import torch
import torch.nn.functional as F
from stock_cnn_phase_training_data import load_training,REPO,SR,PEAK
from stock_cnn_phase_validation import load_validation,stock_video
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_phase_training_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def counts(x):
 z=x*PEAK;r=torch.floor(z+.5).clamp(0,PEAK);return z+(r-z).detach()
def masks(ref):
 lo=np.percentile(ref,10);hi=np.percentile(ref,90);g=np.zeros_like(ref);g[:,:,1:]+=np.abs(ref[:,:,1:]-ref[:,:,:-1]);g[:,1:,:]+=np.abs(ref[:,1:,:]-ref[:,:-1,:]);return np.stack([np.ones_like(ref,bool),ref<=lo,ref>=hi,g>=np.percentile(g,90)])
def phase_scores(model,items,device):
 stats={};digests={};offsets=[(0,1),(1,0),(0,8)]
 with torch.inference_mode():
  for start in range(0,len(items),4):
   batch=items[start:start+4];x=torch.from_numpy(np.stack([r['input'] for r in batch]).astype(np.float32)/PEAK).to(device);p=counts(model(x))[:,:,192:320,192:320].cpu().numpy().astype(np.int32)
   for dy,dx in offsets:
    shifted=counts(model(torch.roll(x,(dy,dx),(-2,-1))))[:,:,192+2*dy:320+2*dy,192+2*dx:320+2*dx].cpu().numpy().astype(np.int32);delta=shifted-p;name=f'{dy},{dx}';digests.setdefault(name,hashlib.sha256()).update(delta.astype('<i4').tobytes())
    for r,d in zip(batch,delta):
     for group in ['pooled',r['group']]:
      v=stats.setdefault(group,{}).setdefault(name,[0,0,0]);v[0]+=int(np.square(d.astype(np.int64)).sum());v[1]+=d.size;v[2]=max(v[2],int(np.abs(d).max()))
 return dict(groups={g:{n:dict(mse_counts=s/n0,max_abs_counts=m,count=n0) for n,(s,n0,m) in entries.items()} for g,entries in stats.items()},delta_sha256={k:v.hexdigest() for k,v in digests.items()})
def main():
 ROOT.mkdir(exist_ok=False)
 for name in ['train_stock_cnn_phase.py','stock_cnn_phase_training_data.py','stock_cnn_phase_validation.py']:shutil.copyfile(Path(__file__).with_name(name),ROOT/name)
 arrays,patches,domains,sources=load_training();evaluate,parent_protocol,parent_report,validation=load_validation();device=torch.device('mps');torch.set_num_threads(4);seed=20261112;steps=600;checkpoints=[200,600];family=[0.,.1,1.]
 protocol=dict(schema='gpr.stock_cnn_phase_training_protocol.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),helper_sha256={n:sha(Path(__file__).with_name(n)) for n in ['stock_cnn_phase_training_data.py','stock_cnn_phase_validation.py']},source_revision='eb3062bfd285c1f4971e5e610071351a0d184b25',model_sha256=sha(SR),runtime_sha256={n:sha(REPO/'tools'/n) for n in ['stock_video.py','stock_cnn_models.py']},sources=sources,datasets=parent_protocol['datasets'],seed=seed,steps_per_arm=steps,checkpoints=checkpoints,phase_weights=family,learning_rate=1e-5,weight_decay=0,batch=4,sampling='Two distinct Nikon and two distinct camera training sources, one patch each. Identical source/patch/shift RNG sequence for every arm. Train/validation scene split unchanged; final references unused.',training_input='ActualstockQ3 decoded RGGB14, originalcounts/16383, extended256packedplanes context, target128plane core unchanged. Source and originalpatch hashes/equality checked beforetraining.',training_raw_loss='Perpatch fourregion MSE/maximum(frozen supplied model roundedcount MSE in same region,1count^2), mean over regions and batch. Targets and masks fixed by reference ONLY on training patches. Predictedcounts use exact halfup14bit roundingforward with straightthroughderivative. This normalizes relative RAW error so lowerror shadows have equal objective presence.',training_phase_loss='Mean squared floatingoutputcount disagreement /4 over output[96:416,96:416] versus shiftedoutput[96+2dy:416+2dy,96+2dx:416+2dx], where torch.roll input by independently sampled0..7 packedpixels, reject(0,0). Interior48packedpixel margins keep wrap/realframeedges beyond the <=28packedpixel receptive radius plus7shift. No shifts/permutations across CFAchannels. Same shiftedforward in all arms.',objective='relativeRAW + phase_weight*phaseLoss; fixed BN running statistics, affine/convolution weights trainable. No learned gate, strength sweep, checkpoint interpolation or output smoothing.',validation='Same320validationcores; all pooled/pergroup fourRAWregions<=bothbicubicandsuppliedSR, toneWBproxy<=suppliedSR eachgroup, strict pooled RAW gain. Additionally both onepackedpixel shift MSE<=supplied in everygroup andstrictpooledreduction forbothaxes. Period8alignedoffset is numericalcontrol <=1countmaximum. Every eligiblecheckpoint advances to all10completevalidationimages and actualrendering beforefreeze/final/backend/Piapproval.',phase_evaluator='Integerroundedoutputcount differences, fixedoutputcore192:320, offsets(0,1),(1,0),(0,8)packedpixels, noflow/interpolation. Compare withintheseprotocols only; this syntheticpatchdiagnostic is not a real-video metric.',limitations=['Single seed and shortmatchedbudget.','Historical pretraining/validation reuse; camera referencecounts alreadycompressed, notsensortruth.','Phase score reduction may remove usefuldetails; RAW/renderedguards remain mandatory.','No actual motion/temporal/render/backend/Pi quality approval from patch scores.'],quality_approval=False,torch=torch.__version__)
 save(ROOT/'protocol.json',protocol);teacher,_=stock_video.load_cnn(None,SR,device)
 for p in teacher.parameters():p.requires_grad_(False)
 bicubic=evaluate(None,None);supplied=evaluate(None,teacher);old=json.loads((Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_joint_20261031')/'baseline.json').read_text());assert bicubic['regions']==old['bicubic']['regions'] and supplied['regions']==old['supplied_sr']['regions'];basephase=phase_scores(teacher,validation,device);assert all(v['max_abs_counts']<=1 for g,d in basephase['groups'].items() for k,v in d.items() if k=='0,8');save(ROOT/'baseline.json',dict(bicubic=bicubic,supplied_sr=supplied,phase=basephase))
 def tensors(keys):
  x=[];targets=[];positions=[];region_masks=[]
  for key in keys:
   planes,ya,xa,oy,ox,vh,vw,*_=patches[key];assert min(vh,vw)>=249;x.append(planes[:,ya:ya+256,xa:xa+256]);ref=np.array(arrays[key[0]][1][key[1],:,64:192,64:192],np.float64);targets.append(ref);region_masks.append(masks(ref));positions.append((oy,ox))
  return (torch.from_numpy(np.stack(x).astype(np.float32)/PEAK).to(device),torch.from_numpy(np.stack(targets).astype(np.float32)).to(device),torch.from_numpy(np.stack(region_masks)).to(device),positions)
 def core(out,positions):return torch.stack([out[i,:,y:y+128,x:x+128] for i,(y,x) in enumerate(positions)])
 report=dict(complete=False,protocol_sha256=sha(ROOT/'protocol.json'),arms=[],quality_approval=False);start=time.perf_counter()
 for weight in family:
  rng=np.random.default_rng(seed);torch.manual_seed(seed);model,_=stock_video.load_cnn(None,SR,device);buffers={n:v.detach().cpu().clone() for n,v in model.named_buffers()};optimizer=torch.optim.AdamW(model.parameters(),lr=protocol['learning_rate'],weight_decay=0);arm=ROOT/f'phase-{weight}';arm.mkdir();row=dict(phase_weight=weight,checkpoints=[]);report['arms'].append(row)
  for step in range(1,steps+1):
   keys=[]
   for domain in domains:
    for index in rng.choice(len(domain),2,replace=False):
     source=domain[int(index)];keys.append(source[int(rng.integers(len(source)))])
   dy,dx=0,0
   while not (dy or dx):dy,dx=map(int,rng.integers(0,8,size=2))
   x,target,mask,positions=tensors(keys);optimizer.zero_grad(set_to_none=True)
   with torch.no_grad():anchor=counts(core(teacher(x),positions));denom=(((anchor-target).square()[:,None]*mask).sum((2,3,4))/mask.sum((2,3,4))).clamp_min(1)
   output=model(x);pred=counts(core(output,positions));relative=(((pred-target).square()[:,None]*mask).sum((2,3,4))/mask.sum((2,3,4))/denom).mean();shifted=model(torch.roll(x,(dy,dx),(-2,-1)));phase=((output[:,:,96:416,96:416]-shifted[:,:,96+2*dy:416+2*dy,96+2*dx:416+2*dx])*PEAK).square().mean()/4;loss=relative+weight*phase;assert torch.isfinite(loss).item();loss.backward();optimizer.step()
   if step%100==0:print(json.dumps(dict(weight=weight,step=step,relative_loss=float(relative.item()),phase_loss=float(phase.item()),elapsed_s=time.perf_counter()-start)),flush=True)
   if step in checkpoints:
    for n,v in model.named_buffers():assert torch.equal(v.detach().cpu(),buffers[n])
    checkpoint=torch.load(SR,map_location='cpu',weights_only=True);checkpoint['backbone_state']={k:v.detach().cpu() for k,v in model.backbone.state_dict().items()};checkpoint.update(phase_protocol_sha256=sha(ROOT/'protocol.json'),phase_weight=weight,phase_step=step,quality_approval=False);path=arm/f'sr-{step}.pt';torch.save(checkpoint,path);score=evaluate(None,model);phase_score=phase_scores(model,validation,device)
    bad=[label+':'+g+':'+r for label,base in [('bicubic',bicubic),('supplied',supplied)] for g,d in base['regions'].items() for r,v in d.items() if score['regions'][g][r]>v];tonebad=[g for g,v in supplied['tone_proxy_mse'].items() if score['tone_proxy_mse'][g]>v];phasebad=[g+':'+n for g,d in basephase['groups'].items() for n,v in d.items() if n!='0,8' and phase_score['groups'][g][n]['mse_counts']>v['mse_counts']];gain=10*math.log10(supplied['regions']['pooled']['overall']/score['regions']['pooled']['overall']);phasegain=all(phase_score['groups']['pooled'][n]['mse_counts']<basephase['groups']['pooled'][n]['mse_counts'] for n in ['0,1','1,0']);assert all(d['0,8']['max_abs_counts']<=1 for d in phase_score['groups'].values());eligible=not bad and not tonebad and not phasebad and gain>0 and phasegain
    result=dict(step=step,checkpoint_sha256=sha(path),metrics=score,phase=phase_score,raw_regressions=bad,tone_proxy_regressions=tonebad,phase_regressions=phasebad,gain_db_vs_supplied=gain,eligible=eligible,elapsed_s=time.perf_counter()-start);row['checkpoints'].append(result);save(ROOT/'results.json',report);print(json.dumps(dict(weight=weight,step=step,gain_db=gain,eligible=eligible,raw_regressions=bad,tone_regressions=tonebad,phase_regressions=phasebad,phase_pooled=phase_score['groups']['pooled'])),flush=True)
  del model,optimizer;torch.mps.empty_cache()
 report.update(complete=True,elapsed_s=time.perf_counter()-start,eligible=[dict(phase_weight=a['phase_weight'],step=c['step']) for a in report['arms'] for c in a['checkpoints'] if c['eligible']]);save(ROOT/'results.json',report);print(json.dumps(dict(complete=True,elapsed_s=report['elapsed_s'],eligible=report['eligible'])),flush=True)
if __name__=='__main__':main()
