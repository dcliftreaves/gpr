"""Synthetic Bayer-preserving translation diagnostic, not a motion quality approval."""
from pathlib import Path
import datetime,hashlib,json,shutil,sys,time
import numpy as np
import torch
import torch.nn.functional as F
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'));import stock_video
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');SOURCE=BASE/'stock_selected_video_chain_20261031';ROOT=BASE/'stock_cnn_translation_20261031';MODEL=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
class Bicubic(torch.nn.Module):
 def forward(self,x):return F.interpolate(x,scale_factor=2,mode='bicubic',align_corners=False).clamp(0,1)
def main():
 ROOT.mkdir(exist_ok=False);shutil.copyfile(Path(__file__),ROOT/Path(__file__).name);torch.set_num_threads(4);device=torch.device('mps');offsets=[(0,0),(0,2),(2,0),(0,16)]
 source_inputs=[SOURCE/f'extracted/{i:06d}.raw' for i in range(2)];assert [sha(p) for p in source_inputs]==['6555fcf0c4715b15e55e2e2b91c565b559b3701fcfa34201b09b37214af41472','1f421c6e09da0ad3a90376c702ac998d783578ed5d1cf881e22ff32e51b9ff85'];assert sha(MODEL)=='f7bda0449b94be4ebd3617297b9dee04506b00e38788dba2d0b04eb71fdaa2f4'
 protocol=dict(schema='gpr.stock_cnn_translation_protocol.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),sources=[dict(path=str(p),sha256=sha(p)) for p in source_inputs],source_capture_sha256=sha(SOURCE/'capture.gvid'),checkpoint_sha256=sha(MODEL),runtime_sha256=sha(REPO/'tools/stock_video.py'),model_architecture_sha256=sha(REPO/'tools/stock_cnn_models.py'),geometry=[4096,3072],output_scale=2,tile=256,halo=64,device=str(device),torch=torch.__version__,source_sensor_offsets_yx=offsets,transform='Exact even-sensor-pixel translations right/down with edge replication before inference. CFAphase preserved. Existing decoded RAW counts shifted, no new codec encode/decode, no sensor noise/blur/occlusion. Native source is compressed camera reference, not sensor truth.',alignment='Compare shifted output at[y+2dy,x+2dx] with unshifted output[y,x], fixed512sensor-output-pixel margin on allfourborders. No interpolation/flow/reference fitting. All supported count samples and allfour Bayer phases included.',hypothesis='Bicubic should preserve integer translation to existing1countnumericbudget. Onepackedpixel shifts test U-Net spatialphase sensitivity; eightpackedpixel shift is period-aligned control. No preregistered model quality pass claimed from syntheticstationaryscene.',selection='No model selection/training/final-reference quality claims. Inputinvariance diagnostic alone cannot establish real video appearance/temporal quality.',bicubic_control_max_count_difference=1,quality_approval=False)
 save(ROOT/'protocol.json',protocol);model,_=stock_video.load_cnn(None,MODEL,device);models={'bicubic':Bicubic().to(device).eval(),'cnn':model};report=dict(complete=False,protocol_sha256=sha(ROOT/'protocol.json'),runs=[],comparisons=[],quality_approval=False);started=time.perf_counter()
 for source,input_path in enumerate(source_inputs):
  image=np.fromfile(input_path,dtype='<u2').reshape(3072,4096);directory=ROOT/str(source);directory.mkdir()
  for dy,dx in offsets:
   shifted=np.pad(image,((dy,0),(dx,0)),mode='edge')[:3072,:4096];assert np.array_equal(shifted[dy:,dx:],image[:3072-dy,:4096-dx]);raw=directory/f'input-{dy}-{dx}.raw';shifted.tofile(raw)
   for name,m in models.items():
    pred,elapsed=stock_video.restore(raw,4096,3072,m,device,256,64,2);assert pred.shape==(6144,8192);out=directory/f'{name}-{dy}-{dx}.raw';pred.tofile(out)
    report['runs'].append(dict(source=source,offset=[dy,dx],mode=name,input_sha256=sha(raw),output_sha256=sha(out),inference_s=elapsed));del pred
   if (dy,dx)!=(0,0):
    differences={}
    for name in models:
     baseline=np.memmap(directory/f'{name}-0-0.raw',dtype='<u2',mode='r',shape=(6144,8192));current=np.memmap(directory/f'{name}-{dy}-{dx}.raw',dtype='<u2',mode='r',shape=(6144,8192));a=baseline[512:5632,512:7680];b=current[512+2*dy:5632+2*dy,512+2*dx:7680+2*dx];diff=b.astype(np.int32)-a.astype(np.int32);differences[name]=diff;absdiff=np.abs(diff);report['comparisons'].append(dict(source=source,offset=[dy,dx],mode=name,count=diff.size,max_abs_counts=int(absdiff.max()),mae_counts=float(absdiff.mean()),rmse_counts=float(np.sqrt(np.mean(diff.astype(np.float64)**2))),differing_samples=int(np.count_nonzero(diff)),p99_abs_counts=float(np.percentile(absdiff,99)),p999_abs_counts=float(np.percentile(absdiff,99.9))))
    assert np.abs(differences['bicubic']).max()<=1
    residual=differences['cnn']-differences['bicubic'];report['comparisons'].append(dict(source=source,offset=[dy,dx],mode='learned-residual-change',count=residual.size,max_abs_counts=int(np.abs(residual).max()),mae_counts=float(np.abs(residual).mean()),rmse_counts=float(np.sqrt(np.mean(residual.astype(np.float64)**2)))))
   save(ROOT/'results.json',report);print(json.dumps(dict(source=source,offset=[dy,dx],complete=True)),flush=True)
 report.update(complete=True,elapsed_s=time.perf_counter()-started);save(ROOT/'results.json',report);print(json.dumps(dict(complete=True,elapsed_s=report['elapsed_s'])),flush=True)
if __name__=='__main__':main()
