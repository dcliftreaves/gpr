"""Independent translation-count accounting and CPU backend control."""
from pathlib import Path
import datetime,hashlib,json,sys,time,shutil
import numpy as np
import torch
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'));import stock_video
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_translation_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 p=json.loads((ROOT/'protocol.json').read_text());r=json.loads((ROOT/'results.json').read_text());assert r['complete'];assert r['protocol_sha256']==sha(ROOT/'protocol.json');assert p['driver_sha256']==sha(ROOT/'measure_stock_cnn_translation.py');assert p['runtime_sha256']==sha(REPO/'tools/stock_video.py')
 for row in r['runs']:
  dy,dx=row['offset'];d=ROOT/str(row['source']);assert sha(d/f'input-{dy}-{dx}.raw')==row['input_sha256'];assert sha(d/f'{row["mode"]}-{dy}-{dx}.raw')==row['output_sha256']
 for i,source in enumerate(p['sources']):
  path=Path(source['path']);assert sha(path)==source['sha256'];a=np.fromfile(path,dtype='<u2').reshape(3072,4096)
  for dy,dx in p['source_sensor_offsets_yx']:
   b=np.fromfile(ROOT/str(i)/f'input-{dy}-{dx}.raw',dtype='<u2').reshape(3072,4096)
   # Index clipping is independent of producer np.pad implementation.
   assert np.array_equal(b,a[np.maximum(np.arange(3072)-dy,0)[:,None],np.maximum(np.arange(4096)-dx,0)[None,:]])
   assert not (dy%2 or dx%2)
 comparisons=[]
 for row in r['comparisons']:
  s=row['source'];dy,dx=row['offset'];m=row['mode'];names=['cnn','bicubic'] if m=='learned-residual-change' else [m];errors=[]
  for name in names:
   old=np.memmap(ROOT/str(s)/f'{name}-0-0.raw',dtype='<u2',mode='r',shape=(6144,8192));new=np.memmap(ROOT/str(s)/f'{name}-{dy}-{dx}.raw',dtype='<u2',mode='r',shape=(6144,8192));chunks=[]
   for y in range(512,5632,128):chunks.append(new[y+2*dy:y+128+2*dy,512+2*dx:7680+2*dx].astype(np.int32)-old[y:y+128,512:7680].astype(np.int32))
   errors.append(np.concatenate(chunks))
  delta=errors[0] if len(errors)==1 else errors[0]-errors[1];absolute=np.abs(delta);sse=sum(int(np.square(x.astype(np.int64)).sum()) for x in delta)
  assert int(absolute.max())==row['max_abs_counts'];assert float(absolute.sum())/delta.size==row['mae_counts'];assert np.sqrt(sse/delta.size)==row['rmse_counts']
  if 'p99_abs_counts' in row:
   assert np.percentile(absolute,99)==row['p99_abs_counts'] and np.percentile(absolute,99.9)==row['p999_abs_counts'];assert np.count_nonzero(delta)==row['differing_samples']
  if m=='bicubic' or dx==16:assert not np.count_nonzero(delta)
  comparisons.append(dict(source=s,offset=[dy,dx],mode=m,max_abs_counts=int(absolute.max()),rmse_counts=float(np.sqrt(sse/delta.size))))
 cpu=ROOT/'cpu-control';cpu.mkdir(exist_ok=False);checkpoint=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt';assert sha(checkpoint)==p['checkpoint_sha256']
 protocol=dict(schema='gpr.stock_cnn_translation_cpu_control.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_protocol_sha256=sha(ROOT/'protocol.json'),driver_sha256=sha(Path(__file__)),source=0,offsets=[[0,0],[0,2]],checkpoint_sha256=sha(checkpoint),device='cpu',threads=4,tile=256,halo=64,max_cpu_mps_count_difference=1,selection=False)
 save(cpu/'protocol.json',protocol);torch.set_num_threads(4);model,_=stock_video.load_cnn(None,checkpoint,torch.device('cpu'));results=[]
 for dy,dx in protocol['offsets']:
  output,elapsed=stock_video.restore(ROOT/'0'/f'input-{dy}-{dx}.raw',4096,3072,model,torch.device('cpu'),256,64,2);path=cpu/f'cnn-{dy}-{dx}.raw';output.tofile(path);mps=np.memmap(ROOT/'0'/f'cnn-{dy}-{dx}.raw',dtype='<u2',mode='r',shape=output.shape);maximum=0;different=0
  for y in range(0,6144,128):d=np.abs(output[y:y+128].astype(np.int32)-mps[y:y+128].astype(np.int32));maximum=max(maximum,int(d.max()));different+=int(np.count_nonzero(d))
  assert maximum<=1;results.append(dict(offset=[dy,dx],output_sha256=sha(path),max_cpu_mps_count_difference=maximum,differing_samples=different,inference_s=elapsed));print('CPU control '+str((dy,dx))+' max '+str(maximum),flush=True)
 left=np.memmap(cpu/'cnn-0-0.raw',dtype='<u2',mode='r',shape=(6144,8192));right=np.memmap(cpu/'cnn-0-2.raw',dtype='<u2',mode='r',shape=(6144,8192));d=right[512:5632,516:7684].astype(np.int32)-left[512:5632,512:7680].astype(np.int32)
 result=dict(schema='gpr.stock_cnn_translation_audit.v1',complete=True,driver_sha256=sha(Path(__file__)),parent_results_sha256=sha(ROOT/'results.json'),transform_samples_independently_exact=True,comparison_metrics_independently_exact=True,comparisons=comparisons,cpu_control=results,cpu_aligned_translation_max_counts=int(np.abs(d).max()),cpu_aligned_translation_rmse_counts=float(np.sqrt(np.mean(d.astype(np.float64)**2))),quality_approval=False)
 save(ROOT/'audit.json',result)
if __name__=='__main__':main()
