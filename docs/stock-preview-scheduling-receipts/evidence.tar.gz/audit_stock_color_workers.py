from pathlib import Path
import hashlib,json,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_color_worker_profile_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 d=ROOT/'native-120-profiled';p=json.loads((d/'protocol.json').read_text());done=json.loads((d/'complete.json').read_text());v=json.loads((d/'verified.json').read_text());assert done['complete'] and done['protocol_sha256']==sha(d/'protocol.json');assert sha(ROOT/'profile_stock_color_workers.py')==p['driver_sha256'];assert sha(ROOT/'source/lib/gpr_video/gpr_preview.cpp')==p['preview_source_sha256'];assert sha(ROOT/'build/CMakeCache.txt')==p['cmake_cache_sha256'];assert done['clip_deleted_after_verification'] and len(v['clip_sha256'])==64 and v['clip_bytes']>v['capture']['payload_bytes'];assert all(v[x] for x in ['all_payloads_exact_independent_stock','all_source_calibration_exact','all_delivered_preview_pixels_exact_offline','end_marker_verified'])
 events=[json.loads(l) for l in (d/'capture.jsonl').read_text().splitlines() if l.startswith('{')];previews=[e for e in events if e['event']=='preview'];frames=[e for e in events if e['event']=='frame'];assert len(previews)==len(frames)==v['frames_verified']==120
 raw=[json.loads(l.split(' ',1)[1]) for l in (d/'workers.stderr').read_text().splitlines() if l.startswith('PREVIEW_WORKER_PROFILE ')];assert raw==json.loads((d/'worker-rows.json').read_text()) and len(raw)==done['profile_records']==480
 for i,preview in enumerate(previews):
  group=[x for x in raw if x['sequence']==i];assert preview['index']==i and frames[i]['timestamp_ns']==preview['timestamp_ns'];assert sorted((x['first_row'],x['last_row']) for x in group)==[(0,192),(192,384),(384,576),(576,768)]
  for x in group:
   assert x['policy']==1 and x['priority']==1 and x['nice']==0 and x['affinity_mask']==15;assert x['begin_ns']>=preview['timestamp_ns'] and x['end_ns']>=x['begin_ns'] and x['cpu_ns']>0;assert x['end_ns']<=preview['timestamp_ns']+preview['capture_to_sink_ms']*1e6+1000
 sources=[]
 for source in (0,1):
  selected=[q for q in previews if q['index']>=p['warmup_frames_for_summary'] and q['source_index']==source];assert len(selected)==58;workers=[];groups={q['index']:[r for r in raw if r['sequence']==q['index']] for q in selected}
  for first in (0,192,384,576):
   rows=[r for group in groups.values() for r in group if r['first_row']==first];workers.append(dict(first_row=first,cpu_median_ms=statistics.median(r['cpu_ns']/1e6 for r in rows),wall_median_ms=statistics.median((r['end_ns']-r['begin_ns'])/1e6 for r in rows),start_lag_median_ms=statistics.median((r['begin_ns']-min(x['begin_ns'] for x in groups[r['sequence']]))/1e6 for r in rows),finish_lag_median_ms=statistics.median((max(x['end_ns'] for x in groups[r['sequence']])-r['end_ns'])/1e6 for r in rows),core_begin_counts={str(k):sum(r['core_begin']==k for r in rows) for k in range(4)}))
  sources.append(dict(source=source,frames=58,api_render_median_ms=statistics.median(q['render_ms'] for q in selected),worker_envelope_median_ms=statistics.median((max(r['end_ns'] for r in g)-min(r['begin_ns'] for r in g))/1e6 for g in groups.values()),sum_cpu_divided_by4_median_ms=statistics.median(sum(r['cpu_ns'] for r in g)/4e6 for g in groups.values()),workers=workers))
 result=dict(complete=True,driver_sha256=sha(Path(__file__)),profile_protocol_sha256=sha(d/'protocol.json'),frames_verified_before_clip_deletion=120,profile_records=480,warmup_frames_excluded=4,sources=sources,scope='Instrumented diagnostic only. Worker loop CPU/wall excludes thread creation/join and prints; sibling/API timings can include print interference. CPU/4 is arithmetic headroom, not an attainable guarantee. Cause of delayed start not isolated; no sustained-rate approval.');(ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print('120 frames and480 color-worker records independently bound; summary complete.')
if __name__=='__main__':main()
