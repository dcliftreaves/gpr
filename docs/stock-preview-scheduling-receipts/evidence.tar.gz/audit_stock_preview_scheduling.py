from pathlib import Path
import hashlib,json,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_preview_scheduling_20261031');WORK=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 output=[]
 for mode,repo,driver in [('three','stock-three-worker-preview-20261031','benchmark_stock_three_worker_capture.py'),('dynamic','stock-dynamic-preview-20261031','benchmark_stock_dynamic_preview_capture.py')]:
  root=ROOT/mode;d=root/'native-abba';p=json.loads((d/'protocol.json').read_text());r=json.loads((d/'receipt.json').read_text());assert r['complete'] and r['protocol_sha256']==sha(d/'protocol.json');assert p['order']==['baseline','streamed','streamed','baseline'] and p['attempts_per_run']==600;assert sha(root/driver)==p['driver_sha256']
  for n,digest in p['uncommitted_integration_source'].items():assert sha(root/n if (root/n).exists() else WORK/repo/n)==digest,n
  for n,digest in p['verifier_sources'].items():assert sha(WORK/repo/'tools'/n)==digest
  rows=[]
  for i,run in enumerate(r['runs']):
   assert (run['index'],run['mode'])==(i,p['order'][i]);events=[json.loads(l) for l in (d/f'{i}.jsonl').read_text().splitlines() if l.startswith('{')];frames=[e for e in events if e['event']=='frame'];previews=[e for e in events if e['event']=='preview'];v=run['verified'];c=next(e for e in events if e['event']=='summary');q=next(e for e in events if e['event']=='preview_summary');assert c==v['capture'] and q==v['preview'] and c['complete'];assert len(frames)==len(previews)==v['frames_verified']==c['written']==c['accepted']==q['rendered']==q['offered'];assert c['attempts']==600==len(frames)+c['overruns'] and not q['discarded']
   assert c['deadline_misses']==sum(e['deadline_missed'] for e in frames);late=sum(e['capture_to_sink_ms']>50 for e in previews);floor=dict(recording=not c['overruns'] and not c['deadline_misses'] and c['durable_fps']>=20,preview=len(previews)==600 and not late,preview_late_deliveries=late,deadline_ms=50.0);assert floor==v['floor'];assert [e['index'] for e in frames]==list(range(len(frames)));fm={e['index']:e for e in frames}
   for e in previews:assert e['timestamp_ns']==fm[e['index']]['timestamp_ns'] and e['width']==1024 and e['height']==768
   assert run['observed']==dict(uids=[1000]*4,policy=1,priority=1,nice=0,capabilities='0000000000000000');assert run['clip_deleted_after_verification'] and run['clip_bytes']>c['payload_bytes'] and len(v['clip_sha256'])==64
   for k in ['all_payloads_exact_independent_stock','all_source_calibration_exact','all_delivered_preview_pixels_exact_offline','end_marker_verified']:assert v[k]
   assert q['streamed_inverse'] and q['stream_buffer_bytes']==4917214 and not q['reconstruction_scratch_bytes'];assert abs(sorted(e['render_ms'] for e in previews)[int((len(previews)-1)*.5)]-q['render_median_ms'])<.0002
   rows.append(dict(index=i,mode=run['mode'],frames=len(frames),durable_fps=c['durable_fps'],encode_median_ms=c['encode_median_ms'],render_median_ms=q['render_median_ms'],late_writes=c['deadline_misses'],late_previews=late,final_fsync_s=c['final_fsync_s'],floor=floor))
  assert r['streamed_fixed_repeats_passed']==all(x['floor']['recording'] and x['floor']['preview'] for x in rows if x['mode']=='streamed');output.append(dict(variant=mode,frames_verified_before_deletion=sum(x['frames'] for x in rows),strict_combined_floor_passed=r['streamed_fixed_repeats_passed'],runs=rows))
 audit=dict(complete=True,driver_sha256=sha(Path(__file__)),comparisons=output,scope='Source/protocol/event/accounting/deadline audit; byte/calibration/PTS/pixelCRC/END3 checks completed by bound verifier before clip deletion. Saved clip identities cannot recreate deleted bytes. No sustained approval.');(ROOT/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print('Both fixed comparisons independently audited:4,799 frames, both gates remain open.')
if __name__=='__main__':main()
