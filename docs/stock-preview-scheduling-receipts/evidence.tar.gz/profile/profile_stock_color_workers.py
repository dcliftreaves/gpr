from pathlib import Path
import hashlib,json,subprocess,sys,time,os,shutil
REPO=Path('/mnt/ssd/gpr_work/stock-color-worker-profile-20261031');ROOT=REPO/'native-120-profiled';SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030');OLD=Path('/mnt/ssd/gpr_work/stock-stream-quant-table-20261031/native-final/protocol.json')
sys.path.insert(0,str(REPO/'tools'));import benchmark_mission1 as bench,stock_video

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 ROOT.mkdir(exist_ok=False);old=json.loads(OLD.read_text());binary=REPO/'build/gpr_capture_app';clip=ROOT/'capture.gvid';args=old['common_command'][:];args[args.index('--frames')+1]='120';capture=[str(binary),*args,'--preview-streamed','--output',str(clip)];launch=ROOT/'launch.json';command=['sudo','-n','chrt','--fifo','1','/usr/bin/setpriv','--reuid=1000','--regid=1000','--init-groups','--reset-env','/usr/bin/python3',str(SEED/'launch_stock_policy_user.py'),str(launch),'1',*capture]
 protocol=dict(schema='gpr.stock_color_worker_profile.v1',base='eb3062bfd285c1f4971e5e610071351a0d184b25',driver_sha256=sha(Path(__file__)),preview_source_sha256=sha(REPO/'source/lib/gpr_video/gpr_preview.cpp'),source_tar_sha256=sha(Path('/tmp/gpr-color-worker-profile-source.tar')),binary_sha256=sha(binary),cmake_cache_sha256=sha(REPO/'build/CMakeCache.txt'),old_protocol_sha256=sha(OLD),command=command,warmup_frames_for_summary=4,scope='120-attempt diagnostic of current native streamed capture; per-color-worker wall/threadCPU for calibrated display row loop, core and actual scheduler/affinity. Prints after each worker timed loop before join, so logging can perturb other workers/API timing. No per-row timers or throughput approval. PID policy/UID/capabilities observed; no concurrent Pi build/test/profile by this run. Actual code includes optional GPR_PREVIEW_WORKER_PROFILE at compiletime.')
 for i,item in enumerate(old['inputs']):
  assert sha(SEED/item['raw_file'])==item['raw_sha256'] and sha(SEED/item['metadata_file'])==item['metadata_sha256']
  assert sha(SEED/f'reference-{i}.vc5')==old['reference_payloads'][i]['sha256'] and sha(SEED/f'profiles/{i:06d}.gprp')==old['profile_sha256'][i]
 assert shutil.disk_usage(ROOT).free>120*max(r['bytes'] for r in old['reference_payloads'])+2*(1<<30)
 save(ROOT/'protocol.json',protocol)
 with (ROOT/'capture.jsonl').open('w') as out,(ROOT/'workers.stderr').open('w') as err:
  child=subprocess.Popen(command,stdout=out,stderr=err);save(ROOT/'supervisor.json',dict(pid=child.pid));settings=None
  while settings is None:
   if launch.exists():
    try:settings=json.loads(launch.read_text())
    except json.JSONDecodeError:pass
   if settings is None:assert child.poll() is None;time.sleep(.005)
  assert not settings['gpr_environment']
  pid=settings['pid'];status=(Path('/proc')/str(pid)/'status').read_text();uids=list(map(int,next(x.split()[1:] for x in status.splitlines() if x.startswith('Uid:'))));assert uids==[1000]*4 and os.sched_getscheduler(pid)==1 and os.sched_getparam(pid).sched_priority==1 and os.getpriority(os.PRIO_PROCESS,pid)==0;assert next(x.split()[1] for x in status.splitlines() if x.startswith('CapEff:'))=='0000000000000000';save(ROOT/'observed.json',dict(uids=uids,policy=1,priority=1,nice=0,capabilities='0000000000000000'));rc=child.wait();assert rc==0,rc
 events=[json.loads(l) for l in (ROOT/'capture.jsonl').read_text().splitlines() if l.startswith('{')];meta=[stock_video.decode_metadata((SEED/x['metadata_file']).read_bytes()) for x in old['inputs']];offline={r['index']:r for r in map(json.loads,(SEED/'offline.jsonl').read_text().splitlines()) if r.get('event')=='preview'};v=bench.verify(clip,events,meta,[x['sha256'] for x in old['reference_payloads']],offline);v['clip_bytes']=clip.stat().st_size;save(ROOT/'verified.json',v)
 rows=[json.loads(l.split(' ',1)[1]) for l in (ROOT/'workers.stderr').read_text().splitlines() if l.startswith('PREVIEW_WORKER_PROFILE ')];assert len(rows)==4*v['frames_verified']
 for i in range(v['frames_verified']):
  group=[r for r in rows if r['sequence']==i];assert sorted((r['first_row'],r['last_row']) for r in group)==[(0,192),(192,384),(384,576),(576,768)]
  assert all(r['end_ns']>=r['begin_ns'] and r['cpu_ns']>0 and r['policy']==1 and r['priority']==1 and r['nice']==0 and r['affinity_mask']==15 for r in group)
 save(ROOT/'worker-rows.json',rows);clip.unlink();assert sha(binary)==protocol['binary_sha256'];save(ROOT/'complete.json',dict(complete=True,protocol_sha256=sha(ROOT/'protocol.json'),frames=v['frames_verified'],profile_records=len(rows),clip_deleted_after_verification=True));print(json.dumps(dict(complete=True,frames=v['frames_verified'])),flush=True)
if __name__=='__main__':main()
