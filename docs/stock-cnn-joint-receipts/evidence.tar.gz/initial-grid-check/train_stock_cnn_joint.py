"""Matched stock BIBO SR-only, frozen-cleanup, and joint-cleanup/SR study."""
from pathlib import Path
import datetime,hashlib,json,shutil,sys,time
import numpy as np
import torch
import torch.nn.functional as F
import tifffile
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'))
import raw_media,stock_video,train_stock_sr
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');ROOT=BASE/'stock_cnn_joint_20261031'
DATA=[('nikon',BASE/'stock_sr_20261028/dataset'),('camera',BASE/'stock_sr_mission_calibrated_20261031/dataset')]
CLEAN=REPO/'models/stock-q3-rggb14-cleanup/selected.pt';SR=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt'
PEAK=16383.
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def rounded(x):
    y=(x*PEAK+.5).floor().clamp(0,PEAK)/PEAK
    return x+(y-x).detach()
def main():
    ROOT.mkdir(exist_ok=False);shutil.copy2(Path(__file__),ROOT/Path(__file__).name)
    torch.set_num_threads(4);device=torch.device('mps');arrays=[];patches={};domains=[];validation=[];source_rows=[]
    # Extend actual decoded sensor inputs to 256 planes: the two-stage receptive
    # field exceeds the old 32-plane patch halo. Preserve target cores/splits.
    for domain,directory in DATA:
        info=json.loads((directory/'dataset.json').read_text());assert info['complete']
        assert sha(directory/'inputs.npy')==info['input_sha256'] and sha(directory/'targets.npy')==info['target_sha256']
        di=len(arrays);inputs=np.load(directory/'inputs.npy',mmap_mode='r');targets=np.load(directory/'targets.npy',mmap_mode='r');arrays.append((inputs,targets));training=[]
        for si,source in enumerate(info['sources']):
            if source['split']=='test':assert source['patch_count']==0 and source['patch_start'] is None;continue
            path=Path(source['path']);assert sha(path)==source['sha256'];meta=raw_media.extract(path,14);tags={r['code']:r for r in meta['image']}
            assert meta['cfa']=='RGGB';black=np.array(raw_media.values(tags[50714]),np.float32);white=float(raw_media.values(tags[50717])[0]);neutral=np.array(raw_media.values(tags[50728]),np.float32);wb=neutral[1]/neutral;wbg=np.array([wb[0],wb[1],wb[1],wb[2]],np.float32)
            decoded=directory/f'source-{si:03d}/decoded.raw'
            if decoded.exists():
                assert sha(decoded)==source['low_decoded_raw_sha256'];raw=np.memmap(decoded,dtype='<u2',mode='r',shape=(source['height']//2,source['width']//2))
            else:
                dng=directory/f'source-{si:03d}/decoded.dng'
                with tifffile.TiffFile(dng) as f:raw=f.asarray()
                assert hashlib.sha256(raw.tobytes()).hexdigest()==source['low_decoded_raw_sha256']
            planes=np.stack([raw[c//2::2,c%2::2] for c in range(4)]);ph,pw=planes.shape[-2:];assert ph>=256 and pw>=256
            keys=[]
            for k,(y,x) in enumerate(source['low_plane_yx']):
                idx=source['patch_start']+k;key=(di,idx);keys.append(key)
                assert np.array_equal(planes[:,y:y+128,x:x+128],inputs[idx])
                ya=min(max(y-64,0),ph-256);xa=min(max(x-64,0),pw-256);assert not (ya%8 or xa%8)
                # Original high-target core64:192 is unchanged. Global-frame
                # boundary convolutions remain real boundaries, not fake padding.
                oy=2*(y-ya)+64;ox=2*(x-xa)+64
                patches[key]=(planes,ya,xa,oy,ox,black,white,wbg,domain+':'+source['group'])
            (training if source['split']=='train' else validation).append(keys)
            source_rows.append(dict(domain=domain,source_sha256=source['sha256'],split=source['split'],group=source['group'],patches=len(keys),decoded_counts_sha256=source['low_decoded_raw_sha256']))
        domains.append(training)
    validation=[k for group in validation for k in group];assert len(validation)==320 and [len(d) for d in domains]==[8,28]
    family=['sr-only','frozen-cleanup','joint-cleanup'];seed=20261109;steps=400;checkpoints=[200,400]
    protocol=dict(schema='gpr.stock_cnn_joint_protocol.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),source_revision='144a338956ab93df767e480c02b9209b669b8a8d',cleanup_sha256=sha(CLEAN),sr_sha256=sha(SR),code_sha256={n:sha(REPO/'tools'/n) for n in ['stock_cnn_models.py','stock_video.py','train_stock_sr.py','raw_media.py']},datasets=[dict(domain=d,path=str(p),manifest_sha256=sha(p/'dataset.json')) for d,p in DATA],sources=source_rows,family=family,seed=seed,steps=steps,batch=4,checkpoints=checkpoints,learning_rate=.00003,weight_decay=.0001,sampling='Two distinct Nikon and two distinct camera training sources per update; one uniform patch per source; identical sequence for each arm',normalization='Original 14-bit count/16383, no canonicalization/gating/strength sweep',batchnorm='All models eval mode throughout, preserving pretrained running statistics; affine and convolution weights train normally. Same for every arm.',geometry='256-plane actual decoded-low input extends original128 patch with64 context each side where available. Original target core64:192 unchanged; crops tracked globally, U-Net grid phase preserved. Original128 input equals dataset bytes on every recorded train/validation patch.',intermediate='Clipped roundeduint16 cleanup counts; straight-through rounding derivative during training, exactly rounded forward. No codec re-encoding. Evaluation uses same rounding.',loss='Native normalized RAW squared error +0.4 horizontal/vertical gradient squared error +0.1 approximate calibrated tone/WB RGB Charbonnier; joint arm additionally0.02 native low-cleanup squared error on rounded same-site high-target2x2 average. Frozen-cleanup/SR-only optimize same final objective.',selection='Eachcheckpoint requires per-group and pooled fourRAWregionMSE<=BOTHbicubicandsuppliedSR, plus calibrated tone/WBproxy<=suppliedSR eachgroup, andstrictpooledRAWimprovement vs suppliedSR. Everyeligiblecheckpoint mustpass all10complete validationimages andactualmatchedrendering beforefreeze/final.',context_requirement='Two BIBO networks combined require roughly55low-plane context; extended patches prevent treating old32halo as sufficient. Full runtime must preserve separately tiled stages, rounding, calibration.',limitations=['Single fixed seed/budget.','Existing model pretraining overlaps historical references; reused source-grouped validation, not blind/sensor truth.','Camera references recovered from compressedGPR and archivalmetadata.','Tone proxy is not calibrated actual renderer; actual rendering mandatory for promotion.','No native/Pi pipeline approval or temporal/restored-tier claim follows patch training.'],final_pixels_used=False,quality_approval=False)
    save(ROOT/'protocol.json',protocol)
    def tensors(keys):
        x=[];y=[];b=[];w=[];wb=[];positions=[]
        for key in keys:
            pl,ya,xa,oy,ox,black,white,gains,group=patches[key];x.append(pl[:,ya:ya+256,xa:xa+256]);y.append(arrays[key[0]][1][key[1]]);b.append(black);w.append(white);wb.append(gains);positions.append((oy,ox))
        values=[np.stack(x).astype(np.float32)/PEAK,np.stack(y).astype(np.float32)/PEAK,np.stack(b)[:,:,None,None],np.array(w,np.float32)[:,None,None,None],np.stack(wb)[:,:,None,None]]
        return (*[torch.from_numpy(v).to(device) for v in values],positions)
    def core(out,positions,scale=2):
        return torch.stack([out[j,:,oy//(2//scale):oy//(2//scale)+128//(2//scale),ox//(2//scale):ox//(2//scale)+128//(2//scale)] for j,(oy,ox) in enumerate(positions)])
    def tone(x,b,w,wb):
        q=((x*PEAK-b)/(w-b)*wb).clamp(0,1)
        return (torch.stack([q[:,0],.5*(q[:,1]+q[:,2]),q[:,3]],1)+1e-4).sqrt()
    def forward(clean,sr,x):
        intermediate=rounded(clean(x)) if clean is not None else x
        return sr(intermediate),intermediate
    def evaluate(clean,sr):
        totals={};proxy={}
        with torch.inference_mode():
            for start in range(0,len(validation),4):
                keys=validation[start:start+4];x,y,b,w,wb,positions=tensors(keys)
                output=F.interpolate(x,scale_factor=2,mode='bicubic',align_corners=False).clamp(0,1) if sr is None else forward(clean,sr,x)[0]
                counts=np.clip(core(output,positions).cpu().numpy()*PEAK+.5,0,PEAK).astype('<u2');ref=np.stack([np.asarray(arrays[k[0]][1][k[1],:,64:192,64:192],np.float64) for k in keys]);pt=torch.from_numpy(counts.astype(np.float32)/PEAK).to(device);yt=y[:,:,64:192,64:192]
                errors=(tone(pt,b,w,wb)-tone(yt,b,w,wb)).square().cpu().numpy()
                for k,p,r,e in zip(keys,counts,ref,errors):
                    regions=train_stock_sr.region_totals(r,p.astype(np.float64)-r)
                    for group in ['pooled',patches[k][-1]]:
                        dest=totals.setdefault(group,{})
                        for region,(sse,n) in regions.items():a,c=dest.get(region,(0.,0));dest[region]=(a+sse,c+n)
                        a,n=proxy.get(group,(0.,0));proxy[group]=(a+float(e.astype(np.float64).sum()),n+e.size)
        return dict(regions={g:{r:a/n for r,(a,n) in d.items()} for g,d in totals.items()},tone_proxy_mse={g:a/n for g,(a,n) in proxy.items()})
    clean0,_=stock_video.load_cnn(None,CLEAN,device);sr0,_=stock_video.load_cnn(None,SR,device)
    baseline=evaluate(None,None);supplied=evaluate(None,sr0);cascade=evaluate(clean0,sr0)
    save(ROOT/'baseline.json',dict(bicubic=baseline,supplied_sr=supplied,frozen_cascade=cascade));del clean0,sr0;torch.mps.empty_cache()
    report=dict(schema='gpr.stock_cnn_joint.v1',complete=False,protocol_sha256=sha(ROOT/'protocol.json'),baseline_sha256=sha(ROOT/'baseline.json'),torch=torch.__version__,cases=[],quality_approval=False);started=time.perf_counter()
    for case in family:
        rng=np.random.default_rng(seed);torch.manual_seed(seed);sr,_=stock_video.load_cnn(None,SR,device);clean=None
        if case!='sr-only':clean,_=stock_video.load_cnn(None,CLEAN,device)
        params=list(sr.parameters())
        if case=='joint-cleanup':params+=list(clean.parameters())
        elif clean is not None:
            for p in clean.parameters():p.requires_grad_(False)
        buffers={name:t.detach().cpu().clone() for prefix,model in [('sr',sr),('clean',clean)] if model is not None for name,t in ((prefix+'.'+n,v) for n,v in model.named_buffers())}
        optimizer=torch.optim.AdamW(params,lr=protocol['learning_rate'],weight_decay=protocol['weight_decay']);directory=ROOT/case;directory.mkdir();row=dict(case=case,checkpoints=[]);report['cases'].append(row)
        for step in range(1,steps+1):
            keys=[]
            for domain in domains:
                for index in rng.choice(len(domain),size=2,replace=False):
                    source=domain[int(index)];keys.append(source[int(rng.integers(len(source)))])
            x,y,b,w,wb,positions=tensors(keys);optimizer.zero_grad(set_to_none=True);output,cleaned=forward(clean,sr,x);pred=core(output,positions);target=y[:,:,64:192,64:192]
            loss=(pred-target).square().mean()+.4*((pred[:,:,:,1:]-pred[:,:,:,:-1]-(target[:,:,:,1:]-target[:,:,:,:-1])).square().mean()+(pred[:,:,1:,:]-pred[:,:,:-1,:]-(target[:,:,1:,:]-target[:,:,:-1,:])).square().mean())
            loss=loss+.1*((tone(pred,b,w,wb)-tone(target,b,w,wb)).square()+1e-6).sqrt().mean()
            if case=='joint-cleanup':
                lowtarget=((F.avg_pool2d(y*PEAK,2)+.5).floor()/PEAK)[:,:,32:96,32:96]
                loss=loss+.02*(core(cleaned,positions,1)-lowtarget).square().mean()
            assert torch.isfinite(loss).item();loss.backward();optimizer.step()
            if step%50==0:print(json.dumps(dict(case=case,step=step,loss=float(loss.item()),elapsed_s=time.perf_counter()-started)),flush=True)
            if step in checkpoints:
                paths={}
                for name,model,template in [('sr',sr,SR),('cleanup',clean,CLEAN)]:
                    if model is None:continue
                    ckpt=torch.load(template,map_location='cpu',weights_only=True);ckpt['backbone_state']={k:v.detach().cpu() for k,v in model.backbone.state_dict().items()};ckpt.update(quality_approval=False,joint_protocol_sha256=sha(ROOT/'protocol.json'),joint_case=case,joint_step=step);path=directory/f'{name}-{step}.pt';torch.save(ckpt,path);paths[name]=dict(path=str(path),sha256=sha(path))
                for prefix,model in [('sr',sr),('clean',clean)]:
                    if model is not None:
                        for name,t in model.named_buffers():assert torch.equal(t.detach().cpu(),buffers[prefix+'.'+name])
                scores=evaluate(clean,sr);bad=[]
                for label,base in [('bicubic',baseline),('supplied',supplied)]:
                    bad += [label+':'+g+':'+r for g,d in base['regions'].items() for r,v in d.items() if scores['regions'][g][r]>v]
                tonebad=[g for g,v in supplied['tone_proxy_mse'].items() if scores['tone_proxy_mse'][g]>v];gain=train_stock_sr.delta(supplied['regions']['pooled']['overall'],scores['regions']['pooled']['overall']);eligible=not bad and not tonebad and gain>0
                result=dict(step=step,checkpoints=paths,metrics=scores,raw_regressions=bad,tone_proxy_regressions=tonebad,gain_db_vs_supplied=gain,eligible=eligible,batchnorm_buffers_unchanged=True,elapsed_s=time.perf_counter()-started);row['checkpoints'].append(result);save(ROOT/'training.json',report);print(json.dumps(dict(case=case,step=step,gain_db_vs_supplied=gain,eligible=eligible,raw_regressions=bad,tone_regressions=tonebad)),flush=True)
        del clean,sr,optimizer;torch.mps.empty_cache()
    report.update(complete=True,elapsed_s=time.perf_counter()-started,eligible=[dict(case=r['case'],step=c['step']) for r in report['cases'] for c in r['checkpoints'] if c['eligible']]);save(ROOT/'training.json',report);print(json.dumps(dict(complete=True,eligible=report['eligible'],elapsed_s=report['elapsed_s'])),flush=True)
if __name__=='__main__':main()
