#define _POSIX_C_SOURCE 200809L
#include "functions.inc"
static void die(const char *s){fprintf(stderr,"%s\n",s);exit(1);}
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static uint8_t outputs[2][131072];
static unsigned encode(int kind,PIXEL *data,unsigned width,unsigned height,unsigned pitch,int incremental,unsigned initial){
 STREAM byte_stream;BITSTREAM bits;
 if(CreateStreamBuffer(&byte_stream,outputs[kind],sizeof(outputs[kind]))||InitBitstream(&bits)||AttachBitstream(&bits,&byte_stream))die("stream");
 if(initial)PutBits(&bits,0xa5a5a5a5,initial);
 uint32_t pending=0;CODEC_ERROR error;
 if(incremental){
  for(unsigned y=0;y<height;y++){
   error=kind?candidate_incremental(&bits,&encoder_codeset_17,data+y*pitch,width,1,pitch*2,&pending,false):baseline_incremental(&bits,&encoder_codeset_17,data+y*pitch,width,1,pitch*2,&pending,false);
   if(error)die("incremental encode");
  }
  error=kind?candidate_incremental(&bits,&encoder_codeset_17,NULL,width,0,pitch*2,&pending,true):baseline_incremental(&bits,&encoder_codeset_17,NULL,width,0,pitch*2,&pending,true);
 }else error=kind?candidate_incremental(&bits,&encoder_codeset_17,data,width,height,pitch*2,NULL,true):baseline_incremental(&bits,&encoder_codeset_17,data,width,height,pitch*2,NULL,true);
 if(error||FlushBitstream(&bits))die("encode");return byte_stream.byte_count;
}
int main(void){
 gpr_allocator allocator={malloc,free};if(PrepareCodebooks(&allocator,&encoder_codeset_17))die("codebook");
 PIXEL data[4096];unsigned checks=0;uint32_t random=1;
 for(unsigned width=1;width<=257;width++)for(unsigned pattern=0;pattern<21;pattern++){
  unsigned pitch=width+3,height=3;
  for(unsigned i=0;i<pitch*height;i++){
   random=random*1664525+1013904223;
   data[i]=pattern==0?0:pattern==1?(int)(random%16)-8:pattern==2?(i%23==22?7:0):pattern==3?(i%3==0?8:i%3==1?-9:0):(int16_t)(random>>16);
  }
  if(pattern>=5)for(unsigned i=0;i<pitch*height;i++)if(!((pattern-5)&(1u<<(i%4))))data[i]=0;
  for(unsigned inc=0;inc<2;inc++)for(unsigned initial=0;initial<=32;initial++){
   unsigned a=encode(0,data,width,height,pitch,inc,initial),b=encode(1,data,width,height,pitch,inc,initial);
   if(a!=b||memcmp(outputs[0],outputs[1],a))die("byte mismatch");checks++;
  }
 }
 printf("{\"exact_stream_cases\":%u,\"runs\":[",checks);
 int order[]={0,1,1,0,1,0,0,1};
 for(unsigned r=0;r<8;r++){
  unsigned kind=order[r];
  for(unsigned i=0;i<4096;i++){random=random*1664525+1013904223;data[i]=(int)(random%16)-8;}
  double start=now();unsigned long bytes=0;
  for(unsigned repeat=0;repeat<50000;repeat++){
   bytes+=encode(kind,data,1024,3,1027,1,0);
  }
  printf("%s{\"kind\":\"%s\",\"elapsed_s\":%.9f,\"streams\":50000,\"output_bytes\":%lu}",r?",":"",kind?"trailing":"baseline",now()-start,bytes);fflush(stdout);
 }
 printf("]}\n");ReleaseCodebooks(&allocator,&encoder_codeset_17);return 0;
}
