from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path('/mnt/ssd/gpr_work/stock-entropy-trailing-groups-20261031');LIB=Path('/mnt/ssd/gpr_work/stock-wavelet-row-integration-20261031');BUILD=LIB/'build'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 assert os.getuid()==1000 and os.sched_getscheduler(0)==0 and os.getpriority(os.PRIO_PROCESS,0)==0
 libs=[BUILD/'source/lib'/n for n in ['vc5_encoder/libvc5_encoder.a','vc5_common/libvc5_common.a','common/libcommon.a']]
 compile=['cc','-O3','-std=c11','-DNDEBUG','-DNEON=1',*['-I'+str(LIB/'source/lib'/n) for n in ['vc5_encoder','vc5_common','common/public','common/private']],str(ROOT/'test.c'),*map(str,libs),'-lm','-pthread','-o',str(ROOT/'test')]
 with (ROOT/'build.log').open('w') as out:subprocess.run(compile,stdout=out,stderr=subprocess.STDOUT,check=True)
 protocol=dict(schema='gpr.trailing_entropy_probe.v1',driver_sha256=sha(Path(__file__)),sources={n:sha(ROOT/n) for n in ['test.c','functions.inc']},libraries={str(p):sha(p) for p in libs},binary_sha256=sha(ROOT/'test'),compile=compile,command=['taskset','-c','2',str(ROOT/'test')],scope='356202 same-binary stream comparisons of extracted current control/candidate, widths1..257,21 patterns,whole/incremental rows,initial occupancy0..32. Fixed8-run synthetic small-coefficient timing; LCG low bits have period16, generated before timing. Not whole encoder or sustained performance.',order=['baseline','trailing','trailing','baseline','trailing','baseline','baseline','trailing'],streams_per_run=50000)
 assert not (ROOT/'protocol.json').exists();save(ROOT/'protocol.json',protocol)
 with (ROOT/'pi.json').open('w') as out,(ROOT/'pi.stderr').open('w') as err:
  child=subprocess.Popen(protocol['command'],stdout=out,stderr=err);save(ROOT/'supervisor.json',dict(pid=child.pid));code=child.wait();assert code==0,code
 r=json.loads((ROOT/'pi.json').read_text());assert r['exact_stream_cases']==356202 and [x['kind'] for x in r['runs']]==protocol['order'];save(ROOT/'complete.json',dict(complete=True,protocol_sha256=sha(ROOT/'protocol.json'),binary_after_sha256=sha(ROOT/'test')));print(json.dumps(r))
if __name__=='__main__':main()
