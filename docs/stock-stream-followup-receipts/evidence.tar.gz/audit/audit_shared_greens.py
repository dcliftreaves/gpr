from pathlib import Path
import hashlib,json,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_shared_greens_unpack_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 result=[]
 for variant,root in [('packed-ready',ROOT),('padded-ready',ROOT/'padded')]:
  p=json.loads((root/'protocol.json').read_text());d=json.loads((root/'complete.json').read_text());assert d['complete'] and d['protocol_sha256']==sha(root/'protocol.json')
  assert sha(root/'shared_greens_unpack_probe.cpp')==p['source_sha256'];driver='benchmark_stock_shared_greens_padded.py' if variant=='padded-ready' else 'benchmark_stock_shared_greens.py';assert sha(root/driver)==p['driver_sha256']
  sources=[]
  for i in range(2):
   rows=[json.loads(x) for x in (root/f'{i}.jsonl').read_text().splitlines()];assert len(rows)==128
   for j,x in enumerate(rows):
    assert (x['block'],x['iteration'],x['warmup'],x['mode'])==(j//16,j%16,j%16==0,p['order'][j//16]);assert x['all_four_channels_exact_scalar'] and x['shared_sample_bytes']==12582912
   modes={}
   for mode in ['channel-assembly','shared-greens']:
    a=[x for x in rows if not x['warmup'] and x['mode']==mode];assert len(a)==60
    modes[mode]=dict(median_ms=statistics.median(x['wall_ms'] for x in a),block_medians_ms=[statistics.median(x['wall_ms'] for x in a if x['block']==b) for b in range(8) if p['order'][b]==mode])
   assert min(modes['shared-greens']['block_medians_ms'])>max(modes['channel-assembly']['block_medians_ms']);sources.append(dict(source=i,modes=modes))
  result.append(dict(variant=variant,sources=sources))
 out=dict(complete=True,exact_iterations=512,decision='Reject both whole-height shared-green cache variants; every candidate block slower than every matched control. No full-encoder speed or ABI claim.',variants=result)
 (ROOT/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
