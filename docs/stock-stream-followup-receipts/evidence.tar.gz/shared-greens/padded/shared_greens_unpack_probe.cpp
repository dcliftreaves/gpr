#include "../source/lib/vc5_encoder/headers.h"
#include "logcurve.h"
#include <arm_neon.h>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <thread>
#include <vector>
#ifdef __linux__
#include <sched.h>
#endif
#define REQUIRE(x) do{if(!(x)){std::fprintf(stderr,"shared greens line %d: %s\n",__LINE__,#x);std::exit(1);}}while(0)
extern "C" void gpr_stock_unpack14_channel(const uint16_t*,const uint16_t*,const uint16_t*,int16_t*,unsigned,unsigned);
static uint16x4_t gather(const uint16_t*p){return vcreate_u16(uint64_t(EncoderLogCurve[p[0]>>2])|(uint64_t(EncoderLogCurve[p[2]>>2])<<16)|(uint64_t(EncoderLogCurve[p[4]>>2])<<32)|(uint64_t(EncoderLogCurve[p[6]>>2])<<48));}
struct Shared {
 unsigned w,h,stride;std::vector<int16_t> gs,gd;std::vector<std::atomic<unsigned>> ready;
 Shared(unsigned width,unsigned height,unsigned spacing=1):w(width),h(height),stride(spacing),gs(size_t(w)*h),gd(size_t(w)*h),ready(h*stride){reset();}
 void reset(){for(unsigned y=0;y<h;++y)ready[y*stride].store(0,std::memory_order_relaxed);}
 void row(const uint16_t*top,const uint16_t*bottom,unsigned y,unsigned ch,int16_t*out){
  unsigned state=ready[y*stride].load(std::memory_order_acquire);
  if(!state&&ready[y*stride].compare_exchange_strong(state,1,std::memory_order_acq_rel)){
   for(unsigned x=0;x<w;x+=4){int16x4_t a=vreinterpret_s16_u16(gather(top+2*x+1)),b=vreinterpret_s16_u16(gather(bottom+2*x));vst1_s16(gs.data()+size_t(y)*w+x,vhadd_s16(a,b));vst1_s16(gd.data()+size_t(y)*w+x,vhadd_s16(vsub_s16(a,b),vdup_n_s16(4096)));}
   ready[y*stride].store(2,std::memory_order_release);
  }else while(ready[y*stride].load(std::memory_order_acquire)!=2){__asm__ volatile("yield");}
  const int16_t*s=gs.data()+size_t(y)*w;
  if(ch==0)std::memcpy(out,s,w*2);
  else if(ch==3)std::memcpy(out,gd.data()+size_t(y)*w,w*2);
  else for(unsigned x=0;x<w;x+=4){int16x4_t color=vreinterpret_s16_u16(gather((ch==1?top:bottom)+2*x+(ch==2)));vst1_s16(out+x,vhadd_s16(color,vsub_s16(vdup_n_s16(4096),vld1_s16(s+x))));}
 }
};
static std::vector<unsigned char>read(const char*n){std::ifstream f(n,std::ios::binary);return std::vector<unsigned char>((std::istreambuf_iterator<char>(f)),{});}
int main(int argc,char**argv){
 if(argc!=2&&argc!=3)return 2;auto raw=read(argv[1]);REQUIRE(raw.size()==4096u*3072u*2u);SetupEncoderLogCurve();const auto*input=reinterpret_cast<const uint16_t*>(raw.data());unsigned w=2048,h=1536;
 Shared cache(w,h,argc==3?32:1);std::array<std::vector<int16_t>,4> expected,actual;for(unsigned c=0;c<4;++c){expected[c].resize(size_t(w)*h);actual[c].resize(size_t(w)*h);}
 for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){auto*t=input+size_t(2*y)*4096;auto*b=t+4096;int g1=EncoderLogCurve[t[2*x+1]>>2],g2=EncoderLogCurve[b[2*x]>>2],gs=(g1+g2)>>1;size_t i=size_t(y)*w+x;expected[0][i]=gs;expected[1][i]=(EncoderLogCurve[t[2*x]>>2]+4096-gs)>>1;expected[2][i]=(EncoderLogCurve[b[2*x+1]>>2]+4096-gs)>>1;expected[3][i]=(g1-g2+4096)>>1;}
 unsigned modes[]={0,1,1,0,1,0,0,1};
 for(unsigned block=0;block<8;++block)for(unsigned it=0;it<16;++it){cache.reset();std::array<std::thread,4>workers;auto start=std::chrono::steady_clock::now();for(unsigned c=0;c<4;++c)workers[c]=std::thread([&,c]{
#ifdef __linux__
  cpu_set_t mask;CPU_ZERO(&mask);CPU_SET(c,&mask);REQUIRE(!sched_setaffinity(0,sizeof(mask),&mask));
#endif
  for(unsigned y=0;y<h;++y){const auto*t=input+size_t(2*y)*4096;auto*b=t+4096;auto*out=actual[c].data()+size_t(y)*w;if(modes[block])cache.row(t,b,y,c,out);else gpr_stock_unpack14_channel(t,b,EncoderLogCurve,out,w,c);}});
  for(auto&t:workers)t.join();double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();for(unsigned c=0;c<4;++c)REQUIRE(actual[c]==expected[c]);
  std::printf("{\"block\":%u,\"iteration\":%u,\"warmup\":%s,\"mode\":\"%s\",\"wall_ms\":%.6f,\"all_four_channels_exact_scalar\":true,\"shared_sample_bytes\":%zu}\n",block,it,it?"false":"true",modes[block]?"shared-greens":"channel-assembly",ms,(cache.gs.size()+cache.gd.size())*2);std::fflush(stdout);
 }
}
