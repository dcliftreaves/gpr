from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path('/mnt/ssd/gpr_work/stock-shared-greens-unpack-20261031');LIB=Path('/mnt/ssd/gpr_work/stock-wavelet-row-integration-20261031');SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 assert os.getuid()==1000 and os.sched_getscheduler(0)==0 and os.getpriority(os.PRIO_PROCESS,0)==0
 libs=[LIB/'build/source/lib'/n for n in ['vc5_encoder/libvc5_encoder.a','vc5_common/libvc5_common.a','common/libcommon.a']]
 command=['c++','-O3','-std=c++11','-DNDEBUG','-DNEON=1',*['-I'+str(LIB/n) for n in ['tests','source/lib/vc5_encoder','source/lib/vc5_common','source/lib/common/public','source/lib/common/private']],str(ROOT/'shared_greens_unpack_probe.cpp'),*map(str,libs),'-lm','-pthread','-o',str(ROOT/'probe')]
 with (ROOT/'build.log').open('w') as out:subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,check=True)
 old=json.loads((SEED/'protocol.json').read_text());protocol=dict(schema='gpr.shared_greens_unpack.v1',source_sha256=sha(ROOT/'shared_greens_unpack_probe.cpp'),driver_sha256=sha(Path(__file__)),libraries={str(p):sha(p) for p in libs},compile=command,binary_sha256=sha(ROOT/'probe'),seed_protocol_sha256=sha(SEED/'protocol.json'),inputs=old['inputs'],order=['channel-assembly','shared-greens','shared-greens','channel-assembly','shared-greens','channel-assembly','channel-assembly','shared-greens'],iterations_per_block=16,warmup_per_block=1,scope='Four concurrent native RGGB14 unpack workers pinned0..3. Shared full-height GS/GDcache row-ready acquire/release single producer per row versus existing assembly. Exact all 4 channel samples against independent scalar formula every iteration. Includes thread start/join. Cache buffers allocated and ready states reset before timing. No filtering/entropy/preview/recording/codec-rate claim.')
 assert not (ROOT/'protocol.json').exists();save(ROOT/'protocol.json',protocol)
 for i,item in enumerate(old['inputs']):
  raw=SEED/item['raw_file'];assert sha(raw)==item['raw_sha256']
  with (ROOT/f'{i}.jsonl').open('w') as out,(ROOT/f'{i}.stderr').open('w') as err:
   child=subprocess.Popen([str(ROOT/'probe'),str(raw)],stdout=out,stderr=err);save(ROOT/f'{i}-child.json',dict(pid=child.pid));rc=child.wait();assert rc==0,rc
  rows=[json.loads(l) for l in (ROOT/f'{i}.jsonl').read_text().splitlines()];assert len(rows)==128
  for j,x in enumerate(rows):assert (x['block'],x['iteration'],x['warmup'],x['mode'])==(j//16,j%16,j%16==0,protocol['order'][j//16]) and x['all_four_channels_exact_scalar']
  print(json.dumps(dict(source=i,complete=True)),flush=True)
 assert sha(ROOT/'probe')==protocol['binary_sha256'];save(ROOT/'complete.json',dict(complete=True,protocol_sha256=sha(ROOT/'protocol.json')))
if __name__=='__main__':main()
