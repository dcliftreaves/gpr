#include "../source/lib/vc5_encoder/headers.h"
#include "vc5_encoder.h"
#include "vc5_decoder.h"
#include "gpr_preview.h"
#include "gpr_gvid.h"
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <mutex>
#include <thread>
#include <vector>
#define REQUIRE(x) do{if(!(x)){std::fprintf(stderr,"color pipeline line %d: %s\n",__LINE__,#x);std::exit(1);}}while(0)
#include "wavelet_row_collector.hpp"
extern "C" int gpr_preview_probe_prefix(const gpr_preview_plan*,const gpr_preview_wavelet_planes*,uint32_t,uint8_t*,size_t,size_t,uint32_t*);
struct Arena{std::vector<unsigned char>bytes;size_t used=0;explicit Arena(size_t n):bytes(n,0){}void*alloc(size_t n){size_t count=(n+63)&~size_t(63);if(count>bytes.size()-used)return nullptr;void*p=bytes.data()+used;used+=count;return p;}};
static thread_local Arena *current=nullptr;static void*allocate(size_t n){return current?current->alloc(n):nullptr;}static void release(void*){}
struct Rows{
 std::array<int16_t,1025>cubic;std::array<RowChannel,3>channels;
 std::array<std::atomic<unsigned>,3> ready;
 std::mutex mutex;std::condition_variable changed;bool pipelined=false;
 Rows():channels{{RowChannel(4096,3072,cubic.data()),RowChannel(4096,3072,cubic.data()),RowChannel(4096,3072,cubic.data())}}{REQUIRE(!ComputeCubicTable(cubic.data(),1025,255));reset();}
 void reset(){for(unsigned c=0;c<3;++c){channels[c].reset();ready[c].store(0);}}
 static void accept(void*user,const vc5_preview_row*r){
  auto&s=*static_cast<Rows*>(user);REQUIRE(r&&r->channel<3);auto&c=s.channels[r->channel];
  unsigned before=std::min(2*c.lower_next,c.height);c.accept(*r);
  unsigned after=std::min(2*c.lower_next,c.height);
  if(s.pipelined&&after!=before){s.ready[r->channel].store(after,std::memory_order_release);
   if(before/16!=after/16||after==c.height){std::lock_guard<std::mutex>lock(s.mutex);s.changed.notify_one();}}
 }
 unsigned prefix(){unsigned n=768;for(auto&r:ready)n=std::min(n,r.load(std::memory_order_acquire));return n;}
};
static std::vector<unsigned char>read(const char*n){std::ifstream f(n,std::ios::binary);return std::vector<unsigned char>((std::istreambuf_iterator<char>(f)),{});}
int main(int argc,char**argv){
 if(argc!=4)return 2;auto raw=read(argv[1]),ref=read(argv[2]),profile=read(argv[3]);REQUIRE(raw.size()==4096u*3072u*2u&&!ref.empty());
 gpr_gvid_config cfg={4096,3072,20,1,3,14,{'R','G','G','B'}};gpr_preview_plan*plan=nullptr;REQUIRE(!gpr_preview_plan_from_profile(&cfg,profile.data(),profile.size(),&plan));gpr_preview_info info={};REQUIRE(!gpr_preview_plan_info(plan,&info));
 std::vector<unsigned char>expected(size_t(info.row_bytes)*info.height),actual(expected.size());REQUIRE(!gpr_preview_plan_render(plan,ref.data(),ref.size(),expected.data(),expected.size(),info.row_bytes,&info));
 std::array<std::vector<int16_t>,3>expected_planes;gpr_buffer reference={ref.data(),ref.size()};vc5_decoder_parameters dp;vc5_decoder_parameters_set_default(&dp);dp.mem_alloc=malloc;dp.mem_free=free;dp.rgb_resolution=GPR_RGB_RESOLUTION_QUARTER;dp.rgb_bits=16;
 for(unsigned c=0;c<3;++c){gpr_rgb_buffer out={};REQUIRE(!vc5_decoder_process_wavelet_channel(&dp,&reference,c,&out));expected_planes[c].assign((int16_t*)out.buffer,(int16_t*)((unsigned char*)out.buffer+out.size));free(out.buffer);}
 Arena arena(192u<<20);Rows rows;gpr_preview_wavelet_planes planes={};planes.width=1024;planes.height=768;for(unsigned c=0;c<3;++c){planes.samples[c]=rows.channels[c].plane.data();planes.sample_count[c]=rows.channels[c].plane.size();}
 vc5_encoder_parameters ep;vc5_encoder_parameters_set_default(&ep);ep.input_width=4096;ep.input_height=3072;ep.input_pitch=8192;ep.pixel_format=VC5_ENCODER_PIXEL_FORMAT_RGGB_14;ep.quality_setting=VC5_ENCODER_QUALITY_SETTING_FS1;ep.mem_alloc=allocate;ep.mem_free=release;gpr_buffer input={raw.data(),raw.size()};
 const unsigned modes[]={0,1,1,0,1,0,0,1};
 for(unsigned block=0;block<8;++block)for(unsigned it=0;it<16;++it){
  rows.reset();rows.pipelined=modes[block];arena.used=0;current=&arena;std::fill(actual.begin(),actual.end(),0xa5);gpr_buffer out={};unsigned rendered=0,chunks=0;double first_ms=0;auto begin=std::chrono::steady_clock::now();
  std::thread color;
  if(rows.pipelined)color=std::thread([&]{unsigned consumed=0;while(consumed<768){unsigned available;{std::unique_lock<std::mutex>lock(rows.mutex);rows.changed.wait(lock,[&]{return rows.prefix()>consumed;});available=rows.prefix();}REQUIRE(!gpr_preview_probe_prefix(plan,&planes,available,actual.data(),actual.size(),info.row_bytes,&rendered));if(!chunks)first_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();++chunks;consumed=available;}});
  REQUIRE(!vc5_encoder_process_with_preview_rows(&ep,&input,&out,nullptr,Rows::accept,&rows));
  double encode_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
  if(rows.pipelined)color.join();else REQUIRE(!gpr_preview_plan_render_wavelets(plan,&planes,actual.data(),actual.size(),info.row_bytes,&info));
  double wall_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
  REQUIRE(out.size==ref.size()&&!memcmp(out.buffer,ref.data(),ref.size()));REQUIRE(actual==expected);
  for(unsigned c=0;c<3;++c)REQUIRE(rows.channels[c].complete()&&rows.channels[c].plane==expected_planes[c]);
  if(rows.pipelined)REQUIRE(rendered==info.height);
  std::printf("{\"block\":%u,\"iteration\":%u,\"warmup\":%s,\"mode\":\"%s\",\"wall_ms\":%.6f,\"encode_ms\":%.6f,\"first_color_ms\":%.6f,\"color_chunks\":%u,\"payload_exact\":true,\"planes_exact\":true,\"calibrated_rgb_exact\":true}\n",block,it,it?"false":"true",rows.pipelined?"progressive-color":"post-color",wall_ms,encode_ms,first_ms,chunks);std::fflush(stdout);
 }
 gpr_preview_plan_destroy(plan);
}
