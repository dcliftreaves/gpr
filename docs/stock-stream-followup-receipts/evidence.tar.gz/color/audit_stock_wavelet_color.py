from pathlib import Path
import json,hashlib,statistics
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_wavelet_color_pipeline_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=json.loads((ROOT/'probe-protocol.json').read_text());done=json.loads((ROOT/'probe-complete.json').read_text());assert done['complete'] and done['protocol_sha256']==sha(ROOT/'probe-protocol.json')
 for name,h in p['sources'].items():assert sha(ROOT/name)==h
 assert sha(Path('analysis/benchmark_stock_wavelet_color.py'))==p['driver_sha256']
 assert sha(Path('/tmp/gpr-color-pipeline-source.tar'))==p['source_tar_sha256']
 sources=[]
 for i in range(2):
  e=[json.loads(l) for l in (ROOT/f'probe-{i}.jsonl').read_text().splitlines()];assert len(e)==128
  for j,x in enumerate(e):
   assert (x['block'],x['iteration'],x['warmup'],x['mode'])==(j//16,j%16,j%16==0,p['order'][j//16])
   assert x['payload_exact'] and x['planes_exact'] and x['calibrated_rgb_exact']
   if x['mode']=='progressive-color':assert x['color_chunks']>1 and 0<x['first_color_ms']<x['encode_ms']
  modes={}
  for mode in ['post-color','progressive-color']:
   a=[x for x in e if not x['warmup'] and x['mode']==mode];assert len(a)==60
   modes[mode]=dict(wall_median_ms=statistics.median(x['wall_ms'] for x in a),encode_median_ms=statistics.median(x['encode_ms'] for x in a),block_wall_medians_ms=[statistics.median(x['wall_ms'] for x in a if x['block']==b) for b in range(8) if p['order'][b]==mode])
  assert min(modes['progressive-color']['block_wall_medians_ms'])>max(modes['post-color']['block_wall_medians_ms'])
  sources.append(dict(source=i,modes=modes,progressive_slower_every_block=True))
 out=dict(complete=True,decision='Reject this extra-color-thread prototype; keep production implementation unchanged.',scope='Independent hashes/event order/warmup/medians audit. Harness compares actual payloads, all reconstructed planes and calibrated RGB every iteration; no capture/storage timing claim.',exact_iterations=256,sources=sources)
 (ROOT/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
