from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/mnt/ssd/gpr_work/stock-wavelet-color-pipeline-20261031');SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def main():
 original=json.loads((SEED/'protocol.json').read_text());binary=ROOT/'build/wavelet_color_pipeline_benchmark';assert os.getuid()==1000 and os.sched_getscheduler(0)==os.SCHED_OTHER and os.getpriority(os.PRIO_PROCESS,0)==0
 protocol=dict(schema='gpr.wavelet_color_probe.v1',base='197d3a94e2458b4f760c426942ccf78a7389d975',source_protocol_sha256=sha(SEED/'protocol.json'),source_tar_sha256=sha(Path('/tmp/gpr-color-pipeline-source.tar')),binary_sha256=sha(binary),driver_sha256=sha(Path(__file__)),sources={n:sha(ROOT/n) for n in ['source/lib/gpr_video/gpr_preview.cpp','tests/wavelet_color_pipeline_benchmark.cpp','CMakeLists.txt','tests/wavelet_row_collector.hpp']},order=['post-color','progressive-color','progressive-color','post-color','progressive-color','post-color','post-color','progressive-color'],iterations_per_block=16,warmup_per_block=1,inputs=original['inputs'],reference_payloads=original['reference_payloads'],profile_sha256=original['profile_sha256'],scope='Experimental test collector/private prefix renderer, ordinary user, exact native stock payload/decoded planes/calibrated RGB per iteration. Single color thread consumes acquired immutable row prefixes during encoding versus existing four-worker rendering after encoding. Includes thread launch/join; no capture/pacing/queues/storage/fsync. No sustained-rate claim.',environment={k:'1' for k in ['GPR_STREAM_UNPACK','GPR_BAND_STREAM','GPR_CHANNEL_ASM','GPR_PIN_CHANNELS','GPR_DIRECT_BANDS','GPR_COMPACT_BANDS']})
 assert not (ROOT/'probe-protocol.json').exists();save(ROOT/'probe-protocol.json',protocol)
 env={k:v for k,v in os.environ.items() if not k.startswith('GPR_')};env.update(protocol['environment'])
 for i,item in enumerate(original['inputs']):
  raw=SEED/item['raw_file'];ref=SEED/f'reference-{i}.vc5';profile=SEED/f'profiles/{i:06d}.gprp'
  assert sha(raw)==item['raw_sha256'] and sha(ref)==original['reference_payloads'][i]['sha256'] and sha(profile)==original['profile_sha256'][i]
  with (ROOT/f'probe-{i}.jsonl').open('w') as out,(ROOT/f'probe-{i}.stderr').open('w') as err:
   child=subprocess.Popen([str(binary),str(raw),str(ref),str(profile)],stdout=out,stderr=err,env=env);save(ROOT/f'probe-{i}-child.json',dict(pid=child.pid));code=child.wait();assert code==0,('probe failed',i,code)
  events=[json.loads(l) for l in (ROOT/f'probe-{i}.jsonl').read_text().splitlines()];assert len(events)==128
  for j,e in enumerate(events):assert e['block']==j//16 and e['iteration']==j%16 and e['warmup']==(j%16==0) and e['mode']==protocol['order'][j//16] and e['payload_exact'] and e['planes_exact'] and e['calibrated_rgb_exact']
  print(json.dumps(dict(source=i,events=len(events),complete=True)),flush=True)
 assert sha(binary)==protocol['binary_sha256'];save(ROOT/'probe-complete.json',dict(complete=True,protocol_sha256=sha(ROOT/'probe-protocol.json')))
if __name__=='__main__':main()
