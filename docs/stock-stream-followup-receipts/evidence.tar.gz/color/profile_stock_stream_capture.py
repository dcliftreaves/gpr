from pathlib import Path
import json,hashlib,subprocess,sys
REPO=Path('/mnt/ssd/gpr_work/stock-wavelet-row-integration-20261031');ROOT=REPO/'profile-after-stream';SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030')
sys.path.insert(0,str(REPO/'tools'));import benchmark_mission1 as bench,stock_video

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 ROOT.mkdir(exist_ok=False);old=json.loads((REPO/'native-abba/protocol.json').read_text());binary=Path(old['binaries']['streamed']['path']);assert sha(binary)==old['binaries']['streamed']['sha256'];command=old['common_command'][:];command[command.index('--frames')+1]='120';clip=ROOT/'profile.gvid';command=[str(binary),*command,'--preview-streamed','--output',str(clip)];data=ROOT/'perf.data'
 launch=ROOT/'launch.json';child=['chrt','--fifo','1','/usr/bin/setpriv','--reuid=1000','--regid=1000','--init-groups','--reset-env','/usr/bin/python3',str(SEED/'launch_stock_policy_user.py'),str(launch),'1',*command]
 perf=['sudo','-n','perf','record','-e','cycles:u','-F','199','-o',str(data),'--',*child]
 save(ROOT/'protocol.json',dict(schema='gpr.stock_stream_profile.v1',binary_sha256=sha(binary),driver_sha256=sha(Path(__file__)),base_protocol_sha256=sha(REPO/'native-abba/protocol.json'),command=perf,scope='120-attempt sampling diagnostic after streaming integration; perf overhead means no rate claim. Child FIFO1 UID1000, only profiler privileged; no global changes. Verify all recording/preview bytes before deleting temporary clip.'))
 with (ROOT/'capture.jsonl').open('w') as out,(ROOT/'perf.stderr').open('w') as err:
  process=subprocess.Popen(perf,stdout=out,stderr=err);save(ROOT/'supervisor.json',dict(pid=process.pid));rc=process.wait();assert rc==0,rc
 subprocess.run(['sudo','-n','chown','1000:1000',str(data)],check=True)
 events=[json.loads(l) for l in (ROOT/'capture.jsonl').read_text().splitlines() if l.startswith('{')];metadata=[stock_video.decode_metadata((SEED/i['metadata_file']).read_bytes()) for i in old['inputs']];offline={r['index']:r for r in map(json.loads,(SEED/'offline.jsonl').read_text().splitlines()) if r.get('event')=='preview'}
 result=bench.verify(clip,events,metadata,[i['sha256'] for i in old['reference_payloads']],offline);result['clip_bytes']=clip.stat().st_size;save(ROOT/'verified.json',result);clip.unlink()
 with (ROOT/'perf-report.txt').open('w') as out:subprocess.run(['perf','report','--stdio','--no-children','--sort','comm,dso,symbol','--percent-limit','0.5','-i',str(data)],stdout=out,check=True)
 save(ROOT/'complete.json',dict(complete=True,binary_after_sha256=sha(binary),perf_sha256=sha(data)));print(json.dumps(dict(complete=True,frames=result['frames_verified'])))
if __name__=='__main__':main()
