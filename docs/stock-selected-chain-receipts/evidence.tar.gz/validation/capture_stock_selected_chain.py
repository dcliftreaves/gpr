from pathlib import Path
import json,hashlib,subprocess,sys
REPO=Path('/mnt/ssd/gpr_work/stock-wavelet-row-integration-20261031');SEED=Path('/mnt/ssd/gpr_work/stock-native12-gopro-20261030');ROOT=REPO/'selected-model-chain-20261031'
sys.path.insert(0,str(REPO/'tools'));import benchmark_mission1 as bench,stock_video

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 ROOT.mkdir(exist_ok=False);p=json.loads((REPO/'native-abba/protocol.json').read_text());binary=Path(p['binaries']['streamed']['path']);assert sha(binary)==p['binaries']['streamed']['sha256'];cmd=p['common_command'][:];cmd[cmd.index('--frames')+1]='2';clip=ROOT/'capture.gvid';cmd=[str(binary),*cmd,'--preview-streamed','--output',str(clip)]
 save(ROOT/'protocol.json',dict(schema='gpr.selected_chain_capture.v1',source_protocol_sha256=sha(REPO/'native-abba/protocol.json'),binary_sha256=sha(binary),driver_sha256=sha(Path(__file__)),command=cmd,scope='Two-frame native streaming recording for downstream selected-model integration; ordinary user, no deadline/rate claim. All payloads/calibration/preview pixels/sourcePTS/END3 verified. Clip retained for transfer.'))
 with (ROOT/'capture.jsonl').open('w') as out,(ROOT/'capture.stderr').open('w') as err:
  child=subprocess.Popen(cmd,stdout=out,stderr=err);save(ROOT/'supervisor.json',dict(pid=child.pid));rc=child.wait();assert rc==0,rc
 events=[json.loads(x) for x in (ROOT/'capture.jsonl').read_text().splitlines()];meta=[stock_video.decode_metadata((SEED/x['metadata_file']).read_bytes()) for x in p['inputs']];offline={x['index']:x for x in map(json.loads,(SEED/'offline.jsonl').read_text().splitlines()) if x.get('event')=='preview'}
 v=bench.verify(clip,events,meta,[x['sha256'] for x in p['reference_payloads']],offline);assert v['frames_verified']==v['previews_verified']==2;save(ROOT/'verified.json',v);assert sha(binary)==p['binaries']['streamed']['sha256'];print(json.dumps(dict(complete=True,clip_sha256=sha(clip))))
if __name__=='__main__':main()
