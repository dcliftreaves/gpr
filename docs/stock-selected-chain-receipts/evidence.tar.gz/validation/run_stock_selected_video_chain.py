from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_selected_video_chain_20261031');BIN=REPO/'build-runtime';PY=Path('/Applications/Xcode.app/Contents/Developer/usr/bin/python3');MLPY=Path('/Users/dcliftreaves/miniforge3/envs/gpr-train/bin/python');ART=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_sr_source_regions_20261030/all-qualified/native/metal-f16');CP=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt';REFERENCE=Path('/private/tmp/gpr-stock-reference/build/source/app/vc5_encoder_app/vc5_encoder_app')
sys.path.insert(0,str(REPO/'tools'));import stock_video,raw_media,stock_still,stock_cnn_metadata

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 clip=ROOT/'capture.gvid';cap=json.loads((ROOT/'verified.json').read_text());assert sha(clip)==cap['clip_sha256'];assert sha(CP)=='f7bda0449b94be4ebd3617297b9dee04506b00e38788dba2d0b04eb71fdaa2f4';assert shutil.disk_usage(ROOT).free>10*(1<<30)
 tools=dict(decoder=BIN/'source/app/stock_video/stock_video',sdk=BIN/'source/app/gpr_tools/gpr_tools',native=BIN/'source/app/stock_metal/gpr_reconstruct',kernels=BIN/'source/app/stock_metal/gpr_stock.metallib',bridge=BIN/'gpr_mov',renderer=BIN/'gpr_render',encoder=BIN/'gpr_prores',probe=Path(shutil.which('ffprobe')),ffmpeg=Path(shutil.which('ffmpeg')),reference=REFERENCE)
 files=['stock_video.py','stock_still.py','stock_native.py','stock_cnn_metadata.py','stock_upres.py','stock_mov.py','stock_prores.py','raw_media.py','stock_sequence.py']
 protocol=dict(schema='gpr.stock_selected_video_chain.v1',source_revision='b09a6cbd8e31dd628e9315bf6fd9c90a5cead969',uncommitted_fix='ProRes cnn_settings now includes standalone native reconstruction; model_info presence selects settings.',source_sha256={n:sha(REPO/'tools'/n) for n in files},driver_sha256=sha(Path(__file__)),capture_sha256=sha(clip),capture_receipt_sha256=sha(ROOT/'verified.json'),checkpoint_sha256=sha(CP),native_artifact_contract_sha256=sha(ART/'contract.json'),binaries={n:dict(path=str(p),sha256=sha(p)) for n,p in tools.items()},model_selection_or_training=False,quality_approval=False,scope='Two-frame integration of fresh Pi public streaming capture with supplied2x model, matched TorchMPS/native counts, editable RAW and explicitQ5 stock reencode/GVID/MOV, direct8K ProRes preserving capture-relative timing. Native media commands under python-S, reference comparator/independent analysis may use ML packages. No motion/sensortruth/sustained-rate/model-tier approval. Historical reference build includes documented bound/sign corrections.',reference_encoder_source_sha256=sha(Path('/private/tmp/gpr-stock-reference/source/lib/vc5_encoder/encoder.c')))
 if (ROOT/'integration-protocol.json').exists():
  original=json.loads((ROOT/'integration-protocol.json').read_text());assert original['source_sha256']==protocol['source_sha256'] and original['binaries']==protocol['binaries'] and original['checkpoint_sha256']==protocol['checkpoint_sha256'] and original['capture_sha256']==sha(clip)
  report=json.loads((ROOT/'integration-steps.json').read_text());assert not report['complete'] and report['steps'][-1]['name']=='torch-reference-numpy-first' and report['steps'][-1]['returncode']==1
  save(ROOT/'resume-protocol-2.json',dict(parent_protocol_sha256=sha(ROOT/'integration-protocol.json'),driver_sha256=sha(Path(__file__)),reason='Optional analysis environment OpenMP duplicate runtime abort before Torch output. Preload NumPy before Torch as in prior matched evaluators; no unsafe duplicate-runtime flag.',native_receipt_sha256=sha(ROOT/'native-restored/receipt.json'),extract_receipt_sha256=sha(ROOT/'extracted/receipt.json')))
 else:
  save(ROOT/'integration-protocol.json',protocol);report=dict(complete=False,protocol_sha256=sha(ROOT/'integration-protocol.json'),steps=[]);save(ROOT/'integration-steps.json',report)
 def run(name,cmd,env=None):
  if any(x['name']==name and x['returncode']==0 for x in report['steps']):return
  cmd=list(map(str,cmd));t=time.monotonic();print(json.dumps(dict(event='starting',step=name)),flush=True)
  with (ROOT/(name+'.stdout')).open('w') as out,(ROOT/(name+'.stderr')).open('w') as err:
   child=subprocess.Popen(cmd,stdout=out,stderr=err,cwd=REPO,env=env);save(ROOT/(name+'-child.json'),dict(pid=child.pid));rc=child.wait()
  report['steps'].append(dict(name=name,command=cmd,returncode=rc,wall_s=time.monotonic()-t));save(ROOT/'integration-steps.json',report);assert rc==0,(name,rc);print(json.dumps(dict(event='completed',step=name)),flush=True)
 std=[PY,'-S'];native=['--native-executable',tools['native'],'--native-artifact',ART,'--native-backend','hybrid','--native-kernels',tools['kernels'],'--native-threads','4'];common=['--checkpoint',CP,'--scale','2','--tile','256','--halo','64']
 run('extract',[*std,REPO/'tools/stock_video.py','extract',clip,'--out-dir',ROOT/'extracted','--decoder',tools['decoder'],'--editable','both'])
 run('native-restore',[*std,REPO/'tools/stock_video.py','restore',clip,'--out-dir',ROOT/'native-restored','--decoder',tools['decoder'],'--editable','dng',*common,*native])
 run('torch-reference-numpy-first-path',[MLPY,'-c','import numpy,runpy,sys,os;sys.argv=sys.argv[1:];sys.path.insert(0,os.path.dirname(sys.argv[0]));runpy.run_path(sys.argv[0],run_name="__main__")',REPO/'tools/stock_video.py','restore',clip,'--out-dir',ROOT/'torch-restored','--decoder',tools['decoder'],'--editable','dng','--device','mps',*common])
 run('direct-prores',[*std,REPO/'tools/stock_prores.py',clip,'--output',ROOT/'direct-native-2x-prores.mov','--decoder',tools['decoder'],'--renderer',tools['renderer'],'--encoder',tools['encoder'],'--ffprobe',tools['probe'],*common,*native])
 run('native-upres',[*std,REPO/'tools/stock_upres.py','--mode','timelapse','--input-mode','captured_gpr','--input',ROOT/'extracted/000000.gpr','--input',ROOT/'extracted/000001.gpr','--reference-kind','camera_gpr_replay','--checkpoint',CP,'--sdk',tools['sdk'],'--output-quality','5','--bridge',tools['bridge'],'--output-dir',ROOT/'upres','--dng-export','--fps-num','20','--fps-den','1','--tile','256','--halo','64',*native])
 for action,source,dest,name in [('wrap',clip,ROOT/'source-private.mov','source-wrap'),('unwrap',ROOT/'source-private.mov',ROOT/'source-roundtrip.gvid','source-unwrap'),('unwrap',ROOT/'upres/timelapse.mov',ROOT/'upres-roundtrip.gvid','upres-unwrap')]:
  run(name,[*std,REPO/'tools/stock_mov.py',action,source,'--bridge',tools['bridge'],'--output',dest])
 assert sha(ROOT/'source-roundtrip.gvid')==sha(clip);assert sha(ROOT/'upres-roundtrip.gvid')==sha(ROOT/'upres/timelapse.gvid')
 environment={k:v for k,v in os.environ.items() if not k.startswith('GPR_')};environment['GPR_BENCH_QUALITY']='5'
 for i in range(2):
  raw=ROOT/f'native-restored/{i:06d}.cnn.raw';reference=ROOT/f'reference-full-{i}.vc5';run(f'historical-encoder-{i}',[REFERENCE,'-i',raw,'-o',reference,'-w','8192','-h','6144','-p','16384'],environment)
  full=ROOT/f'upres/{i:06d}-timelapse/full.gpr';meta,payload=raw_media.extract(full,14,with_payload=True);assert hashlib.sha256(payload).hexdigest()==sha(reference)
 run('decode-prores',[tools['ffmpeg'],'-v','error','-i',ROOT/'direct-native-2x-prores.mov','-f','null','-'])
 for name,p in tools.items():assert sha(p)==protocol['binaries'][name]['sha256']
 report['complete']=True;save(ROOT/'integration-steps.json',report);print(json.dumps(dict(complete=True)),flush=True)
if __name__=='__main__':main()
