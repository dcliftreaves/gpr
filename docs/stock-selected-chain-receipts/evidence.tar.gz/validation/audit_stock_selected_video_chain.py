from pathlib import Path
import hashlib,json,sys
import numpy as np
import tifffile
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_selected_video_chain_20261031');sys.path.insert(0,str(REPO/'tools'))
import stock_video,raw_media,stock_still,stock_cnn_metadata

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def read(n):return json.loads((ROOT/n).read_text())
def main():
 p=read('integration-protocol.json');steps=read('integration-steps.json');assert steps['complete'] and steps['protocol_sha256']==sha(ROOT/'integration-protocol.json')
 for n,h in p['source_sha256'].items():assert sha(REPO/'tools'/n)==h
 for n,o in p['binaries'].items():assert sha(Path(o['path']))==o['sha256']
 assert sha(REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt')==p['checkpoint_sha256']
 with (ROOT/'capture.gvid').open('rb') as f:
  header=stock_video.read_header(f);captured=list(stock_video.records(f,header));assert header['_end_marker_verified'] and len(captured)==2 and header['quality']==3
 native=read('native-restored/receipt.json');torch=read('torch-restored/receipt.json');upres=read('upres/run.json');prores=read('direct-native-2x-prores.mov.json');extracted=read('extracted/receipt.json');rows=[]
 for r in [native,torch,upres,prores]:assert r['complete']
 assert upres['quality_approval'] is False and upres['capture_simulated'] is False and upres['output_quality']==5
 assert prores['cnn_settings']==dict(tile=256,halo=64,device='cpu',scale=2)
 assert prores['cnn']['checkpoint_sha256']==p['checkpoint_sha256'] and prores['cnn']['runtime_backend']=='hybrid'
 for i,c in enumerate(captured):
  metadata=c['metadata']['raw_metadata'];scaled,geometry=stock_cnn_metadata.scaled(metadata,2);payload=hashlib.sha256(c['payload']).hexdigest();n=native['frames'][i];t=torch['frames'][i];u=upres['frames'][i];v=prores['frames'][i]
  assert n['sha256']==t['sha256']==extracted['frames'][i]['sha256']==v['payload_sha256']==payload
  assert n['pts_ns']==t['pts_ns']==v['pts_ns']==c['pts_ns']
  assert n['raw_sha256']==t['raw_sha256']==v['raw_sha256'] and n['native_reconstruction']['input_sha256']==n['raw_sha256']
  assert native['cnn']['checkpoint_sha256']==torch['cnn']['checkpoint_sha256']==upres['model']['checkpoint_sha256']==p['checkpoint_sha256']
  assert n['cnn_sha256']==u['model_raw_sha256']==v['rendered_raw_sha256']
  source_meta,source_payload=raw_media.extract(ROOT/f'extracted/{i:06d}.gpr',14,with_payload=True);assert source_payload==c['payload'] and stock_still.canonical(source_meta)==stock_still.canonical(metadata)
  width,height=8192,6144;nraw=np.memmap(ROOT/f'native-restored/{i:06d}.cnn.raw',dtype='<u2',mode='r',shape=(height,width));traw=np.memmap(ROOT/f'torch-restored/{i:06d}.cnn.raw',dtype='<u2',mode='r',shape=(height,width));maximum=0;changed=0
  for y in range(0,height,64):
   diff=np.abs(nraw[y:y+64].astype(np.int32)-traw[y:y+64].astype(np.int32));maximum=max(maximum,int(diff.max()));changed+=int(np.count_nonzero(diff))
  assert maximum<=32 # existing folded-FP16 native budget, unchanged
  folder=ROOT/f'upres/{i:06d}-timelapse';independent_tiffs=[]
  for path,expected,expected_meta in [(ROOT/f'native-restored/{i:06d}.dng',n['cnn_sha256'],scaled),(folder/'model-output.dng',n['cnn_sha256'],scaled),(folder/'decoded-full.dng',u['final_decoded_raw_sha256'],scaled),(ROOT/f'torch-restored/{i:06d}.dng',t['cnn_sha256'],scaled),(ROOT/f'extracted/{i:06d}.dng',n['raw_sha256'],metadata)]:
   pixels=tifffile.memmap(path);assert pixels.shape==(expected_meta['height'],expected_meta['width']) and pixels.dtype==np.dtype('<u2');digest=hashlib.sha256(pixels.tobytes()).hexdigest();assert digest==expected
   actual=raw_media.extract(path,14);assert stock_still.canonical(actual)==stock_still.canonical(expected_meta);independent_tiffs.append(dict(file=str(path.relative_to(ROOT)),pixel_sha256=digest))
  full_meta,full_payload=raw_media.extract(folder/'full.gpr',14,with_payload=True);assert stock_still.canonical(full_meta)==stock_still.canonical(scaled);assert hashlib.sha256(full_payload).hexdigest()==sha(ROOT/f'reference-full-{i}.vc5')
  assert v['render_calibration_sha256']==hashlib.sha256(stock_still.canonical(scaled)).hexdigest();assert n['native_reconstruction']['model']['artifact_contract_sha256']==p['native_artifact_contract_sha256']
  rows.append(dict(index=i,input_payload_sha256=payload,model_sha256=p['checkpoint_sha256'],native_model_counts_sha256=n['cnn_sha256'],max_native_torch_difference=maximum,differing_samples=changed,samples=width*height,independent_tiff_pixels=independent_tiffs,historical_q5_payload_exact=True,supported_calibration_exact=True,metadata_omissions=geometry.get('omitted',[])))
 assert sha(ROOT/'source-roundtrip.gvid')==sha(ROOT/'capture.gvid')==p['capture_sha256'];assert sha(ROOT/'upres-roundtrip.gvid')==sha(ROOT/'upres/timelapse.gvid')
 with (ROOT/'upres/timelapse.gvid').open('rb') as f:
  h=stock_video.read_header(f);full=list(stock_video.records(f,h));assert h['_end_marker_verified'] and (h['width'],h['height'],h['quality'])==(8192,6144,5)
  assert [x['pts_ns'] for x in full]==[0,50000000]
  for i,x in enumerate(full):
   m,b=raw_media.extract(ROOT/f'upres/{i:06d}-timelapse/full.gpr',14,with_payload=True);assert x['payload']==b and stock_still.canonical(x['metadata']['raw_metadata'])==stock_still.canonical(m)
 stream=prores['verification']['streams'][0];packets=prores['verification']['packets'];assert (stream['width'],stream['height'],stream['codec_name'],stream['profile'],stream['pix_fmt'])==(8192,6144,'prores','HQ','yuv422p10le');assert stream['time_base']=='1/1000000000'
 relative=[x['pts_ns']-captured[0]['pts_ns'] for x in captured];assert [x['pts'] for x in packets]==relative and prores['timing']['maximum_timestamp_error_ns']==0
 assert all(stream[k]=='bt709' for k in ['color_space','color_transfer','color_primaries']);assert sha(ROOT/'direct-native-2x-prores.mov')==prores['output_sha256']
 assert any(x['name']=='decode-prores' and x['returncode']==0 for x in steps['steps'])
 report=dict(schema='gpr.selected_video_chain_audit.v1',complete=True,quality_approval=False,frames=rows,capture_sha256=p['capture_sha256'],mov_roundtrips_exact=True,prores=dict(file='direct-native-2x-prores.mov',bytes=(ROOT/'direct-native-2x-prores.mov').stat().st_size,sha256=prores['output_sha256'],width=8192,height=6144,pixel_format=stream['pix_fmt'],packets=packets,capture_relative_pts_exact=True,independently_decoded_all_frames=True),timelapse_timestamps='synthetic_nominal_20fps',scope='Two-frame integration/exactness and existing32-count backend agreement check. Not a quality improvement, motion, sensortruth, sustained throughput or physical camera approval.')
 (ROOT/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
