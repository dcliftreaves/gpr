from pathlib import Path
import hashlib,json
import numpy as np
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_selected_video_chain_20261031')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def main():
 p=json.loads((ROOT/'pi-protocol.json').read_text());d=json.loads((ROOT/'pi-complete.json').read_text());r=json.loads((ROOT/'pi-portable-2x/receipt.json').read_text());m=json.loads((ROOT/'torch-restored/receipt.json').read_text());n=json.loads((ROOT/'native-restored/receipt.json').read_text());assert d['complete'] and d['protocol_sha256']==sha(ROOT/'pi-protocol.json');assert d['receipt_sha256']==sha(ROOT/'pi-portable-2x/receipt.json')
 assert p['max_cpu_mps_difference_counts']==1 and p['capture_sha256']==sha(ROOT/'capture.gvid');assert p['checkpoint_sha256']==r['cnn']['checkpoint_sha256']==m['cnn']['checkpoint_sha256']==n['cnn']['checkpoint_sha256']
 rows=[]
 for i in range(2):
  cpu=ROOT/f'pi-portable-2x/{i:06d}.cnn.raw';mps=ROOT/f'torch-restored/{i:06d}.cnn.raw';native=ROOT/f'native-restored/{i:06d}.cnn.raw';assert sha(cpu)==d['output_hashes'][cpu.name]==r['frames'][i]['cnn_sha256'];assert r['frames'][i]['raw_sha256']==m['frames'][i]['raw_sha256']==n['frames'][i]['raw_sha256'];assert r['frames'][i]['pts_ns']==m['frames'][i]['pts_ns']
  arrays=[np.memmap(x,dtype='<u2',mode='r',shape=(6144,8192)) for x in [cpu,mps,native]];maximum=0;different=0;native_max=0
  for y in range(0,6144,64):
   a,b,c=[x[y:y+64].astype(np.int32) for x in arrays];delta=np.abs(a-b);maximum=max(maximum,int(delta.max()));different+=int(np.count_nonzero(delta));native_max=max(native_max,int(np.abs(a-c).max()))
  rows.append(dict(index=i,cpu_raw_sha256=sha(cpu),decoded_input_sha256=r['frames'][i]['raw_sha256'],max_cpu_mps_counts=maximum,different_cpu_mps_samples=different,samples=50331648,max_cpu_native_hybrid_counts=native_max,passed_declared_bound=maximum<=p['max_cpu_mps_difference_counts'],cpu_inference_s=r['frames'][i]['cnn_s']))
 result=dict(schema='gpr.selected_chain_pi_comparison.v1',complete=True,passed=all(x['passed_declared_bound'] for x in rows),quality_approval=False,declared_cpu_mps_bound_counts=1,torch_pi=p['torch'],pi_workflow_wall_s=d['wall_s'],frames=rows,scope='Fresh capture supplied-model cross-host execution/count agreement; no lossless sensor target, motion/quality/tier or sustained rate claim.')
 (ROOT/'pi-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert result['passed'],'Existing one-count portability bound failed'
if __name__=='__main__':main()
