from pathlib import Path
import hashlib,json,sys
import numpy as np
import tifffile
ROOT=Path('/mnt/ssd/gpr_work/stock-wavelet-row-integration-20261031/selected-model-chain-20261031');REPO=ROOT.parent
sys.path.insert(0,str(REPO/'tools'));import raw_media,stock_video,stock_still,stock_cnn_metadata

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def main():
 p=json.loads((ROOT/'pi-protocol.json').read_text());done=json.loads((ROOT/'pi-complete.json').read_text());assert done['complete'] and done['protocol_sha256']==sha(ROOT/'pi-protocol.json')
 r=json.loads((ROOT/'pi-portable-2x/receipt.json').read_text());assert r['complete'] and r['end_marker_verified'] and r['cnn']['checkpoint_sha256']==p['checkpoint_sha256'] and r['frame_count']==2
 assert done['receipt_sha256']==sha(ROOT/'pi-portable-2x/receipt.json')
 with (ROOT/'capture.gvid').open('rb') as f:h=stock_video.read_header(f);records=list(stock_video.records(f,h));assert h['_end_marker_verified'] and len(records)==2
 frames=[]
 for i,(source,row) in enumerate(zip(records,r['frames'])):
  raw=ROOT/f'pi-portable-2x/{i:06d}.cnn.raw';dng=ROOT/f'pi-portable-2x/{i:06d}.dng';assert sha(raw)==row['cnn_sha256']==done['output_hashes'][raw.name]
  pixels=tifffile.memmap(dng);assert pixels.shape==(6144,8192) and pixels.dtype==np.dtype('<u2');assert hashlib.sha256(pixels.tobytes()).hexdigest()==sha(raw)
  expected,geometry=stock_cnn_metadata.scaled(source['metadata']['raw_metadata'],2);actual=raw_media.extract(dng,14);assert stock_still.canonical(expected)==stock_still.canonical(actual)
  assert row['pts_ns']==source['pts_ns'] and row['sha256']==hashlib.sha256(source['payload']).hexdigest()
  frames.append(dict(index=i,output_sha256=sha(raw),tiff_pixels_exact=True,supported_calibration_exact=True,pts_ns=row['pts_ns'],decoded_input_sha256=row['raw_sha256'],cnn_s=row['cnn_s'],omissions=geometry.get('omitted',[])))
 result=dict(schema='gpr.selected_chain_pi_dng_audit.v1',complete=True,quality_approval=False,driver_sha256=sha(Path(__file__)),frames=frames)
 (ROOT/'pi-dng-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
