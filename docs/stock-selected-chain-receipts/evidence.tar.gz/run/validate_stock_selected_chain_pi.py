from pathlib import Path
import json,hashlib,subprocess,time,os
REPO=Path('/mnt/ssd/gpr_work/stock-wavelet-row-integration-20261031');ROOT=REPO/'selected-model-chain-20261031';OUT=ROOT/'pi-portable-2x';PY=Path('/mnt/ssd/gpr_work/pr-human-test-env-20261011/bin/python');CP=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt';DEC=Path('/mnt/ssd/gpr_work/stock-raw-media-runtime/build-runtime/source/app/stock_video/stock_video')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 assert os.getuid()==1000 and os.sched_getscheduler(0)==0 and os.getpriority(os.PRIO_PROCESS,0)==0
 assert sha(CP)=='f7bda0449b94be4ebd3617297b9dee04506b00e38788dba2d0b04eb71fdaa2f4';assert sha(ROOT/'capture.gvid')==json.loads((ROOT/'verified.json').read_text())['clip_sha256']
 version=subprocess.check_output([str(PY),'-c','import numpy,torch;print(torch.__version__)'],text=True).strip()
 command=[str(PY),'-c','import numpy,torch,runpy,sys,os;torch.set_num_threads(4);sys.argv=sys.argv[1:];sys.path.insert(0,os.path.dirname(sys.argv[0]));runpy.run_path(sys.argv[0],run_name="__main__")',str(REPO/'tools/stock_video.py'),'restore',str(ROOT/'capture.gvid'),'--out-dir',str(OUT),'--decoder',str(DEC),'--checkpoint',str(CP),'--scale','2','--tile','256','--halo','64','--device','cpu','--editable','dng']
 protocol=dict(schema='gpr.selected_chain_pi.v1',driver_sha256=sha(Path(__file__)),command=command,torch=version,checkpoint_sha256=sha(CP),capture_sha256=sha(ROOT/'capture.gvid'),decoder_sha256=sha(DEC),sources={n:sha(REPO/'tools'/n) for n in ['stock_video.py','stock_cnn_models.py','stock_cnn_metadata.py','raw_media.py','stock_still.py']},max_cpu_mps_difference_counts=1,quality_approval=False,scope='Fresh native streaming input selected2x portable PiCPU execution; match exact input/model/calibration and independent MacMPS count comparison after transfer. Four threads ordinary user; offline time not recording floor/quality approval.')
 assert not (ROOT/'pi-protocol.json').exists();save(ROOT/'pi-protocol.json',protocol);start=time.monotonic()
 with (ROOT/'pi-restore.stdout').open('w') as out,(ROOT/'pi-restore.stderr').open('w') as err:
  child=subprocess.Popen(command,stdout=out,stderr=err);save(ROOT/'pi-child.json',dict(pid=child.pid));rc=child.wait();assert rc==0,rc
 r=json.loads((OUT/'receipt.json').read_text());assert r['complete'] and r['end_marker_verified'] and r['frame_count']==2 and r['cnn']['checkpoint_sha256']==sha(CP)
 save(ROOT/'pi-complete.json',dict(complete=True,protocol_sha256=sha(ROOT/'pi-protocol.json'),wall_s=time.monotonic()-start,output_hashes={p.name:sha(p) for p in sorted(OUT.glob('*.cnn.raw'))},receipt_sha256=sha(OUT/'receipt.json')));print(json.dumps(dict(complete=True)),flush=True)
if __name__=='__main__':main()
