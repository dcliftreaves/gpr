"""Diagnostic actual renders of the fixed cascade; RAW failures still disqualify it."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
import numpy as np,tifffile
from render_stock_sr_sensor_gate import score
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime')
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');ROOT=BASE/'stock_cnn_cascade_20261031';PARENT=BASE/'stock_sr_sensor_gate_20261031/render-validation'
RENDER=REPO/'build-runtime/gpr_render'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
    raw=json.loads((ROOT/'selection.json').read_text());old=json.loads((PARENT/'selection.json').read_text());assert raw['complete'] and old['complete']
    pp=json.loads((PARENT/'protocol.json').read_text());assert sha(RENDER)==pp['renderer_sha256']
    protocol=ROOT/'render-protocol.json';assert not protocol.exists();save(protocol,dict(schema='gpr.stock_cnn_cascade_render_protocol.v1',driver_sha256=sha(Path(__file__)),score_source_sha256=sha(Path(__file__).with_name('render_stock_sr_sensor_gate.py')),raw_selection_sha256=sha(ROOT/'selection.json'),baseline_render_sha256=sha(PARENT/'selection.json'),renderer_sha256=sha(RENDER),scope='Fixedpipeline diagnostic on all10validationimages. AlreadyfailedRAWguard, so renderingcannotqualifyit. Reference/SR-onlyTIFFsfromsamecurrentrenderer+numericallyequivalentmetadataarehashverified andreused.',quality_approval=False,final_pixels_used=False))
    shutil.copy2(Path(__file__),ROOT/Path(__file__).name);report=dict(schema='gpr.stock_cnn_cascade_render.v1',complete=False,protocol_sha256=sha(protocol),sources=[],quality_approval=False);total=0.;bt=0.;pixels=0
    for i,row in enumerate(raw['sources']):
        source=old['sources'][i];work=ROOT/f'source-{i:02d}';prior=PARENT/f'source-{i:02d}';ref=prior/'reference.tiff';single=prior/'supplied.tiff';assert sha(ref)==source['tiff_sha256']['reference'] and sha(single)==source['tiff_sha256']['supplied'];assert sha(work/'cascade.dng')==row['dng_sha256']
        result=subprocess.run([str(RENDER),str(work/'cascade.dng'),str(work/'cascade.tiff')],capture_output=True,text=True);(work/'render.stderr').write_text(result.stderr);assert result.returncode==0;record=json.loads(result.stdout);save(work/'render.json',record)
        for key in ['width','height','decoder','baseline_exposure','neutral_temperature','neutral_tint','source_orientation','lens_correction_enabled']:assert record[key]==source['render_receipts']['reference'][key]
        with tifffile.TiffFile(ref) as f:reference=f.asarray()
        with tifffile.TiffFile(work/'cascade.tiff') as f:cascade=f.asarray()
        metrics=score(reference,cascade);baseline=source['scores']['supplied'];failed=[key for key in ['rgb_mse','y_prime_mse'] if metrics[key]>baseline[key]];n=metrics['pixels'];pixels+=n;total+=n*metrics['rgb_mse'];bt+=n*baseline['rgb_mse']
        report['sources'].append(dict(source_index=i,metrics=metrics,sr_only_metrics=baseline,regressions=failed,render_receipt=record,tiff_sha256=sha(work/'cascade.tiff')));save(ROOT/'render-selection.json',report)
        print(json.dumps(dict(source_index=i,regressions=failed,rgb_gain_db=float(10*np.log10(baseline['rgb_mse']/metrics['rgb_mse'])))),flush=True)
        del reference,cascade
    report.update(complete=True,pooled_rgb_gain_db_vs_sr=float(10*np.log10(bt/total)),all_rendered_regions_pass=all(not r['regressions'] for r in report['sources']),all_raw_regions_pass=raw['all_raw_regions_pass'],selected=None,reason='RAW guard failures prevent promotion regardless of rendering');save(ROOT/'render-selection.json',report);print(json.dumps(dict(complete=True,rgb_gain_db=report['pooled_rgb_gain_db_vs_sr'],all_rendered_pass=report['all_rendered_regions_pass'],all_raw_pass=report['all_raw_regions_pass'])),flush=True)
if __name__=='__main__':main()
