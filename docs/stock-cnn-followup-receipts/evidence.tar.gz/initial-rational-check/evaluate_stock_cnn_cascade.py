"""Frozen stock cleanup-then-SR composition on all ten validation sources."""
from pathlib import Path
import hashlib,json,shutil,sys,time
import numpy as np
import torch
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'))
import stock_video,stock_cnn_metadata,raw_media,stock_still
from benchmark_stills import quality
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');PARENT=BASE/'stock_sr_sensor_gate_20261031';ROOT=BASE/'stock_cnn_cascade_20261031'
CLEANUP=REPO/'models/stock-q3-rggb14-cleanup/selected.pt';SR=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
    ROOT.mkdir(exist_ok=False);sources=json.loads((PARENT/'full-sources.json').read_text());assert len(sources)==10
    protocol=dict(schema='gpr.stock_cnn_cascade_protocol.v1',driver_sha256=sha(Path(__file__)),sources_sha256=sha(PARENT/'full-sources.json'),cleanup_sha256=sha(CLEANUP),sr_sha256=sha(SR),sources=sources,stages=['Unchanged frozen1xcleanup on decoded native stockQ3 low counts, whole-frame256tile64halo','Unchanged frozen2xSR on cleaned low counts, whole-frame256tile64halo'],intermediate='Rounded uint16 original-domain RAW; no intermediate compression/re-encoding or calibration change',selection='All10completevalidation sources, per-image4RAWregions <=BOTHbicubicandSR-only. Allsettingsmustthenpass actualmatchedRGB/Y-prime nonregression vsSR-onlyonall10 beforefreeze/final. No weights/strength/threshold selection.',final_pixels_used=False,quality_approval=False,limitations=['Previousindividualmodelqualitydoesnotqualifycomposition/inputdistribution.','Historical cameraGPRcounts/recoveredmetadata and reusedNikon validation, notblind/sensortruth/temporalapproval.'])
    save(ROOT/'protocol.json',protocol);shutil.copy2(Path(__file__),ROOT/Path(__file__).name);torch.set_num_threads(4);device=torch.device('mps')
    clean,_=stock_video.load_cnn(None,CLEANUP,device);sr,_=stock_video.load_cnn(None,SR,device)
    report=dict(schema='gpr.stock_cnn_cascade.v1',complete=False,protocol_sha256=sha(ROOT/'protocol.json'),sources=[],quality_approval=False);started=time.perf_counter()
    for i,entry in enumerate(sources):
        s=entry['source'];source=Path(s['path']);assert sha(source)==s['sha256'];meta=raw_media.extract(source,14);w,h=meta['width'],meta['height'];work=ROOT/f'source-{i:02d}';work.mkdir()
        if entry['domain']=='nikon':
            old=BASE/'stock_sr_source_regions_20261030/all-qualified/full-validation';p=json.loads((old/'protocol.json').read_text());index=next(j for j,r in enumerate(p['validation_sources']) if r['sha256']==s['sha256']);cache=old/f'validation-{index}';refpath=cache/'independent-sdk.raw';raw=cache/'decoded-low.raw'
        else:refpath=BASE/'mission1p_source_scan_20260616/raw50_decode'/(s['stem']+'.raw');raw=Path(entry['dataset'])/f"source-{entry['source_index']:03d}/decoded.raw"
        assert sha(refpath)==s['reference_raw_sha256'] and sha(raw)==s['low_decoded_raw_sha256'];reference=np.fromfile(refpath,dtype='<u2').reshape(h,w)
        prior=PARENT/'render-validation'/f'source-{i:02d}/supplied.dng'
        import tifffile
        with tifffile.TiffFile(prior) as f:single=f.asarray()
        sm=quality(reference,single,meta);baseline=json.loads((PARENT/'full-selection.json').read_text())['sources'][i]['bicubic_metrics']
        cleaned,t1=stock_video.restore(raw,w//2,h//2,clean,device,256,64,1);assert cleaned.shape==(h//2,w//2) and cleaned.dtype==np.dtype('<u2');lowpath=work/'cleaned-low.raw';cleaned.tofile(lowpath)
        out,t2=stock_video.restore(lowpath,w//2,h//2,sr,device,256,64,2);assert out.shape==(h,w) and out.max()<=16383;outpath=work/'cascade.raw';out.tofile(outpath);metrics=quality(reference,out,meta)
        regions=['active','shadow_bottom_decile','highlight_top_decile','detail_top_decile'];failed=[r for r in regions if metrics[r]['rmse_counts']>baseline[r]['rmse_counts'] or metrics[r]['rmse_counts']>sm[r]['rmse_counts']]
        lowmeta,omitted=stock_cnn_metadata.simulated_half(meta);stage1meta,_=stock_cnn_metadata.scaled(lowmeta,1);highmeta,_=stock_cnn_metadata.scaled(stage1meta,2);supported={**meta,'image':[r for r in meta['image'] if r['code']!=700]};assert stock_still.canonical(highmeta)==stock_still.canonical(supported)
        raw_media.write(work/'cascade.dng',highmeta,out.tobytes())
        with tifffile.TiffFile(work/'cascade.dng') as f:assert np.array_equal(f.asarray(),out)
        assert stock_still.canonical(raw_media.extract(work/'cascade.dng',14))==stock_still.canonical(highmeta)
        row=dict(source_index=i,source=entry,metrics=metrics,sr_only_metrics=sm,bicubic_metrics=baseline,regressions=failed,raw_sha256=sha(outpath),dng_sha256=sha(work/'cascade.dng'),cleaned_low_sha256=sha(lowpath),no_intermediate_reencode=True,supported_metadata_roundtrip_exact=True,editable_pixels_exact=True,cleanup_s=t1,sr_s=t2,omissions=omitted)
        report['sources'].append(row);save(ROOT/'selection.json',report);print(json.dumps(dict(source_index=i,regressions=failed,gain_db_vs_sr=metrics['active']['psnr_db']-sm['active']['psnr_db'],elapsed_s=time.perf_counter()-started)),flush=True)
        del reference,single,cleaned,out;torch.mps.empty_cache()
    report.update(complete=True,all_raw_regions_pass=all(not s['regressions'] for s in report['sources']),selected=None,actual_render_required=True);save(ROOT/'selection.json',report);print(json.dumps(dict(complete=True,all_raw_regions_pass=report['all_raw_regions_pass'])),flush=True)
if __name__=='__main__':main()
