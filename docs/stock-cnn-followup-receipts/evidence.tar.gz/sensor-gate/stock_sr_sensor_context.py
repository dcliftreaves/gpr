"""Research-only sensor-context wrapper and input-derived correction gate."""
import numpy as np
import torch

PEAK=16383.
RAMPS=(.03,.15,.65,.9)

def predict(model,x,coords,black,white,canonical):
    gain=14884./(white-black) if canonical else torch.ones_like(black)
    offset=(1008.-black*gain)/PEAK if canonical else torch.zeros_like(black)
    return ((model(torch.cat([x*gain+offset,coords],1))-offset)/gain).clamp(0,1)

class ContextNetwork(torch.nn.Module):
    def __init__(self,model,black,white,canonical):
        super().__init__();self.model=model;self.canonical=canonical
        self.register_buffer('black',torch.tensor(black,dtype=torch.float32).reshape(1,4,1,1))
        self.register_buffer('white',torch.tensor(white,dtype=torch.float32).reshape(1,1,1,1))
    def forward(self,x):return predict(self.model,x[:,:4],x[:,4:6],self.black,self.white,self.canonical)

def correction(base,pred,black,white,alpha,domain='canonical'):
    b=base.astype(np.float64)
    if b.ndim==3:
        bl=np.asarray(black,np.float64).reshape(4,1,1);wh=float(white)
    elif b.ndim==4:
        bl=np.asarray(black,np.float64).reshape(-1,4,1,1);wh=np.asarray(white,np.float64).reshape(-1,1,1,1)
    else:raise ValueError('requires four packed Bayer planes, optionally batched')
    if not np.all(wh>bl):raise ValueError('white must exceed each black level')
    gate_input=(b-bl)*14884./(wh-bl)+1008. if domain=='canonical' else b
    a,c,d,e=RAMPS;v=gate_input/PEAK
    gain=float(alpha)*np.clip((v-a)/(c-a),0,1)*np.clip((e-v)/(e-d),0,1)
    return np.clip(np.floor(b+gain*(pred.astype(np.float64)-b)+.5),0,PEAK).astype('<u2')

def interleave(planes):
    _,h,w=planes.shape;out=np.empty((2*h,2*w),dtype='<u2')
    for c in range(4):out[c//2::2,c%2::2]=planes[c]
    return out

def proxy_mse(reference,output,black,white,wb):
    total=0.;count=0
    for start in range(0,reference.shape[0],128):
        end=min(start+128,reference.shape[0]);values=[]
        for raw in [reference,output]:
            planes=np.stack([raw[start+c//2:end:2,c%2::2] for c in range(4)]).astype(np.float64)
            signal=np.clip((planes-np.asarray(black)[:,None,None])/(white-np.asarray(black))[:,None,None]*np.asarray(wb)[:,None,None],0,1)
            values.append(np.sqrt(np.stack([signal[0],.5*(signal[1]+signal[2]),signal[3]])+1e-4))
        delta=values[1]-values[0];total+=float(np.square(delta).sum());count+=delta.size
    return total/count
