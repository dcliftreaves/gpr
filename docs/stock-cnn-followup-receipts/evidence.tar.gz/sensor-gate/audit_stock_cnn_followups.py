"""Audit fixed-family selection and independently recompute rendered scores."""
from pathlib import Path
import hashlib,json,math
import numpy as np,tifffile
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');GATE=BASE/'stock_sr_sensor_gate_20261031';CASCADE=BASE/'stock_cnn_cascade_20261031'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def independent(reference,value):
    total=0.;ytotal=0.;n=reference.shape[0]*reference.shape[1];w=[.2126,.7152,.0722]
    with np.errstate(all='raise'):
        for y in range(0,len(reference),32):
            e=[value[y:y+32,:,c].astype(np.float64)-reference[y:y+32,:,c] for c in range(3)];s=[float(np.sum(v*v)) for v in e];total+=sum(s);ytotal+=sum(a*a*b for a,b in zip(w,s))
            for a,b in [(0,1),(0,2),(1,2)]:ytotal+=2*w[a]*w[b]*float(np.sum(e[a]*e[b]))
    return dict(rgb_mse=total/(3*n),y_prime_mse=ytotal/n)
def main():
    p=load(GATE/'patch-selection.json');f=load(GATE/'full-selection.json');r=load(GATE/'render-validation/selection.json');c=load(CASCADE/'selection.json');cr=load(CASCADE/'render-selection.json');assert all(x['complete'] for x in [p,f,r,c,cr])
    assert len(p['rows'])==18 and len(f['sources'])==len(r['sources'])==len(c['sources'])==len(cr['sources'])==10
    for row in p['rows']:
        bad=[g+':'+k for g,d in p['baseline']['regions'].items() for k,v in d.items() if row['metrics']['regions'][g][k]>v]
        pb=[g for g,v in p['baseline']['tone_proxy_mse'].items() if row['metrics']['tone_proxy_mse'][g]>v]
        assert bad==row['regressions'] and pb==row['proxy_regressions'] and row['eligible']==(not bad and not pb and row['gain_db']>0)
    qualified=[x for x in p['rows'] if x['eligible']];assert [x['id'] for x in qualified]==['parent-sensor','parent-canonical']
    n=0;bt=0.;totals={x['id']:0. for x in qualified};bad={x['id']:[] for x in qualified};full_count=0
    for i,row in enumerate(f['sources']):
        bm=row['bicubic_metrics'];top,left,bottom,right=bm['active_area'];samples=(bottom-top)*(right-left);n+=samples;bt+=samples*bm['active']['rmse_counts']**2
        assert [x['id'] for x in row['candidates']]==[x['id'] for x in qualified]
        for x in row['candidates']:
            assert sha(GATE/f"{i}-{x['id']}.raw")==x['output_sha256'];full_count+=1
            failed=[k for k in ['active','shadow_bottom_decile','highlight_top_decile','detail_top_decile'] if x['metrics'][k]['rmse_counts']>bm[k]['rmse_counts']]
            if x['tone_proxy_mse']>row['bicubic_proxy_mse']:failed.append('tone_proxy')
            assert failed==x['regressions'];bad[x['id']].extend(dict(source_index=i,region=k) for k in failed);totals[x['id']]+=samples*x['metrics']['active']['rmse_counts']**2
    for x in f['results']:
        assert x['regressions']==bad[x['id']] and x['active_mse']==totals[x['id']]/n and math.isclose(x['gain_db'],10*math.log10(bt/totals[x['id']]),abs_tol=1e-11)
        assert x['eligible']==(not bad[x['id']] and totals[x['id']]<bt)
    assert [x['id'] for x in f['render_candidates']]==['parent-sensor']
    old=CASCADE.with_name(CASCADE.name+'-initial-rational-check')
    for file in ['source-00/cascade.raw','source-00/cleaned-low.raw']:assert sha(old/file)==sha(CASCADE/file)
    for i,row in enumerate(c['sources']):
        assert sha(CASCADE/f'source-{i:02d}/cascade.raw')==row['raw_sha256'] and sha(CASCADE/f'source-{i:02d}/cascade.dng')==row['dng_sha256']
        failed=[k for k in ['active','shadow_bottom_decile','highlight_top_decile','detail_top_decile'] if row['metrics'][k]['rmse_counts']>row['bicubic_metrics'][k]['rmse_counts'] or row['metrics'][k]['rmse_counts']>row['sr_only_metrics'][k]['rmse_counts']]
        assert failed==row['regressions'] and row['editable_pixels_exact'] and row['no_intermediate_reencode'] and row['supported_metadata_numeric_equivalence']
    checks=[]
    for i in range(10):
        root=GATE/'render-validation'/f'source-{i:02d}';previous=r['sources'][i];assert sha(root/'reference.tiff')==previous['tiff_sha256']['reference']
        with tifffile.TiffFile(root/'reference.tiff') as tf:reference=tf.asarray()
        scores={}
        for label,path,expected in [('supplied',root/'supplied.tiff',previous['scores']['supplied']),('gate',root/'parent-sensor.tiff',previous['scores']['parent-sensor']),('cascade',CASCADE/f'source-{i:02d}/cascade.tiff',cr['sources'][i]['metrics'])]:
            if label=='cascade':assert sha(path)==cr['sources'][i]['tiff_sha256']
            else:assert sha(path)==previous['tiff_sha256']['supplied' if label=='supplied' else 'parent-sensor']
            with tifffile.TiffFile(path) as tf:value=tf.asarray()
            scores[label]=independent(reference,value)
            for key,actual in scores[label].items():assert np.isclose(actual,expected[key],rtol=1e-10,atol=1e-8)
            del value
        gatebad=[key for key in ['rgb_mse','y_prime_mse'] if scores['gate'][key]>scores['supplied'][key]];cascadebad=[key for key in ['rgb_mse','y_prime_mse'] if scores['cascade'][key]>scores['supplied'][key]]
        assert gatebad==previous['candidate_failures']['parent-sensor'] and cascadebad==cr['sources'][i]['regressions'];checks.append(dict(source_index=i,independent_rgb_yprime_agreement=True,gate_regressions=gatebad,cascade_regressions=cascadebad));del reference
        print(json.dumps(dict(audited_render_source=i)),flush=True)
    assert r['selected'] is None and cr['selected'] is None and not c['all_raw_regions_pass']
    result=dict(schema='gpr.stock_cnn_followup_audit.v1',complete=True,script_sha256=sha(Path(__file__)),patch_family=18,patch_qualified=2,full_outputs_verified=full_count,full_qualified=1,render_gate_selected=None,cascade_raw_outputs_verified=10,cascade_selected=None,independent_render_scores=30,render_checks=checks,cascade_initial_inference_outputs_unchanged=True,quality_approval=False)
    (GATE/'followup-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(complete=True,selected=None)))
if __name__=='__main__':main()
