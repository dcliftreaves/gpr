"""Actual renderer gate for every complete-image-qualified setting versus BIBO."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
import numpy as np
import torch,tifffile
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'))
import raw_media,stock_video,stock_still
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');ROOT=BASE/'stock_sr_sensor_gate_20261031'
CP=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt';RENDER=REPO/'build-runtime/gpr_render'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def score(reference,value):
    rgb=0.;yy=0.;n=0
    with np.errstate(all='raise'):
        for start in range(0,len(reference),64):
            e=value[start:start+64,:,:3].astype(np.float64)-reference[start:start+64,:,:3];rgb+=float(np.square(e).sum());y=.2126*e[:,:,0]+.7152*e[:,:,1]+.0722*e[:,:,2];yy+=float(np.square(y).sum());n+=y.size
    return dict(rgb_mse=rgb/(n*3),y_prime_mse=yy/n,pixels=n)
def main():
    full=json.loads((ROOT/'full-selection.json').read_text());assert full['complete'];candidates=full['render_candidates'];assert candidates
    root=ROOT/'render-validation';root.mkdir(exist_ok=False)
    protocol=dict(schema='gpr.stock_sr_sensor_gate_render_protocol.v1',driver_sha256=sha(Path(__file__)),full_selection_sha256=sha(ROOT/'full-selection.json'),supplied_model_sha256=sha(CP),renderer_sha256=sha(RENDER),candidates=candidates,
        comparison='Every full-qualified setting on all10validation sources. Fresh reference/bicubic/supplied-BIBO/candidate16bitRGBARec709 renders, same supported highmetadata and renderer settings. Selection requires each source RGB ANDY-prime MSE <= SUPPLIED BIBO, strict pooledRGBimprovement; choose lowest pooledRGBMSE then freeze, before any final reference.',
        final_pixels_used=False,quality_approval=False,limitations=['Historical/reused references and archived calibration, not blind or sensortruth.','Rendered fidelity is not recovered texture/temporal approval.'])
    save(root/'protocol.json',protocol);shutil.copy2(Path(__file__),root/Path(__file__).name)
    report=dict(schema='gpr.stock_sr_sensor_gate_render.v1',complete=False,protocol_sha256=sha(root/'protocol.json'),sources=[],quality_approval=False);bad={c['id']:[] for c in candidates};totals={c['id']:0. for c in candidates};btotal=0.;pixels=0;torch.set_num_threads(4);started=time.perf_counter()
    for i,row in enumerate(full['sources']):
        entry=row['source'];s=entry['source'];source=Path(s['path']);assert sha(source)==s['sha256'];meta=raw_media.extract(source,14);w,h=meta['width'],meta['height'];meta['image']=[r for r in meta['image'] if r['code']!=700]
        if entry['domain']=='nikon':
            parent=BASE/'stock_sr_source_regions_20261030/all-qualified/full-validation';p=json.loads((parent/'protocol.json').read_text());index=next(j for j,r in enumerate(p['validation_sources']) if r['sha256']==s['sha256']);cache=parent/f'validation-{index}';refpath=cache/'independent-sdk.raw';raw=cache/'decoded-low.raw'
        else:refpath=BASE/'mission1p_source_scan_20260616/raw50_decode'/(s['stem']+'.raw');raw=Path(entry['dataset'])/f"source-{entry['source_index']:03d}/decoded.raw"
        assert sha(refpath)==s['reference_raw_sha256'] and sha(raw)==s['low_decoded_raw_sha256']
        work=root/f'source-{i:02d}';work.mkdir();reference=np.fromfile(refpath,dtype='<u2').reshape(h,w)
        model,_=stock_video.load_cnn(None,CP,torch.device('mps'));supplied,_=stock_video.restore(raw,w//2,h//2,model,torch.device('mps'),256,64,2);del model;torch.mps.empty_cache()
        arrays={'reference':reference,'supplied':supplied}
        # Bicubic has already been checked numerically; render it for comparison.
        from benchmark_stock_sr import Bicubic
        base,_=stock_video.restore(raw,w//2,h//2,Bicubic(),torch.device('mps'),256,64,2);assert hashlib.sha256(base.tobytes()).hexdigest()==row['bicubic_raw_sha256'];arrays['bicubic']=base
        for c in candidates:
            cp=ROOT/f"{i}-{c['id']}.raw";old=next(r for r in row['candidates'] if r['id']==c['id']);assert sha(cp)==old['output_sha256'];arrays[c['id']]=np.fromfile(cp,dtype='<u2').reshape(h,w)
        records={};renders={}
        for name,array in arrays.items():
            path=work/(name+'.dng');raw_media.write(path,meta,array.astype('<u2').tobytes());assert stock_still.canonical(raw_media.extract(path,14))==stock_still.canonical(meta)
            result=subprocess.run([str(RENDER),str(path),str(work/(name+'.tiff'))],capture_output=True,text=True);(work/(name+'.stderr')).write_text(result.stderr);assert result.returncode==0
            record=json.loads(result.stdout);save(work/(name+'.json'),record);records[name]=record
            with tifffile.TiffFile(work/(name+'.tiff')) as f:r=f.asarray()
            assert r.dtype==np.uint16 and r.shape[-1]==4 and record['bits_per_component']==16 and record['color_space']=='ITU-R BT.709';renders[name]=r
        for record in records.values():
            for key in ['width','height','decoder','baseline_exposure','neutral_temperature','neutral_tint','source_orientation','lens_correction_enabled']:assert record[key]==records['reference'][key]
        scores={name:score(renders['reference'],value) for name,value in renders.items() if name!='reference'};n=scores['supplied']['pixels'];pixels+=n;btotal+=n*scores['supplied']['rgb_mse']
        for c in candidates:
            name=c['id'];m=scores[name];failed=[key for key in ['rgb_mse','y_prime_mse'] if m[key]>scores['supplied'][key]];bad[name].extend(dict(source_index=i,metric=key) for key in failed);totals[name]+=n*m['rgb_mse']
        report['sources'].append(dict(source_index=i,source=entry,scores=scores,render_receipts=records,tiff_sha256={name:sha(work/(name+'.tiff')) for name in renders},candidate_failures={c['id']:[key for key in ['rgb_mse','y_prime_mse'] if scores[c['id']][key]>scores['supplied'][key]] for c in candidates}));save(root/'selection.json',report)
        print(json.dumps(dict(source_index=i,regressions=report['sources'][-1]['candidate_failures'],elapsed_s=time.perf_counter()-started)),flush=True)
        del arrays,renders,reference,supplied,base
    results=[dict(id=c['id'],pooled_rgb_mse=totals[c['id']]/pixels,gain_db_vs_supplied=float(10*np.log10(btotal/totals[c['id']])),regressions=bad[c['id']],eligible=not bad[c['id']] and totals[c['id']]<btotal) for c in candidates];eligible=[r for r in results if r['eligible']]
    report.update(complete=True,results=results,selected=min(eligible,key=lambda r:r['pooled_rgb_mse']) if eligible else None,baseline_rgb_mse=btotal/pixels,rendered_pixels=pixels);save(root/'selection.json',report);print(json.dumps(dict(complete=True,results=results,selected=report['selected'])),flush=True)
if __name__=='__main__':main()
