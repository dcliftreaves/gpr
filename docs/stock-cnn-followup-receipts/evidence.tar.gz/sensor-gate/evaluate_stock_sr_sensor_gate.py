"""Frozen sensor-aware gate family: patches then every qualified complete image."""
from pathlib import Path
import hashlib,json,shutil,sys,time
import numpy as np
import torch
import torch.nn.functional as F
import stock_sr_sensor_context as context
import stock_sr_historical_boundary as boundary
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'))
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');PARENT=BASE/'stock_sr_calibrated_mixed_20261031';ROOT=BASE/'stock_sr_sensor_gate_20261031'
CAMERA=BASE/'stock_sr_mission_calibrated_20261031-metadata-v2/dataset';NIKON=BASE/'stock_sr_20261028/dataset'
sys.path.insert(0,str(PARENT))
import mission1_sr_models,mission1_sr_runtime,train_stock_sr,raw_media,stock_video,benchmark_stock_sr
from benchmark_stills import quality
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
    ROOT.mkdir(exist_ok=False);parent=json.loads((PARENT/'training.json').read_text());assert parent['complete']
    models=[];family=[]
    for case in parent['cases']:
        for checkpoint in case['checkpoints']:
            name=case['case']['name']+'-'+str(checkpoint['step']);models.append(dict(id=name,path=checkpoint['path'],sha256=checkpoint['checkpoint_sha256'],canonical=case['case']['canonical'],parent=checkpoint))
            family.extend(dict(id=name+'-canonical-'+str(a),model=name,domain='canonical',alpha=a) for a in [1.,.5])
    frozen=json.loads((BASE/'stock_sr_historical_boundary_20261031/frozen.json').read_text());models.append(dict(id='parent',path=frozen['checkpoint_path'],sha256=frozen['checkpoint_sha256'],canonical=False))
    family.extend(dict(id='parent-'+domain,model='parent',domain=domain,alpha=1.) for domain in ['sensor','canonical']);assert len(models)==9 and len(family)==18
    protocol=dict(schema='gpr.stock_sr_sensor_gate_protocol.v1',driver_sha256=sha(Path(__file__)),context_source_sha256=sha(Path(context.__file__)),tiler_source_sha256=sha(Path(boundary.__file__)),parent_training_sha256=sha(PARENT/'training.json'),nikon_dataset_sha256=sha(NIKON/'dataset.json'),camera_dataset_sha256=sha(CAMERA/'dataset.json'),camera_carrier_sha256=sha(CAMERA.parent/'carrier-proof.json'),models=models,family=family,ramps=context.RAMPS,
        gate='Per-site rounded bicubic input mapped by source black/white levels into canonical1008..15892 before existing fixed ramps; float64 count postblend and half-up rounding. Parent sensor-domain control preserves previous gate. No reference at inference.',
        selection='Same320patch RAW pooled/group4region and tone-proxy nonregression; strict pooled improvement. Every qualified setting on all10fullvalidationimages with per-image RAW4region+tone-proxy nonregression. ALLfull-qualified settings must then pass matched actual Rec709 RGB/Y-prime nonregression versus SUPPLIED BIBO on every source before selecting lowest pooled rendered RGB MSE/freeze/finals.',
        final_pixels_used=False,checkpoint_retuned=False,quality_approval=False,torch=torch.__version__,limitations=['Historical archived camera references/printed calibration, not fresh originals or sensor truth.','Pretraining overlap and reused validation, not blind.','Proxy is not actual renderer; no native/Pi/temporal or restored-detail promotion.'])
    save(ROOT/'protocol.json',protocol)
    for path in [Path(__file__),Path(context.__file__),Path(boundary.__file__),PARENT/'mission1_sr_models.py',PARENT/'mission1_sr_runtime.py']:shutil.copy2(path,ROOT/path.name)
    # Canonical gate is exactly the old count gate for Nikon calibration.
    b=np.broadcast_to(np.arange(16384,dtype=np.uint16).reshape(1,128,128),(4,128,128)).copy();p=(16383-b).astype('<u2')
    for a in [1.,.5]:assert np.array_equal(context.correction(b,p,[1008]*4,15892,a),boundary.correction(b,p,a,list(context.RAMPS)))
    save(ROOT/'gate-checks.json',dict(complete=True,nikon_all_14bit_counts_gate_identity=True,alphas=[1.,.5]))
    datasets=[];keys=[];cal={};coords={};fullsources=[]
    for domain,path in [('nikon',NIKON),('mission1',CAMERA)]:
        info=json.loads((path/'dataset.json').read_text());assert info['complete'] and sha(path/'inputs.npy')==info['input_sha256'] and sha(path/'targets.npy')==info['target_sha256']
        index=len(datasets);datasets.append((np.load(path/'inputs.npy',mmap_mode='r'),np.load(path/'targets.npy',mmap_mode='r')))
        for source_index,s in enumerate(info['sources']):
            if s['split']!='validation':continue
            source=Path(s['path']);assert sha(source)==s['sha256'];meta=raw_media.extract(source,14);tags={t['code']:t for t in meta['image']}
            black=np.array(raw_media.values(tags[50714]),np.float32);white=float(raw_media.values(tags[50717])[0]);neutral=np.array(raw_media.values(tags[50728]),np.float32);wb=neutral[1]/neutral;wbg=np.array([wb[0],wb[1],wb[1],wb[2]],np.float32)
            for offset,(y,x) in enumerate(s['low_plane_yx']):
                key=(index,s['patch_start']+offset);keys.append(key);cal[key]=(black,white,wbg,domain+':'+s['group']);coords[key]=boundary.coordinates(x,y,128,128,s['height']//4,s['width']//4)
            fullsources.append(dict(domain=domain,source_index=source_index,dataset=str(path),source=s,black=black.tolist(),white=white,wb=wbg.tolist()))
    assert len(keys)==320 and len(fullsources)==10;save(ROOT/'full-sources.json',fullsources)
    torch.set_num_threads(4);device=torch.device('mps');core=slice(64,192)
    def tensors(ids):
        x=np.stack([np.asarray(datasets[d][0][i],np.float32)/16383 for d,i in ids]);co=np.stack([coords[k] for k in ids]);black=np.stack([cal[k][0] for k in ids])[:,:,None,None];white=np.array([cal[k][1] for k in ids],np.float32)[:,None,None,None];wb=np.stack([cal[k][2] for k in ids])[:,:,None,None]
        return tuple(torch.from_numpy(v).to(device) for v in [x,co,black,white,wb])
    def score(outputs,ids,totals,proxy):
        ref=np.stack([np.asarray(datasets[d][1][i,:,core,core],np.float64) for d,i in ids]);_,_,black,white,wb=tensors(ids)
        def tone(raw):
            signal=((raw*16383-black)/(white-black)*wb).clamp(0,1)
            return (torch.stack([signal[:,0],.5*(signal[:,1]+signal[:,2]),signal[:,3]],1)+1e-4).sqrt()
        error=(tone(torch.from_numpy(outputs.astype(np.float32)/16383).to(device))-tone(torch.from_numpy(ref.astype(np.float32)/16383).to(device))).square().cpu().numpy()
        for key,p,r,e in zip(ids,outputs,ref,error):
            regs=train_stock_sr.region_totals(r,p.astype(np.float64)-r)
            for group in ['pooled',cal[key][3]]:
                a,n=proxy.get(group,(0.,0));proxy[group]=(a+float(e.astype(np.float64).sum()),n+e.size)
                dest=totals.setdefault(group,{})
                for region,(v,count) in regs.items():a,n=dest.get(region,(0.,0));dest[region]=(a+v,n+count)
    def finish(t,p):return dict(regions={g:{r:a/n for r,(a,n) in d.items()} for g,d in t.items()},tone_proxy_mse={g:a/n for g,(a,n) in p.items()})
    totals={c['id']:{} for c in family};proxies={c['id']:{} for c in family};bt={};bp={};controls={};started=time.perf_counter()
    for spec in models:
        cp=Path(spec['path']);assert sha(cp)==spec['sha256'];checkpoint=torch.load(cp,map_location='cpu',weights_only=True);net=mission1_sr_models.make_model_from_config(checkpoint['config']);net.load_state_dict(checkpoint['model'],strict=True);net.to(device).eval();ct={};pt={}
        with torch.inference_mode():
            for start in range(0,len(keys),8):
                ids=keys[start:start+8];x,co,bl,wh,wb=tensors(ids)
                base=np.clip(F.interpolate(x,scale_factor=2,mode='bicubic',align_corners=False).clamp(0,1)[:,:,core,core].cpu().numpy()*16383+.5,0,16383).astype('<u2')
                prediction=np.clip(context.predict(net,x,co,bl,wh,spec['canonical'])[:,:,core,core].cpu().numpy()*16383+.5,0,16383).astype('<u2')
                score(prediction,ids,ct,pt)
                if spec is models[0]:score(base,ids,bt,bp)
                for c in [c for c in family if c['model']==spec['id']]:
                    output=context.correction(base,prediction,[cal[k][0] for k in ids],[cal[k][1] for k in ids],c['alpha'],c['domain']);score(output,ids,totals[c['id']],proxies[c['id']])
        control=finish(ct,pt);controls[spec['id']]=control
        if 'parent' in spec:assert control==spec['parent']['metrics'],'ungated parent checkpoint control exact'
        del net;torch.mps.empty_cache()
        print(json.dumps(dict(patch_model=spec['id'],elapsed_s=time.perf_counter()-started)),flush=True)
    baseline=finish(bt,bp);assert baseline==json.loads((PARENT/'baseline.json').read_text())
    rows=[]
    for c in family:
        m=finish(totals[c['id']],proxies[c['id']]);bad=[g+':'+r for g,d in baseline['regions'].items() for r,v in d.items() if m['regions'][g][r]>v];pb=[g for g,v in baseline['tone_proxy_mse'].items() if m['tone_proxy_mse'][g]>v]
        gain=train_stock_sr.delta(baseline['regions']['pooled']['overall'],m['regions']['pooled']['overall']);rows.append(dict(**c,metrics=m,regressions=bad,proxy_regressions=pb,gain_db=gain,eligible=not bad and not pb and gain>0))
    eligible=[r for r in rows if r['eligible']];save(ROOT/'patch-selection.json',dict(complete=True,protocol_sha256=sha(ROOT/'protocol.json'),baseline=baseline,controls=controls,rows=rows))
    print(json.dumps(dict(patch_complete=True,eligible=len(eligible),family=len(rows))),flush=True)
    if not eligible:save(ROOT/'full-selection.json',dict(complete=True,skipped='No patch-qualified setting',selected=None));return
    report=dict(schema='gpr.stock_sr_sensor_gate_full.v1',complete=False,protocol_sha256=sha(ROOT/'protocol.json'),patch_sha256=sha(ROOT/'patch-selection.json'),quality_approval=False,sources=[]);total={c['id']:0. for c in eligible};bad={c['id']:[] for c in eligible};bt=0.;samples_total=0;regions=['active','shadow_bottom_decile','highlight_top_decile','detail_top_decile']
    for index,entry in enumerate(fullsources):
        s=entry['source'];path=Path(s['path']);meta=raw_media.extract(path,14);w,h=meta['width'],meta['height'];black=entry['black'];white=entry['white'];wb=entry['wb']
        if entry['domain']=='nikon':
            parent=BASE/'stock_sr_source_regions_20261030/all-qualified/full-validation';pr=json.loads((parent/'protocol.json').read_text());pi=next(i for i,r in enumerate(pr['validation_sources']) if r['sha256']==s['sha256']);cache=parent/f'validation-{pi}';old=json.loads((cache/'benchmark.json').read_text());raw=cache/'decoded-low.raw';refpath=cache/'independent-sdk.raw'
        else:
            cache=Path(entry['dataset'])/f"source-{entry['source_index']:03d}";raw=cache/'decoded.raw';refpath=BASE/'mission1p_source_scan_20260616/raw50_decode'/(s['stem']+'.raw');old=None
        assert sha(raw)==s['low_decoded_raw_sha256'] and sha(refpath)==s['reference_raw_sha256'];reference=np.fromfile(refpath,dtype='<u2').reshape(h,w);low=np.fromfile(raw,dtype='<u2').reshape(h//2,w//2)
        base,_=stock_video.restore(raw,w//2,h//2,benchmark_stock_sr.Bicubic(),device,256,64,2);bm=quality(reference,base,meta)
        if old is not None:assert hashlib.sha256(base.tobytes()).hexdigest()==old['bicubic_raw_sha256'] and json.loads(json.dumps(bm))==old['bicubic_metrics']
        tone=context.proxy_mse(reference,base,black,white,wb);top,left,bottom,right=bm['active_area'];samples=(bottom-top)*(right-left);samples_total+=samples;bt+=samples*bm['active']['rmse_counts']**2
        row=dict(source=entry,bicubic_metrics=bm,bicubic_proxy_mse=tone,bicubic_raw_sha256=hashlib.sha256(base.tobytes()).hexdigest(),candidates=[]);report['sources'].append(row)
        for spec in models:
            candidates=[c for c in eligible if c['model']==spec['id']]
            if not candidates:continue
            checkpoint=torch.load(spec['path'],map_location='cpu',weights_only=True);net=mission1_sr_models.make_model_from_config(checkpoint['config']);net.load_state_dict(checkpoint['model'],strict=True);model=context.ContextNetwork(net,black,white,spec['canonical']).to(device).eval()
            pred,stats=boundary.tiled(model,mission1_sr_runtime.deinterleave(low),device,reflect=True);baseplanes=mission1_sr_runtime.deinterleave(base)
            for c in candidates:
                output=context.interleave(context.correction(baseplanes,pred,black,white,c['alpha'],c['domain']));metrics=quality(reference,output,meta);pm=context.proxy_mse(reference,output,black,white,wb);failed=[r for r in regions if metrics[r]['rmse_counts']>bm[r]['rmse_counts']]
                if pm>tone:failed.append('tone_proxy')
                out=ROOT/f"{index}-{c['id']}.raw";output.tofile(out);total[c['id']]+=samples*metrics['active']['rmse_counts']**2;bad[c['id']].extend(dict(source_index=index,region=r) for r in failed)
                row['candidates'].append(dict(id=c['id'],metrics=metrics,tone_proxy_mse=pm,regressions=failed,output_sha256=sha(out),runtime=stats));save(ROOT/'full-selection.json',report)
                print(json.dumps(dict(source_index=index,id=c['id'],regressions=failed,gain_db=metrics['active']['psnr_db']-bm['active']['psnr_db'],elapsed_s=time.perf_counter()-started)),flush=True)
            del model,net,pred;torch.mps.empty_cache()
        del base,reference,low,output
    results=[dict(id=c['id'],candidate=c,active_mse=total[c['id']]/samples_total,gain_db=float(10*np.log10(bt/total[c['id']])),regressions=bad[c['id']],eligible=not bad[c['id']] and total[c['id']]<bt) for c in eligible]
    report.update(complete=True,results=results,render_candidates=[r for r in results if r['eligible']],selected=None,selection_deferred='Actual rendered comparison versus supplied BIBO required before freeze',baseline_active_mse=bt/samples_total,active_samples=samples_total);save(ROOT/'full-selection.json',report);print(json.dumps(dict(full_complete=True,render_candidates=len(report['render_candidates']))),flush=True)
if __name__=='__main__':main()
