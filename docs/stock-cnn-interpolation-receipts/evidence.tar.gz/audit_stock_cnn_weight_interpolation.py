"""Verify parameter interpolation and independently repeat frozen validation."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch
from stock_cnn_joint_validation import load_validation,stock_video,REPO
ROOT=Path('/Volumes/OWC_8TB/gpr_work/artifacts/stock_cnn_weight_interpolation_20261031')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=json.loads((ROOT/'protocol.json').read_text());r=json.loads((ROOT/'results.json').read_text());assert r['complete'] and not r['eligible'] and len(r['candidates'])==len(p['family'])==10
 assert sha(ROOT/'protocol.json')==r['protocol_sha256'];assert sha(ROOT/'interpolate_stock_cnn_checkpoints.py')==p['driver_sha256'];assert sha(ROOT/'stock_cnn_joint_validation.py')==p['validation_driver_sha256']
 sr=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt';assert sha(sr)==p['base_sha256'];base=torch.load(sr,map_location='cpu',weights_only=True)
 evaluate,_,_=load_validation();controls={}
 for row in r['controls']:
  m=None if row['setting']=='bicubic' else stock_video.load_cnn(None,sr,torch.device('mps'))[0]
  actual=evaluate(None,m);assert actual==row['scores'];controls[row['setting']]=actual;del m
 rows=[];tensors=0
 for setting,row in zip(p['family'],r['candidates']):
  assert (setting['step'],setting['alpha'])==(row['step'],row['alpha']);end=Path(setting['endpoint']['path']);assert sha(end)==setting['endpoint']['sha256']
  endpoint=torch.load(end,map_location='cpu',weights_only=True);path=ROOT/f'sr-step{row["step"]}-alpha{row["alpha"]}.pt';assert sha(path)==row['checkpoint_sha256'];ck=torch.load(path,map_location='cpu',weights_only=True)
  for k,left in base['backbone_state'].items():
   a=left.numpy();b=endpoint['backbone_state'][k].numpy();observed=ck['backbone_state'][k].numpy();t=row['alpha']
   expected=((1-t)*a.astype(np.float64)+t*b.astype(np.float64)).astype(a.dtype) if np.issubdtype(a.dtype,np.floating) else a
   assert np.array_equal(observed,expected),k;tensors+=1
  model,_=stock_video.load_cnn(None,path,torch.device('mps'));scores=evaluate(None,model);assert scores==row['metrics'];del model;torch.mps.empty_cache()
  bad=[label+':'+g+':'+key for label,name in [('bicubic','bicubic'),('supplied','supplied_sr')] for g,d in controls[name]['regions'].items() for key,v in d.items() if scores['regions'][g][key]>v]
  tonebad=[g for g,v in scores['tone_proxy_mse'].items() if v>controls['supplied_sr']['tone_proxy_mse'][g]]
  assert bad==row['raw_regressions'] and tonebad==row['tone_proxy_regressions'];assert bad and not row['eligible'];assert any('nikon:' in x and x.endswith(':shadow') for x in bad)
  rows.append(dict(step=row['step'],alpha=row['alpha'],prediction_sha256=scores['prediction_sha256'],raw_regressions=bad));print('Verified '+str((row['step'],row['alpha'])),flush=True)
 result=dict(schema='gpr.stock_cnn_weight_interpolation_audit.v1',complete=True,driver_sha256=sha(Path(__file__)),protocol_sha256=sha(ROOT/'protocol.json'),results_sha256=sha(ROOT/'results.json'),settings_reinferred=12,validation_patches_per_setting=320,parameter_tensors_compared=tensors,all_parameters_exact_numpy_float64_interpolation=True,all_prediction_hashes_and_raw_proxy_scores_reproduced=True,all_candidates_fail_nikon_shadow_guards=True,selected=None,results=rows)
 (ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
