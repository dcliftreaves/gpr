"""Validation-only weight interpolation of related stock SR checkpoints."""
from pathlib import Path
import datetime,hashlib,json,math,shutil,sys,time
import numpy as np
import torch
from stock_cnn_joint_validation import load_validation,stock_video,REPO
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');ROOT=BASE/'stock_cnn_weight_interpolation_20261031';PARENT=BASE/'stock_cnn_joint_20261031'
SR=REPO/'models/stock-q3-rggb14-sr-diagnostic/selected.pt'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def main():
 ROOT.mkdir(exist_ok=False)
 for n in [Path(__file__),Path(__file__).with_name('stock_cnn_joint_validation.py')]:shutil.copyfile(n,ROOT/n.name)
 parent=json.loads((PARENT/'training.json').read_text());assert parent['complete']
 endpoints=next(r for r in parent['cases'] if r['case']=='sr-only')['checkpoints'];assert [r['step'] for r in endpoints]==[200,400]
 family=[dict(step=r['step'],alpha=a,endpoint=r['checkpoints']['sr']) for r in endpoints for a in [0.125,0.25,0.5,0.75,1.0]]
 for row in family:assert sha(Path(row['endpoint']['path']))==row['endpoint']['sha256']
 protocol=dict(schema='gpr.stock_cnn_weight_interpolation_protocol.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_sha256=sha(SR),parent_training_sha256=sha(PARENT/'training.json'),parent_protocol_sha256=sha(PARENT/'protocol.json'),driver_sha256=sha(Path(__file__)),validation_driver_sha256=sha(Path(__file__).with_name('stock_cnn_joint_validation.py')),family=family,interpolation='Each floating backbone tensor: ((1-alpha)*base.float64 + alpha*endpoint.float64).to(originaldtype). Nonfloating tensors must be identical. Batchnorm buffers must be identical and remain exact. All architecture, normalization, residual strength and inference metadata from supplied model. This interpolates parameters, not output predictions.',evaluation='Same320source-grouped validation patch cores, extended256lowplanes context and calibrated NumPy tone proxy as independently audited parent study. Exact RAW scores of bicubic/base/endpoint controls must reproduce. Per-group and pooled four-region MSE<=BOTHbicubicandsuppliedSR, tone proxy MSE<=suppliedSR eachgroup; positive pooled gain required. All patch-qualified family members advance to all10complete validationimages and actualrenderer before freeze/final.',selection='No final-reference pixels; no thresholds relaxed. Current supplied model unchanged unless full quality/native/Pi validation passes. These reused validation sources have historical pretraining overlap; not blind/sensor truth.',torch=torch.__version__,quality_approval=False)
 save(ROOT/'protocol.json',protocol)
 evaluate,oldprotocol,oldreport=load_validation();assert sha(PARENT/'protocol.json')==protocol['parent_protocol_sha256']
 baseline=json.loads((PARENT/'baseline.json').read_text());report=dict(schema='gpr.stock_cnn_weight_interpolation.v1',complete=False,protocol_sha256=sha(ROOT/'protocol.json'),controls=[],candidates=[],quality_approval=False);started=time.perf_counter()
 def compare(actual,expected):
  assert actual['regions']==expected['regions']
  for g,v in actual['tone_proxy_mse'].items():assert np.isclose(v,expected['tone_proxy_mse'][g],rtol=2e-5,atol=1e-12)
 base=torch.load(SR,map_location='cpu',weights_only=True)
 for label,path in [('bicubic',None),('supplied_sr',SR)]:
  model=None if path is None else stock_video.load_cnn(None,path,torch.device('mps'))[0]
  score=evaluate(None,model);compare(score,baseline[label]);report['controls'].append(dict(setting=label,scores=score));del model
 reference_proxy=report['controls'][1]['scores']['tone_proxy_mse']
 for row in family:
  endpoint=torch.load(row['endpoint']['path'],map_location='cpu',weights_only=True);assert base['backbone_state'].keys()==endpoint['backbone_state'].keys()
  checkpoint=dict(base);state={};a=row['alpha']
  for key,left in base['backbone_state'].items():
   right=endpoint['backbone_state'][key];assert left.shape==right.shape and left.dtype==right.dtype
   if not left.is_floating_point() or any(n in key for n in ['running_mean','running_var','num_batches_tracked']):assert torch.equal(left,right);state[key]=left.clone()
   else:state[key]=((1-a)*left.to(torch.float64)+a*right.to(torch.float64)).to(left.dtype)
   expected=((1-a)*left.numpy().astype(np.float64)+a*right.numpy().astype(np.float64)).astype(left.numpy().dtype) if left.is_floating_point() else left.numpy()
   assert np.array_equal(state[key].numpy(),expected),key
   if a==1:assert torch.equal(state[key],right)
  checkpoint['backbone_state']=state;checkpoint.update(quality_approval=False,weight_interpolation_protocol_sha256=sha(ROOT/'protocol.json'),weight_interpolation_step=row['step'],weight_interpolation_alpha=a)
  path=ROOT/f'sr-step{row["step"]}-alpha{a}.pt';torch.save(checkpoint,path)
  model,_=stock_video.load_cnn(None,path,torch.device('mps'));scores=evaluate(None,model);del model;torch.mps.empty_cache()
  if a==1:compare(scores,next(c for c in endpoints if c['step']==row['step'])['metrics'])
  bad=[label+':'+g+':'+r for label,key in [('bicubic','bicubic'),('supplied','supplied_sr')] for g,d in baseline[key]['regions'].items() for r,v in d.items() if scores['regions'][g][r]>v]
  tonebad=[g for g,v in scores['tone_proxy_mse'].items() if v>reference_proxy[g]];gain=10*math.log10(baseline['supplied_sr']['regions']['pooled']['overall']/scores['regions']['pooled']['overall'])
  result=dict(step=row['step'],alpha=a,checkpoint_sha256=sha(path),metrics=scores,raw_regressions=bad,tone_proxy_regressions=tonebad,gain_db_vs_supplied=gain,eligible=not bad and not tonebad and gain>0,elapsed_s=time.perf_counter()-started)
  report['candidates'].append(result);save(ROOT/'results.json',report);print(json.dumps({k:result[k] for k in ['step','alpha','gain_db_vs_supplied','raw_regressions','tone_proxy_regressions','eligible']}),flush=True)
 report.update(complete=True,elapsed_s=time.perf_counter()-started,eligible=[dict(step=r['step'],alpha=r['alpha']) for r in report['candidates'] if r['eligible']]);save(ROOT/'results.json',report);print(json.dumps(dict(complete=True,eligible=report['eligible'],elapsed_s=report['elapsed_s'])),flush=True)
if __name__=='__main__':main()
