"""Re-run all joint-study patch predictions and independently score RAW regions."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch
import torch.nn.functional as F
import tifffile
REPO=Path('/Users/dcliftreaves/Documents/slop/gpr_check/worktrees/stock-raw-media-runtime');sys.path.insert(0,str(REPO/'tools'))
import raw_media,stock_video
BASE=Path('/Volumes/OWC_8TB/gpr_work/artifacts');ROOT=BASE/'stock_cnn_joint_20261031';PEAK=16383.
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_validation():
    protocol=json.loads((ROOT/'protocol.json').read_text());report=json.loads((ROOT/'training.json').read_text());assert report['complete'] and not report['eligible'];assert sha(ROOT/'train_stock_cnn_joint.py')==protocol['driver_sha256'];torch.set_num_threads(4);device=torch.device('mps');items=[]
    for dataset in protocol['datasets']:
        d=Path(dataset['path']);info=json.loads((d/'dataset.json').read_text());assert sha(d/'dataset.json')==dataset['manifest_sha256'];inputs=np.load(d/'inputs.npy',mmap_mode='r');targets=np.load(d/'targets.npy',mmap_mode='r')
        for si,s in enumerate(info['sources']):
            if s['split']!='validation':continue
            meta=raw_media.extract(s['path'],14);tags={x['code']:x for x in meta['image']};black=np.array(raw_media.values(tags[50714]),np.float32);white=float(raw_media.values(tags[50717])[0]);wb=np.array(raw_media.values(tags[50728]),np.float32);wb=wb[1]/wb;wb=wb[[0,1,1,2]]
            raw=d/f'source-{si:03d}/decoded.raw'
            if raw.exists():image=np.fromfile(raw,dtype='<u2').reshape(s['height']//2,s['width']//2)
            else:
                with tifffile.TiffFile(d/f'source-{si:03d}/decoded.dng') as f:image=f.asarray()
            assert hashlib.sha256(image.tobytes()).hexdigest()==s['low_decoded_raw_sha256'];planes=np.stack([image[c//2::2,c%2::2] for c in range(4)]);h,w=planes.shape[-2:];pad=np.pad(planes,((0,0),(0,-h%8),(0,-w%8)),mode='edge')
            for j,(y,x) in enumerate(s['low_plane_yx']):
                index=s['patch_start']+j;assert np.array_equal(planes[:,y:y+128,x:x+128],inputs[index]);top=min(max(0,y-64),pad.shape[-2]-256);left=min(max(0,x-64),pad.shape[-1]-256)
                items.append(dict(input=pad[:,top:top+256,left:left+256],target=np.array(targets[index,:,64:192,64:192],np.float64),crop=(2*(y-top)+64,2*(x-left)+64),valid=(min(256,h-top),min(256,w-left)),black=black,white=white,wb=wb,group=dataset['domain']+':'+s['group']))
    assert len(items)==320
    def evaluate(clean,sr):
        totals={};proxy={};digest=hashlib.sha256()
        with torch.inference_mode():
            for start in range(0,len(items),4):
                batch=items[start:start+4];x=torch.from_numpy(np.stack([r['input'] for r in batch]).astype(np.float32)/PEAK).to(device)
                if clean is not None:
                    low=torch.floor(clean(x)*PEAK+.5).clamp(0,PEAK)/PEAK
                    x=torch.cat([F.pad(low[j:j+1,:,:r['valid'][0],:r['valid'][1]],(0,256-r['valid'][1],0,256-r['valid'][0]),mode='replicate') for j,r in enumerate(batch)])
                out=F.interpolate(x,scale_factor=2,mode='bicubic',align_corners=False).clamp(0,1) if sr is None else sr(x)
                for j,r in enumerate(batch):
                    y,x0=r['crop'];p=np.clip(out[j,:,y:y+128,x0:x0+128].cpu().numpy()*PEAK+.5,0,PEAK).astype('<u2');digest.update(p.tobytes());ref=r['target'];squared=np.square(p.astype(np.float64)-ref)
                    lo=np.percentile(ref,10);hi=np.percentile(ref,90);g=np.zeros_like(ref);g[:,:,1:]+=np.abs(ref[:,:,1:]-ref[:,:,:-1]);g[:,1:,:]+=np.abs(ref[:,1:,:]-ref[:,:-1,:]);threshold=np.percentile(g,90)
                    masks={'overall':np.ones_like(ref,dtype=bool),'shadow':ref<=lo,'highlight':ref>=hi,'detail':g>=threshold}
                    # Independent NumPy calibrated proxy; permit float32-roundoff
                    # differences against producer Torch sqrt, never RAW differences.
                    def tone(a):
                        signal=np.clip((a.astype(np.float64)-r['black'][:,None,None])/(r['white']-r['black'])[:,None,None]*r['wb'][:,None,None],0,1)
                        return np.sqrt(np.stack([signal[0],.5*(signal[1]+signal[2]),signal[3]])+1e-4)
                    errors=np.square(tone(p)-tone(ref))
                    for group in ['pooled',r['group']]:
                        dest=totals.setdefault(group,{})
                        for key,mask in masks.items():a,n=dest.get(key,(0.,0));dest[key]=(a+float(squared[mask].sum()),n+int(np.count_nonzero(mask)))
                        a,n=proxy.get(group,(0.,0));proxy[group]=(a+float(errors.sum()),n+errors.size)
        return dict(regions={g:{r:a/n for r,(a,n) in d.items()} for g,d in totals.items()},tone_proxy_mse={g:a/n for g,(a,n) in proxy.items()},prediction_sha256=digest.hexdigest())
    return evaluate,protocol,report
